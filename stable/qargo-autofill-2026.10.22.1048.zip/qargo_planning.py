"""Qargo's planning, through the requests its own web app sends: the trips of a day with their stops and resources,
the resources (drivers, tractors, trailers), and the two changes assign_trips.py makes:

  assign(trip, resource ids)        what "Assign resources" -> Save sends (MoveShipmentMutation)
  reorder(trip, stop ids in order)  what the order page's Route -> Edit route -> Save sends

Qargo accepts only the exact request texts its app sends. The reads are learned from the Orders, Planning and an
order page as they load (so a Qargo update is followed); the two changes cannot be learned without making one, so
their texts are the ones the app sent on 21 Oct 2026 (recorded with the request blocked, nothing changed). If Qargo
changes them, a change fails with "query is not allowed" and nothing is changed.

Every change is read back: no answer, or Qargo still showing the old state, is an error, never "done".
"""
import time
from cancel_overdue import Qargo, NoAnswer, PAGE_ANSWER_S

MOVE_SHIPMENT = ("mutation MoveShipmentMutation($args: [MoveShipmentsArgs!]!) {\n  MoveShipments(args: $args) {\n"
                 "    message\n    __typename\n  }\n}\n")
REORDER_STOPS = ("mutation MoveAndReorderActualStopsMutation($args: MoveAndReorderActualStopsArgs!, "
                 "$includeShipment: Boolean = false) {\n  MoveAndReorderActualStops(args: $args) {\n    row_id\n"
                 "    shipment @include(if: $includeShipment) {\n      actual_stops {\n        row_id\n"
                 "        shipment_sequence_number\n        __typename\n      }\n      display_name\n"
                 "      estimated_start_timestamp\n      name\n      row_id\n      __typename\n    }\n"
                 "    __typename\n  }\n}\n")
NOT_STARTED = ("TO_PLAN", "PLANNED")
CHECK_S = 60                     # how long a change may take to show when read back


class Planning(Qargo):
    """a hidden, logged-in Qargo (copy of the login) that knows the planning page's own requests"""

    def __init__(self, pw, profile):
        super().__init__(pw, profile)                       # the Orders page: ElasticQuery
        from qargo_fill import TENANT_URL
        self.tenant = TENANT_URL
        self._learn("/planning/home", ("PlanningBoardDataQuery", "ResourcesToPlanQuery"))

    def _learn(self, path, ops):
        self.page.goto(self.tenant + path, wait_until="load", timeout=PAGE_ANSWER_S * 1000)
        deadline = time.time() + PAGE_ANSWER_S
        while not set(ops) <= self.seen.keys():
            if time.time() > deadline:
                missing = sorted(set(ops) - self.seen.keys())
                raise NoAnswer(f"NO ANSWER: {path} did not send {missing} within {PAGE_ANSWER_S} s (internet?)")
            self.page.wait_for_timeout(500)

    def text(self, op):
        return self.seen[op][2]

    # ---- reads
    def trips(self, dates):
        """the trips with a stop on one of `dates` (YYYY-MM-DD) that have not started: [shipment]"""
        q = {"filter": {"bool": {"filter": [
                {"bool": {"must_not": [{"terms": {"status": ["IGNORED"]}}]}},
                {"nested": {"path": "stops", "query": {"bool": {"must": [
                    {"terms": {"stops.date": sorted(dates)}}]}}}},
                {"terms": {"modality": ["ROAD"]}},
                {"terms": {"status": list(NOT_STARTED)}}]}},
             "index": "SHIPMENT_SUMMARY_V5", "offset": 0, "size": 1000,
             "sort": [{"orders.name": {"order": "asc", "missing": "_last"}}], "source": ["updated_timestamp"]}
        hits = self.run("ElasticQuery", self.text("ElasticQuery"), {"query": q})["Search"]["hits"]
        return self.shipments([h["row_id"] for h in hits])

    def to_plan_from(self, day):
        """every trip still To plan with a stop on `day` (YYYY-MM-DD) or later: [shipment]"""
        q = {"filter": {"bool": {"filter": [
                {"nested": {"path": "stops", "query": {"bool": {"must": [{"range": {"stops.date": {"gte": day}}}]}}}},
                {"terms": {"modality": ["ROAD"]}},
                {"terms": {"status": ["TO_PLAN"]}}]}},
             "index": "SHIPMENT_SUMMARY_V5", "offset": 0, "size": 1000,
             "sort": [{"orders.name": {"order": "asc", "missing": "_last"}}], "source": ["updated_timestamp"]}
        hits = self.run("ElasticQuery", self.text("ElasticQuery"), {"query": q})["Search"]["hits"]
        return self.shipments([h["row_id"] for h in hits])

    def shipments(self, ids):
        out = []
        for i in range(0, len(ids), 40):
            out += self.run("PlanningBoardDataQuery", self.text("PlanningBoardDataQuery"),
                            {"rowIds": ids[i:i + 40]})["shipment"]
        return out

    def resources(self, day):
        v = {"calendarEventFilter": {"_and": [{"category": {"_neq": "VALIDITY"}},
                                              {"_or": [{"end_timestamp": {"_gte": day}}, {"end_timestamp": {"_is_null": True}}]}]},
             "resourceFilter": {"resource_type": {"_nin": ["AIRPLANE", "BARGE", "FERRY", "TRAIN"]}},
             "validFromDate": day, "validToDate": day}
        return self.run("ResourcesToPlanQuery", self.text("ResourcesToPlanQuery"), v)["resource"]

    def consignment_refs(self, order_id):
        """{consignment row id: consignment reference} of one order (the VO-numbers of a Vredeveld order)"""
        if "OrderDetailHelperQuery" not in self.seen:
            self._learn(f"/orders/{order_id}", ("OrderDetailHelperQuery",))
        o = self.run("OrderDetailHelperQuery", self.text("OrderDetailHelperQuery"), {"orderId": order_id})["order"]
        return {c["row_id"]: (c.get("consignment_reference_number") or "").strip() for c in o.get("consignments") or []}

    # ---- changes, each read back (and the trip as Qargo shows it afterwards is returned)
    def assign(self, ship, resource_ids):
        self.run("MoveShipmentMutation", MOVE_SHIPMENT, {"args": [{
            "resource_group": list(resource_ids),
            "shipments": [{"row_id": ship["row_id"], "planned_start_timestamp": ship["planned_start_timestamp"]}]}]})
        return self._wait(ship, lambda s: sorted(allocated(s)) == sorted(resource_ids), "the resources")

    def reorder(self, ship, stop_ids):
        self.run("MoveAndReorderActualStopsMutation", REORDER_STOPS, {"includeShipment": False, "args": {
            "actual_stops": [{"row_id": sid, "sequence_number": i} for i, sid in enumerate(stop_ids)],
            "shipment": {"row_id": ship["row_id"]}}})
        return self._wait(ship, lambda s: [x["row_id"] for x in sorted(s["actual_stops"],
                                           key=lambda x: x["shipment_sequence_number"])] == list(stop_ids), "the stop order")

    def _wait(self, ship, ok, what):
        deadline = time.time() + CHECK_S
        while True:
            now = self.shipments([ship["row_id"]])
            if now and ok(now[0]):
                return now[0]
            if time.time() > deadline:
                raise NoAnswer(f"NO ANSWER: {ship['name']}: Qargo does not show {what} {CHECK_S} s after the change "
                               f"(internet?); check the trip in Qargo")
            self.page.wait_for_timeout(1000)


def allocated(ship):
    """the resource ids on a trip"""
    return [a["resource"]["row_id"] if isinstance(a.get("resource"), dict) else a.get("resource_id")
            for a in ship.get("resource_allocations") or [] if not a.get("deleted")]
