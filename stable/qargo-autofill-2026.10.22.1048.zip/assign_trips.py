#!/usr/bin/env python3
"""Assign driver, tractor and trailer to today's and tomorrow's trips from the planning sheet, and put the stops of
each trip in the right order. Part of the scheduled "Check planning mail", after mail_watch.py.

  .venv/bin/python assign_trips.py              # assign and reorder; print the report
  .venv/bin/python assign_trips.py --dry-run    # only say what it would do; nothing changes in Qargo

Rules (decided with him, 21 Oct 2026):
- Trips with a stop today or tomorrow that have not started, and every trip still "To plan" from today on (any
  date), that are not in the driver's app yet ("Send to mobile app" not done). It never sends anything to the app: that stays his step.
- The charter code on the order (Instructions, first line) says which sheet row: Cornelissen DEBAnn, Simon Loos
  DENIBAREnn, PostNL its route code; Vredeveld the Wagen of the planning mail. No code, a code the sheet does not
  have, or one it has twice: the trip is left alone and listed.
- Driver, tractor and trailer each must match exactly one Qargo resource, or the trip is left alone (a wrong pick
  is worse than none). A trip with a zero-emission note needs a tractor whose Qargo note says it can enter.
- An assignment is changed only if the bot made it and nobody changed it since (assign_state.json); a person's
  assignment is never touched, a difference with the sheet is reported.
- Stop order: Vredeveld as the planning mail's rows, everyone else by the requested time windows (stop_order.py).
  A trip whose order cannot be worked out for certain is left as it is and listed.
"""
import argparse, datetime, json, re, sys, tempfile, unicodedata
from dataclasses import dataclass, field
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import paths
import planning_sheet
import stop_order
import vredeveld_plan

CODE_RES = {        # customer -> the charter code in line 1 of the order Instructions
    "Cornelissen": re.compile(r"\bDEBA\s*0*(\d+[A-Z]?)\b", re.I),
    "Simon Loos": re.compile(r"\bDENIBARE\s*0*(\d+[A-Z]?)\b", re.I),
    "PostNL": re.compile(r"\b(DEN[A-Z]{3}\d{2}[A-Z]?)\b", re.I),
}
SHEET_JOBS = {      # customer -> the sheet's COMP. values that are its work
    "Cornelissen": ("corn",), "Simon Loos": ("simon loos",), "PostNL": ("post nl", "postnl"), "Vredeveld": ("vredeveld",),
}
ZE_NOTE = re.compile(r"zero[- ]?emissie|zero[- ]?emission|\bZE\b", re.I)
ZE_OK = re.compile(r"can enter 0 emission|kan .*0[- ]?emissie", re.I)


def plain(text):
    """upper case, no accents, single spaces"""
    t = unicodedata.normalize("NFKD", text or "").encode("ascii", "ignore").decode()
    return " ".join(t.upper().split())


def charter_key(cell):
    """'zm 3' / 'ZM3' / '03' / 'DEBA03' / '5A' -> '3' / '3' / '3' / '3' / '5A'; '' when there is no number"""
    m = re.search(r"0*(\d+[A-Z]?)\b", plain(cell).replace(" ", ""))
    return m.group(1) if m else ""


def plate(text):
    """the registration in a sheet cell ('OT08PP-4' -> 'OT08PP'); several or none -> None"""
    is_plate = lambda t: re.fullmatch(r"[A-Z0-9]{6,8}", t) and re.search(r"[A-Z]", t) and re.search(r"\d", t)
    found = []
    for token in re.split(r"[\s+/,;]+", plain(text)):
        whole = token.replace("-", "")
        head = token.split("-")[0]                          # OT08PP-4 (the sheet's trailer number), OR87BJ-CHASIS
        if re.fullmatch(r"[A-Z0-9]{1,3}(?:-[A-Z0-9]{1,3}){2}", token) and is_plate(whole):
            found.append(whole)                             # a plate written with dashes: OK-65-BY
        elif is_plate(head):
            found.append(head)
    return found[0] if len(set(found)) == 1 else None


@dataclass
class Result:
    trip: str
    order: str
    customer: str
    ref: str
    assigned: str = ""          # what was assigned (names), or why not
    reordered: str = ""         # what happened to the stop order
    problems: list = field(default_factory=list)


def order_of(ship):
    stops = ship.get("actual_stops") or []
    return (stops[0].get("order") or {}) if stops else {}


def is_container(ship):
    return any((s.get("order") or {}).get("container_scenario") for s in ship.get("actual_stops") or [])


def trip_day(ship):
    """the local date of the trip's first customer stop (the UTC start of a midnight trip is the day before)"""
    d = (((ship.get("shipment_summary") or {}).get("first_consignment_stop") or {}).get("date")
         or min((s.get("date") for s in ship.get("actual_stops") or [] if s.get("date")), default=None))
    return datetime.date.fromisoformat(d) if d else None


def in_app(ship):
    return (ship.get("shipment_summary") or {}).get("dispatch") == "SENT"


def charter_of(ship, wagen_of_ref):
    """(customer, code) of a trip, or (customer, None) with no code"""
    o = order_of(ship)
    cust = ((o.get("customer") or {}).get("name") or "").strip()
    if cust == "Vredeveld":
        refs = [r.strip() for r in (o.get("customer_reference_number") or "").split("/")]
        wagens = {wagen_of_ref[r] for r in refs if r in wagen_of_ref}
        return cust, (str(wagens.pop()) if len(wagens) == 1 else None)
    first = ((o.get("instructions") or "").strip().splitlines() or [""])[0]
    rx = CODE_RES.get(cust)
    m = rx.search(first) if rx else None
    return cust, (re.sub(r"\s+", "", m.group(0)).upper() if m else None)


def sheet_rows(entries, customer, code):
    """the sheet entries of one customer whose CHARTER is this code"""
    jobs = SHEET_JOBS.get(customer, ())
    mine = [e for e in entries if any(j in e.comp.lower() for j in jobs)]
    if customer == "PostNL":                     # the route code, written with or without its last V (DENTIL01V)
        route_code = lambda s: re.sub(r"V$", "", plain(s).replace(" ", ""))
        return [e for e in mine if e.charter and route_code(e.charter) == route_code(code)]
    return [e for e in mine if charter_key(e.charter) == charter_key(code)]


def names_file():
    """sheet spellings of drivers that differ from Qargo's: {"OLEG GAYDARDZHI": "Oleg Gaidarji"} (he confirms each)"""
    return paths.data_dir() / "sheet_names.json"


def sheet_names():
    f = names_file()
    try:
        return {plain(k): v for k, v in json.loads(f.read_text(encoding="utf-8")).items()} if f.exists() else {}
    except ValueError:
        return {}


def find_resource(resources, kind, text, aliases=None):
    """the one Qargo resource of this kind for a sheet cell; (resource, None) or (None, why)"""
    live = [r for r in resources if r.get("resource_type") == kind and not r.get("archived")]
    if kind == "DRIVER":
        alias = (aliases if aliases is not None else sheet_names()).get(plain(text))
        if alias:
            hits = [r for r in live if plain(r.get("name")) == plain(alias)]
        else:
            want = plain(text).split()
            hits = [r for r in live if want and all(w in plain(r.get("name")).split() for w in want)]
        if not hits:
            import difflib
            close = difflib.get_close_matches(plain(text), [plain(r["name"]) for r in live], n=1, cutoff=0.6)
            names = {plain(r["name"]): r["name"] for r in live}
            return None, (f"driver '{text}' is not in Qargo" +
                          (f" (closest: {names[close[0]]}; if that is the driver, tell Claude "
                           f"'{text.strip()} is {names[close[0]]}' to remember it)" if close else ""))
    else:
        p = plate(text)
        if not p:
            return None, f"{kind.lower()} '{text}': not one registration"
        # a record named exactly as the sheet writes it first: Qargo also has imported copies with dashes
        # (BB-063-P next to BB063P); the planners use the exact one (21 Oct 2026)
        hits = [r for r in live if plain(r.get("name")).replace(" ", "") == p] or \
               [r for r in live if plate(r.get("name")) == p]          # OT06PX/p
    if len(hits) == 1:
        return hits[0], None
    return None, (f"{kind.lower()} '{text}' is not in Qargo" if not hits else
                  f"{kind.lower()} '{text}' fits {len(hits)} Qargo resources ({', '.join(r['name'] for r in hits[:4])})")


def plan_resources(ship, entry, resources):
    """[driver, tractor, trailer] Qargo resources for a sheet row, or (None, why)"""
    if not entry.driver or not entry.truck:
        return None, f"sheet row {entry.row} has no driver or no truck"
    picked = []
    for kind, cell in (("DRIVER", entry.driver), ("TRACTOR", entry.truck), ("TRAILER", entry.trailer)):
        if kind == "TRAILER" and not cell:
            continue
        r, why = find_resource(resources, kind, cell)
        if not r:
            return None, why
        picked.append(r)
    o = order_of(ship)
    if ZE_NOTE.search(o.get("instructions") or ""):
        tractor = picked[1]
        if not ZE_OK.search(tractor.get("note") or ""):
            return None, f"zero-emission trip, and Qargo's note on {tractor['name']} does not say it can enter"
    return picked, None


def state_file():
    return paths.data_dir() / "assign_state.json"


def load_state():
    f = state_file()
    return json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}


def save_state(state):
    """write what this run assigned, keeping what another run wrote meanwhile (a check by hand next to the scheduled
    one, 21 Oct 2026: the scheduled run wrote the file back without the 7 trips the other had just assigned)"""
    disk = load_state()
    for k, v in state.items():
        if k not in disk or (disk[k].get("at") or "") <= (v.get("at") or ""):
            disk[k] = v
    state.update(disk)
    tmp = state_file().with_suffix(".tmp")
    tmp.write_text(json.dumps(disk, indent=1), encoding="utf-8")
    tmp.replace(state_file())


def run(q, days, entries_of, plans_of, *, dry_run=False, state=None, now=None):
    """one pass over the trips. q: a qargo_planning.Planning (or a stand-in); entries_of(day) -> sheet entries or
    raises; plans_of(day) -> (rows per Wagen, problems). Returns [Result] and the general problems."""
    from qargo_planning import allocated
    state = state if state is not None else load_state()
    now = now or datetime.datetime.now().astimezone()
    general, results = [], []
    trips = {s["row_id"]: s for s in q.trips([d.isoformat() for d in days])}
    for s in q.to_plan_from(days[0].isoformat()):          # every To plan trip from today on, whatever its date
        trips.setdefault(s["row_id"], s)
    trips = list(trips.values())
    days = sorted(set(days) | {d for d in map(trip_day, trips) if d and d >= days[0]})
    sheets, plans, wagen_refs = {}, {}, {}
    for d in days:
        try:
            sheets[d] = entries_of(d)
        except Exception as e:
            sheets[d] = None
            general.append(f"!! SHEET for {d:%d-%m}: {e}. Nothing was assigned for that day.")
        rows, problems = plans_of(d)
        plans[d] = rows or {}
        general += [f"Vredeveld {d:%d-%m}: {p}" for p in problems]
        wagen_refs[d] = {str(r.get("ref") or "").strip(): w for w, rs in (rows or {}).items() for r in rs if r.get("ref")}
    resources = {d: q.resources(d.isoformat()) for d in days if sheets.get(d) is not None}
    for ship in sorted(trips, key=lambda s: (s.get("planned_start_timestamp") or "", s["name"])):
        o = order_of(ship)
        day = trip_day(ship) or days[0]
        day = day if day in days else days[0]             # a trip begun before today with a stop today
        res = Result(ship["name"], o.get("name") or "", (o.get("customer") or {}).get("name") or "?",
                     o.get("customer_reference_number") or "")
        results.append(res)
        if is_container(ship):
            res.assigned = res.reordered = "container order: left alone"
            continue
        if in_app(ship):
            res.assigned = res.reordered = "already sent to the driver's app: left alone"
            continue
        # ---- the stop order
        stops = stop_order.stops_of(ship)
        if res.customer == "Vredeveld":
            w = wagen_refs[day].get(res.ref.split("/")[0].strip())
            if w is None:
                plan = stop_order.Plan(None, "not in the Vredeveld planning mail (yet)")
            else:
                vos = q.consignment_refs(o["row_id"])
                plan = stop_order.by_planning_rows(stops, vos, plans[day][w], refs=res.ref.split("/"))
        else:
            plan = stop_order.by_time_windows(stops)
        if plan.order is None:
            res.reordered = f"left as it is: {plan.why}"
        elif not plan.changed:
            res.reordered = "already in the right order"
        elif dry_run:
            res.reordered = "WOULD REORDER: " + route(stops, plan.order)
        else:
            try:
                q.reorder(ship, plan.order)
                res.reordered = "REORDERED: " + route(stops, plan.order)
            except Exception as e:
                res.reordered = f"!! not reordered: {str(e).splitlines()[0][:200]}"
        # ---- the resources
        if sheets.get(day) is None:
            res.assigned = "no sheet for this day"
            continue
        customer, code = charter_of(ship, wagen_refs[day])
        have = sorted(allocated(ship))
        mine = state.get(ship["row_id"], {}).get("resources")
        if not code:
            res.assigned = "no charter code on the order" if customer != "Vredeveld" else "no Wagen in the planning mail"
            continue
        rows = sheet_rows(sheets[day], customer, code)
        label = f"Wagen {code}" if customer == "Vredeveld" else code
        if len(rows) != 1:
            res.assigned = (f"{label} is not in the sheet for {day:%d-%m}" if not rows else
                            f"{label} is in the sheet {len(rows)} times (rows {', '.join(str(e.row) for e in rows)}): which one?")
            continue
        picked, why = plan_resources(ship, rows[0], resources[day])
        if not picked:
            res.assigned = f"{label} (sheet row {rows[0].row}): {why}"
            continue
        want = sorted(r["row_id"] for r in picked)
        names = " / ".join(r["name"] for r in picked)
        if have == want:
            res.assigned = f"already {names}"
            continue
        if have and have != sorted(mine or []):
            res.assigned = f"!! assigned by hand in Qargo; the sheet says {names} ({label}, row {rows[0].row}): left alone"
            continue
        if dry_run:
            res.assigned = ("WOULD CHANGE to " if have else "WOULD ASSIGN ") + f"{names} ({label}, sheet row {rows[0].row})"
            continue
        try:
            q.assign(ship, want)
            state[ship["row_id"]] = {"trip": ship["name"], "resources": want, "at": now.isoformat()}
            save_state(state)
            res.assigned = ("CHANGED to " if have else "ASSIGNED ") + f"{names} ({label}, sheet row {rows[0].row})"
        except Exception as e:
            res.assigned = f"!! not assigned: {str(e).splitlines()[0][:200]}"
    return results, general


def route(stops, order):
    by_id = {s.id: s for s in stops}
    names, last = [], None
    for sid in order:
        n = (by_id[sid].name or by_id[sid].postcode)[:22]
        if n != last:
            names.append(n)
        last = n
    return " -> ".join(names)


def report(results, general, days, dry_run):
    out = [f"TRIPS {' + '.join(f'{d:%d-%m}' for d in days)}" + (" (dry run: nothing changed)" if dry_run else "")]
    out += general
    for title, pick in (("ASSIGNED / CHANGED", lambda r: r.assigned.startswith(("ASSIGNED", "CHANGED", "WOULD"))),
                        ("REORDERED", lambda r: r.reordered.startswith(("REORDERED", "WOULD"))),
                        ("!! NEEDS YOU", lambda r: r.assigned.startswith("!!") or r.reordered.startswith("!!")),
                        ("LEFT ALONE", lambda r: not r.assigned.startswith(("ASSIGNED", "CHANGED", "WOULD", "!!", "already"))
                                                 and r.assigned)):
        rows = [r for r in results if pick(r)]
        if rows:
            out.append(f"\n{title}")
            for r in rows:
                what = r.reordered if title == "REORDERED" else r.assigned
                out.append(f"   {r.trip} {r.order} {r.customer} ref {r.ref}: {what}")
    left = [r for r in results if r.reordered.startswith("left as it is")]
    if left:
        out.append("\nSTOP ORDER NOT CHECKED")
        out += [f"   {r.trip} {r.order} {r.customer} ref {r.ref}: {r.reordered}" for r in left]
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--dry-run", action="store_true", help="only say what it would do; nothing changes in Qargo")
    ap.add_argument("--today", help="YYYY-MM-DD (tests): the first of the two days")
    a = ap.parse_args(argv)
    today = datetime.date.fromisoformat(a.today) if a.today else datetime.date.today()
    days = [today, today + datetime.timedelta(days=1)]
    from playwright.sync_api import sync_playwright
    from cancel_overdue import copy_profile, NoAnswer
    from qargo_planning import Planning
    token = {}
    def entries_of(d):
        token.setdefault("t", planning_sheet.access_token())
        return planning_sheet.entries(d, token=token["t"])
    plans_of = lambda d: vredeveld_plan.load_plan(paths.documents_dir(), d)[:2]
    with tempfile.TemporaryDirectory(prefix="qargo-assign-") as tmp, sync_playwright() as pw:
        try:
            copy_profile(paths.profile_dir("chromium"), Path(tmp) / "profile")
            q = Planning(pw, Path(tmp) / "profile")
        except Exception as e:
            print(f"!! QARGO NOT OPENED: {str(e).splitlines()[0][:300]}. Nothing assigned or reordered.")
            return 1
        try:
            results, general = run(q, days, entries_of, plans_of, dry_run=a.dry_run)
        finally:
            q.close()
    text = "\n".join(report(results, general, days, a.dry_run))
    print(text)
    if not a.dry_run:
        log = paths.logs_dir() / f"assign_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"
        log.write_text(text + "\n", encoding="utf-8")
        print(f"\nlog: {log}")
    return 1 if "!!" in text else 0


if __name__ == "__main__":
    sys.exit(main())
