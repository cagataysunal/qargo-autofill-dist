"""The planning sheet "2026 - NEW 1 Planning.xlsx" (Google Sheets), read with a read-only Google service account.

Setup (once, by him, 21 Oct 2026): a Google Cloud project with the Sheets API on, a service account with a JSON
key, the sheet shared with the account's e-mail as Viewer. The key lives outside the code folder:

    ~/.config/qargo-autofill/google-sheets-key.json      (or QARGO_SHEETS_KEY=<path>)

A week tab ("Week 43-1") is one grid. Under each date five columns, one row per driver:

    Naam chauffeur | COMP. (the job: "ZAANDAM SIMON LOOS", "PIJN AH Corn", "Vredeveld" ...) | CHARTER | TRUCK | TRAILER

entries(day) gives those rows for one date, cell texts as written ("zm3", "OV32NV+ 32625/OK-65-BY" ...); what a
charter code on an order means is assign_trips.py's business.

Every answer from Google is waited for with a deadline; no answer is an error (SheetNoAnswer), never "empty".
"""
import base64, datetime, json, os, re, time, urllib.error, urllib.parse, urllib.request
from dataclasses import dataclass
from pathlib import Path

SHEET_ID = os.environ.get("QARGO_SHEET_ID") or "1_hYfgb8KsmcfU6VOavD6CN5bvGGOF2HaEUvb2tc7kDw"
KEY_FILE = Path(os.environ.get("QARGO_SHEETS_KEY") or Path.home() / ".config" / "qargo-autofill" / "google-sheets-key.json")
SCOPE = "https://www.googleapis.com/auth/spreadsheets.readonly"
ANSWER_S = 60
COLUMNS = ("driver", "comp", "charter", "truck", "trailer")


class SheetNoAnswer(Exception):
    """Google did not answer, refused, or the key / sharing is not set up: nothing may be concluded"""


@dataclass
class Entry:
    day: datetime.date
    row: int                    # sheet row number (1-based), for the report
    driver: str
    comp: str
    charter: str
    truck: str
    trailer: str


def tab_name(day):
    """the week tab with the charter columns: 'Week 43-1' (ISO week)"""
    return f"Week {day.isocalendar()[1]}-1"


def _b64(data):
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def access_token(key_file=KEY_FILE, now=None):
    """a 1-hour token for the service account (OAuth 2 JWT bearer, signed with its private key)"""
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    try:
        key = json.loads(Path(key_file).read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise SheetNoAnswer(f"NO SHEET KEY: {key_file} is missing (the Google service account's JSON key)")
    now = int(now or time.time())
    head = _b64(json.dumps({"alg": "RS256", "typ": "JWT"}).encode())
    claims = _b64(json.dumps({"iss": key["client_email"], "scope": SCOPE, "aud": key["token_uri"],
                              "iat": now, "exp": now + 3600}).encode())
    private = serialization.load_pem_private_key(key["private_key"].encode(), password=None)
    sig = private.sign(f"{head}.{claims}".encode(), padding.PKCS1v15(), hashes.SHA256())
    body = urllib.parse.urlencode({"grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                                   "assertion": f"{head}.{claims}.{_b64(sig)}"}).encode()
    return _call(urllib.request.Request(key["token_uri"], data=body, method="POST"), "the Google login")["access_token"]


def _call(req, what):
    try:
        with urllib.request.urlopen(req, timeout=ANSWER_S) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:300]
        if e.code in (403, 404):
            raise SheetNoAnswer(f"SHEET REFUSED ({e.code}) for {what}: is the sheet shared with the service account "
                                f"as Viewer, and the Sheets API enabled? {detail}")
        raise SheetNoAnswer(f"SHEET ERROR {e.code} for {what}: {detail}")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise SheetNoAnswer(f"NO ANSWER from Google for {what} within {ANSWER_S} s (internet?): {e}")


def read_tab(tab, token, sheet_id=SHEET_ID):
    """the tab's cells as text, as shown in the sheet: [[str]]"""
    rng = urllib.parse.quote(f"'{tab}'!A1:BZ1500", safe="")
    url = (f"https://sheets.googleapis.com/v4/spreadsheets/{sheet_id}/values/{rng}"
           f"?valueRenderOption=FORMATTED_VALUE&majorDimension=ROWS")
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    return _call(req, f"tab '{tab}'").get("values") or []


DATE_RE = re.compile(r"^\s*(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})\s*$")


def _date(cell):
    m = DATE_RE.match(cell or "")
    if not m:
        return None
    try:
        return datetime.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


def parse(grid):
    """[Entry] of a week tab: every block's header row ('Naam chauffeur', 'COMP.', ...) gives the five columns of each
    date; the date is the nearest date cell above that header, in one of those five columns"""
    cell = lambda r, c: (grid[r][c] if r < len(grid) and c < len(grid[r]) else "") or ""
    out, block = [], {}                                   # block: {first column: date}
    for r, row in enumerate(grid):
        heads = [c for c, v in enumerate(row) if (v or "").strip().lower().startswith("naam chauffeur")]
        if heads:
            block = {}
            for c in heads:
                for up in range(r - 1, max(-1, r - 4), -1):
                    d = next((_date(cell(up, k)) for k in range(c, c + 5) if _date(cell(up, k))), None)
                    if d:
                        block[c] = d
                        break
            continue
        if any(_date(v) for v in row):                    # the next block's title row with its dates
            block = {}
            continue
        if not block:
            continue
        for c, day in block.items():
            vals = [cell(r, c + i).strip() for i in range(5)]
            if any(vals):
                out.append(Entry(day, r + 1, *vals))
    return out


def entries(day, *, token=None, read=read_tab):
    """the sheet's rows for one date"""
    token = token or access_token()
    return [e for e in parse(read(tab_name(day), token)) if e.day == day]
