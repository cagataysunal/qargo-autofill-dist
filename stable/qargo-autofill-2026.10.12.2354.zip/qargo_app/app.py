"""One running program: where its data is, its settings, its log, "only one of me", the report for support -
and main(), which puts the server, the documents and the engine together.

Where things go is decided by paths.py: with QARGO_DATA_DIR (the launcher always sets it) everything is in that
folder; without it, next to the code, as the command line does (that is how the developer tries the window).
"""
import datetime, json, os, platform, queue, secrets, signal, sys, tempfile, threading, time, traceback, urllib.request, zipfile
from pathlib import Path
import paths
from . import texts
from .server import Store, make_server
from .documents import Batch, clean_old

BROWSERS = ("chromium", "chrome", "msedge")
REPORT_LOG_BYTES = 2_000_000         # of each log, the end
SWAP_TRIES, SWAP_WAIT = 10, 0.5      # write_whole: how long a file that is still open elsewhere is waited for


class App:
    def __init__(self):
        self.data = paths.data_dir()
        self.inbox = self.data / "inbox"                # our copies of the documents, one folder per day
        self.logs = paths.logs_dir()
        self.lock_file = self.data / "app.lock"
        self.settings_file = self.data / "settings.json"       # the launcher reads the language from it too
        self.version = os.environ.get("QARGO_VERSION") or "dev"
        browser = (os.environ.get(paths.ENV_BROWSER) or "chromium").lower()
        self.browser = browser if browser in BROWSERS else "chromium"
        self.profile = paths.profile_dir(self.browser)
        self.headless = os.environ.get("QARGO_HEADLESS") == "1"            # tests only
        self.debug_port = os.environ.get("QARGO_DEBUG_PORT")               # tests only: a second client drives the window
        self.settings = self.load_json(self.settings_file, {})
        lang = self.settings.get("lang")
        # no language kept yet (first start): the page picks the one of this computer and tells us
        self.store = Store(lang if lang in texts.LANGS else "en", self.version, lang_chosen=lang in texts.LANGS)
        self.token = secrets.token_urlsafe(32)
        self.cmds, self.cancel = queue.Queue(), threading.Event()
        self.log_lock, self.log_file = threading.Lock(), None
        self.done_lock = threading.RLock()
        self.done_unwritten = {}                # saved orders done.json could not take yet: order key -> address
        self.httpd = make_server(self)
        port = self.httpd.server_address[1]
        self.origin, self.hosts = f"http://127.0.0.1:{port}", {f"127.0.0.1:{port}", f"localhost:{port}"}
        self.batch = None
        self.owns_lock = False
        self.serving = False                    # serve() was called

    # ---- small files
    @staticmethod
    def load_json(path, default):
        try:
            value = json.loads(Path(path).read_text(encoding="utf-8-sig"))
            return value if isinstance(value, type(default)) else default
        except (OSError, ValueError):
            return default

    @staticmethod
    def write_whole(path, text):
        """never half a file: write next to it, then swap. Patient, as the launcher's replace() is: Windows
        refuses the swap while a virus scanner or another thread of ours still has the file open."""
        tmp = Path(str(path) + ".tmp")
        tmp.write_text(text, encoding="utf-8")
        for attempt in range(SWAP_TRIES):
            try:
                return os.replace(tmp, path)
            except PermissionError:
                if attempt == SWAP_TRIES - 1:
                    raise
                time.sleep(SWAP_WAIT)

    def save_settings(self, **kw):
        self.settings.update(kw)
        try:
            self.write_whole(self.settings_file, json.dumps(self.settings, indent=1, ensure_ascii=False))
        except OSError as e:
            self.log(f"settings not saved: {e}")

    def done_now(self):
        """done.json as it is now: {order key: its address in Qargo}. Read every time: the command line writes it too."""
        with self.done_lock:                    # never read it while mark_done() swaps it
            return {**self.load_json(paths.done_file(), {}), **self.done_unwritten}

    def mark_done(self, oid, url):
        """Never raises: the order IS in Qargo. When done.json cannot be written (Windows: the file is held by
        another program) the order is remembered here and written with the next one, or when the program closes."""
        with self.done_lock:
            self.done_unwritten[oid] = url
            try:
                self.write_whole(paths.done_file(), json.dumps(self.done_now(), indent=1))
                self.done_unwritten = {}
            except OSError as e:
                self.log(f"done.json not written ({type(e).__name__}: {e}); kept for the next try: {sorted(self.done_unwritten)}")

    # ---- log: fill_log_<start>.txt, where the command line's logs are; every line at once, so a crash loses nothing
    def log_line(self, line):
        with self.log_lock:
            try:
                if self.log_file is None:
                    self.log_file = open(self.logs / f"fill_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt", "a", encoding="utf-8")
                self.log_file.write(line + "\n")
                self.log_file.flush()
            except (OSError, ValueError):
                pass

    def log(self, msg):
        line = f"{datetime.datetime.now():%H:%M:%S} {msg}"
        try:
            print(line, flush=True)             # the launcher sends this to logs/app.log
        except (OSError, ValueError):
            pass
        self.log_line(line)

    # ---- only one of me: app.lock holds pid, port and token of the program that has the window
    def single_instance(self):
        """True: we are the one. False: another one runs; it was asked to bring its window to the front."""
        mine = json.dumps({"pid": os.getpid(), "port": self.httpd.server_address[1], "token": self.token})
        for _ in range(3):
            try:
                fd = os.open(self.lock_file, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError:
                other = self.load_json(self.lock_file, {})
                if self.ask_front(other):
                    return False
                try:                            # left behind by a program that is gone (crash, power cut)
                    os.unlink(self.lock_file)
                except OSError:
                    pass
                continue
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(mine)
            self.owns_lock = True
            return True
        return True                             # the file cannot be made: better two windows than none

    @staticmethod
    def ask_front(other):
        """the running program answers on its port (and only to who knows its token): ask for its window"""
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{int(other['port'])}/api/cmd", data=b'{"cmd": "raise"}',
                                         headers={"Cookie": f"qa_token={other['token']}", "Content-Type": "application/json"})
            with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(req, timeout=5) as r:
                return r.status == 202
        except Exception:
            return False

    def serve(self):
        self.serving = True
        threading.Thread(target=self.httpd.serve_forever, daemon=True, name="http").start()

    def started(self):
        """the control page is showing: tell the launcher (it then stops watching us)"""
        marker = os.environ.get("QARGO_STARTED_OK")
        if marker:
            try:
                Path(marker).parent.mkdir(parents=True, exist_ok=True)
                Path(marker).write_text(str(os.getpid()), encoding="utf-8")
            except OSError as e:
                self.log(f"started marker not written: {e}")

    def close(self):
        # shutdown() waits for serve_forever() to end: for ever, when that was never started
        for step in ((self.httpd.shutdown,) if self.serving else ()) + (self.httpd.server_close,):
            try:
                step()
            except Exception:
                pass
        if self.done_unwritten:                 # a last try for what done.json did not take
            self.mark_done(*next(iter(self.done_unwritten.items())))
        if self.owns_lock:
            try:
                if self.load_json(self.lock_file, {}).get("pid") == os.getpid():
                    os.unlink(self.lock_file)
            except OSError:
                pass
        with self.log_lock:
            if self.log_file:
                self.log_file.close()
                self.log_file = None

    # ---- "Save a report for support"
    def save_report(self):
        """A zip with the logs, the version, the system and the list as it is now - into the operator's Downloads
        folder, or else our own. Never the browser profile (the Qargo login), the documents, the orders or
        done.json; and no screenshots: they are pictures of half-filled orders (they stay in the logs folder)."""
        now = datetime.datetime.now()
        name = f"qargo-autofill-report-{now:%Y%m%d-%H%M%S}.zip"
        info = {"program": "Qargo Autofill", "version": self.version, "made": now.isoformat(timespec="seconds"),
                "system": platform.platform(), "machine": platform.machine(), "python": sys.version.split()[0],
                "browser": self.browser, "language": self.store.read(lambda s: s["lang"]),
                "installed": bool(os.environ.get(paths.ENV_DATA)),
                "screenshots_left_out": sorted(f.name for f in self.logs.glob("error_*.png"))}
        try:
            from importlib.metadata import version
            info["playwright"] = version("playwright")
        except Exception:
            pass
        files = sorted(self.logs.glob("fill_log_*.txt"))[-20:]
        if os.environ.get(paths.ENV_DATA):              # next to the code "*.log" could be anything
            files += sorted(self.logs.glob("*.log"))
            if os.environ.get("QARGO_HOME"):
                files.append(Path(os.environ["QARGO_HOME"]) / "install.log")
        for folder, where in ((paths.downloads_dir(), "downloads"), (self.data / "reports", "data")):
            try:
                if where == "data":
                    folder.mkdir(parents=True, exist_ok=True)
                with zipfile.ZipFile(folder / (name + ".part"), "w", zipfile.ZIP_DEFLATED) as z:
                    z.writestr("info.json", json.dumps(info, indent=1, ensure_ascii=False))
                    z.writestr("list.json", self.store.snapshot()[1])
                    for f in files:
                        try:
                            with open(f, "rb") as fh:
                                fh.seek(max(0, f.stat().st_size - REPORT_LOG_BYTES))
                                z.writestr("logs/" + f.name, fh.read())
                        except OSError:
                            pass
                os.replace(folder / (name + ".part"), folder / name)
            except OSError as e:
                self.log(f"report not written to the {where} folder: {type(e).__name__}: {e}")
                try:
                    (folder / (name + ".part")).unlink()
                except OSError:
                    pass
                continue
            self.log(f"report for support written: {name} ({where})")
            self.store.update(notice={"code": "report_" + where, "p": {"name": name}})
            return {"ok": True, "name": name, "where": where}
        self.store.update(notice={"code": "report_failed", "p": {}})
        return {"ok": False}


def main(filler=None):
    """the operator's window. filler: something else than qargo_fill.py to fill with (tests/fake_qargo.py)"""
    for name in ("stdout", "stderr"):                   # pythonw.exe has neither: give print() somewhere to go
        if getattr(sys, name) is None:
            setattr(sys, name, open(os.devnull, "w", encoding="utf-8"))
    app = App()
    try:
        if not app.single_instance():
            print("Qargo Autofill is already running: its window was asked to come to the front", flush=True)
            app.httpd.server_close()
            return 0
        app.batch = Batch(app)
        app.serve()                             # from here on a second start can ask for our window
        app.log(f"Qargo Autofill {app.version} on {platform.platform()}, browser {app.browser}"
                + (", data next to the code" if not os.environ.get(paths.ENV_DATA) else ""))
        switches = [k for k in ("QARGO_TENANT_URL", "QARGO_HEADLESS", "QARGO_DEBUG_PORT") if os.environ.get(k)]
        if switches:                                    # never on an operator's machine: say so where support reads first
            app.log("TEST SWITCHES in the environment: " + ", ".join(switches))
        try:
            clean_old(app)
        except Exception:
            app.log("CLEAN " + traceback.format_exc())
        from .engine import Engine                      # playwright is imported here, not for a second start
        if filler is None:
            from .filler import QargoFiller
            filler = QargoFiller()
        engine = Engine(app, filler)
        for sig in ("SIGINT", "SIGTERM", "SIGBREAK"):   # Windows has no SIGTERM to speak of: there Done and the window's X end us
            try:
                signal.signal(getattr(signal, sig), lambda *_: setattr(engine, "quit", True))
            except (AttributeError, ValueError, OSError):
                pass
        return engine.run()
    except Exception:
        app.log("APP " + traceback.format_exc())
        app.close()
        return 1


# ------------------------------------------------------------------ the checks the launcher runs
TINY_PDF_TEXT = "Qargo Autofill self-test 12345"


def tiny_pdf(text):
    """a one-page PDF with one line of text, made here: the self-test needs no file. Written out the long way
    (a line per keyword): pdfminer does not read the shortest legal spelling."""
    stream = f"BT /F1 14 Tf 50 700 Td ({text}) Tj ET"
    objs = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Count 1 /Kids [3 0 R] >>",
            "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
            f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream",
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"]
    out, offsets = b"%PDF-1.4\n", []
    for i, body in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n{body}\nendobj\n".encode("ascii")
    xref = len(out)
    out += b"xref\n0 6\n0000000000 65535 f \n" + b"".join(b"%010d 00000 n \n" % o for o in offsets)
    return out + b"trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % xref


def selftest():
    """exit code 0 when this installation can work: the modules import, pdf_layout reads a PDF, every string
    table loads and fits the English one, and Playwright starts and stops. No browser window, no network."""
    bad = []

    def step(name, fn):
        try:
            detail = fn()
            print(f"ok    {name}" + (f" ({detail})" if detail else ""), flush=True)
        except Exception as e:
            bad.append(name)
            print(f"FAIL  {name}: {type(e).__name__}: {e}", flush=True)

    def imports():
        import parse_trips, validate_orders, qargo_fill, housekeeping, run, messages, chat_import      # noqa: F401
        from . import engine, filler, documents, server                                                # noqa: F401

    def pdf():
        import pdf_layout                    # the installed app reads PDFs with this (pdfminer.six), on every system
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "selftest.pdf"
            path.write_bytes(tiny_pdf(TINY_PDF_TEXT))
            got = pdf_layout.pdf_layout_text(path)
        if TINY_PDF_TEXT not in got:
            raise ValueError(f"read {got!r}")

    def strings():
        wrong = texts.problems()
        if wrong:
            raise ValueError("; ".join(wrong[:3]))
        if "{LANGUAGE}" in texts.photo_prompt("bg") or "{PROBLEMS}" in texts.correction(["x"]):
            raise ValueError("photo_prompt.txt: a placeholder was not filled in")
        if "/*STRINGS*/{}" not in (texts.HERE / "page.html").read_text(encoding="utf-8"):
            raise ValueError("page.html has no place for the string tables")
        return f"{len(texts.LANGS)} languages, {len(texts.tables()['en'])} sentences"

    def playwright():
        from playwright.sync_api import sync_playwright
        sync_playwright().start().stop()

    step("the program's modules import", imports)
    step("pdf_layout reads a PDF", pdf)
    step("string tables", strings)
    step("Playwright starts and stops", playwright)
    return 1 if bad else 0


def browser_smoke(name):
    """exit code 0 when this browser opens a page without a window, with a profile folder of its own"""
    name = (name or "").lower()
    if name not in BROWSERS:
        print(f"FAIL  unknown browser {name!r}: one of {', '.join(BROWSERS)}", flush=True)
        return 2
    try:
        import qargo_fill
        from playwright.sync_api import sync_playwright
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as profile, sync_playwright() as p:
            ctx = qargo_fill.open_browser(p, profile, channel=name, headless=True)
            try:
                page = ctx.pages[0] if ctx.pages else ctx.new_page()
                page.goto("data:text/html,<title>qargo-autofill</title><p>ok</p>")
                title, version = page.title(), ctx.browser.version if ctx.browser else "?"
            finally:
                ctx.close()
        if title != "qargo-autofill":
            raise ValueError(f"page title {title!r}")
        print(f"ok    {name} {version}", flush=True)
        return 0
    except Exception as e:
        print(f"FAIL  {name}: {type(e).__name__}: {str(e).splitlines()[0][:300]}", flush=True)
        return 1
