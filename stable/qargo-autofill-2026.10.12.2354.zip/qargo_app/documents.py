"""Documents in, orders out: everything between a dropped file and a row of the list.

No browser here: this runs on the HTTP threads and on one reader thread. The operator's own files are never
moved or deleted; the program keeps a copy of each in <data>/inbox/<date>/ (the bot attaches that copy to the
order) and deletes copies older than 14 days.

PDFs are always read as ONE batch with parse_trips.parse_paths, every time a document is added: a coupling place
on one document is resolved with an address printed on another, so reading them one by one gives other orders.
"""
import datetime, hashlib, json, os, re, shutil, threading, time, traceback, urllib.parse
from pathlib import Path
import paths, parse_trips, validate_orders, messages, chat_import
from . import texts
from .server import FRESH

PDF = (".pdf",)
PHOTO = (".jpg", ".jpeg", ".png", ".heic", ".heif", ".webp")
KEEP_INBOX_DAYS = 14          # the copies of the documents
KEEP_LOG_DAYS = 30
DAY = re.compile(r"\d{4}-\d{2}-\d{2}")


def safe_name(name):
    """the file's own name, never a path, whatever the browser sends; kept as it is where Windows allows it,
    because the order names its document by this name and the bot attaches it under it"""
    name = Path(urllib.parse.unquote(name or "").replace("\\", "/")).name
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .") or "document"
    stem, ext = Path(name).stem, Path(name).suffix
    return stem[:140 - len(ext)] + ext


def free_name(folder, name):
    """name, or 'stem (2).pdf', 'stem (3).pdf'... if the folder already has it"""
    p, n = folder / name, 2
    while p.exists():
        p = folder / f"{Path(name).stem} ({n}){Path(name).suffix}"
        n += 1
    return p


def order_id(o):
    key = o.get("key") if isinstance(o, dict) else None
    return key.strip() if isinstance(key, str) and key.strip() else None


def check(order, dirs):
    """the validator on ONE order: (errors, warnings) as its own messages. It can crash on a malformed order
    (a number where it expects text); that order then simply cannot be filled, the others are not touched."""
    try:
        errors, warnings = validate_orders.validate([order], dirs)
    except Exception as e:
        return [f"validator crashed: {type(e).__name__}: {e}"], []
    return [m for _, m in errors], [m for _, m in warnings]


def unique(rs):
    """each sentence once. Two reasons are the same sentence when they differ only in a parameter their sentence
    does not show (the missing document, told by the validator for the order and by the bot at a stop)."""
    seen, out = set(), []
    for r in rs:
        shows = set(texts.PLACEHOLDER.findall(texts.tables()["en"].get("r." + r["code"], "")))
        mark = (r["code"], json.dumps({k: v for k, v in r["p"].items() if k in shows}, sort_keys=True, default=str))
        if mark not in seen:
            seen.add(mark)
            out.append(r)
    return out


def reasons(raw, origin, stop=None):
    """raw messages -> what the page shows, each sentence once"""
    return unique(r for r in (messages.reason(m, origin, stop) for m in raw) if messages.SEVERITY.get(r["code"]) != "info")


def row(oid, o, origin, errors, warnings):
    """the line the page shows for one order. Never the whole order: that stays in Store.full"""
    def g(d, *keys):
        for k in keys:
            d = d.get(k) if isinstance(d, dict) else None
        return d
    cons = o.get("consignments") if isinstance(o.get("consignments"), list) else []
    first = o.get("setup") or g(cons[0] if cons else {}, "pickup") or {}
    picks = {json.dumps(g(c, "pickup"), sort_keys=True, default=str) for c in cons if isinstance(c, dict)}
    text = lambda v, default="?": v if isinstance(v, str) and v else default
    return {"id": oid, "customer": text(o.get("customer")), "reference": text(o.get("customer_reference")),
            "date": text(g(first, "date"), ""), "time": text(g(first, "start") or g(first, "end"), ""),
            "stops": len(picks) + len(cons) + bool(o.get("setup")) + bool(o.get("teardown")),
            "origin": origin, "status": "invalid" if errors else "ready",
            "reasons": reasons(errors or warnings, origin), "step": None, "qargo": None,
            # which reading of the documents this row is (support: two machines, the same PDFs, the same marks?)
            "sig": hashlib.sha1(json.dumps(o, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()[:10]}


class Batch:
    """this session's documents and the orders read from them"""
    def __init__(self, app):
        self.app, self.st = app, app.store
        self.lock = threading.RLock()           # the lists below
        self.build_lock = threading.Lock()      # one rebuild of the list at a time: the last one to start wins
        self.parse_lock = threading.Lock()      # parse_trips keeps a module global: one reading at a time
        self.docs = []            # {"name", "path", "sha", "kind": "pdf" | "photo"} in the order they came
        self.parsed = []          # the orders of all PDFs, as parse_paths gave them for the whole batch
        self.pdf_unread = []      # PDFs of the batch that gave no orders: {"name", "code"}
        self.other_unread = []    # files we did not keep (wrong kind, too big, not an orders file)
        self.extra = {}           # order id -> (order, origin): orders files and chatbot answers, as they came
        self.notes = {}           # order id -> our own "app: ..." notes (they count as doubts, like the validator's)
        self.removed = set()      # orders the operator took off the list
        self.wake, self.more_until = threading.Event(), 0.0
        threading.Thread(target=self._reader, daemon=True, name="reader").start()

    # ---- files coming in
    def take(self, name, data, more=False, as_photo=False):
        """one dropped or chosen file. more: the page is sending further files of the same drop right now.
        as_photo: chosen on the photo screen (a scan may be a PDF: it is kept for the order, not read)"""
        name = safe_name(name)
        ext = Path(name).suffix.lower()
        if ext == ".json" and not as_photo:
            return self.take_orders_file(name, data)
        if ext not in PDF + PHOTO:
            self.unread(name, "wrong_type")
            return {"ok": False, "code": "wrong_type"}
        doc, _ = self.keep(name, data, "photo" if as_photo or ext in PHOTO else "pdf")
        if as_photo or doc["kind"] == "photo":
            return {"ok": True, "photo": doc["name"]}
        self.read_soon(more)
        return {"ok": True}

    def keep(self, name, data, kind):
        """our own copy of a document in inbox/<today>/; the same file twice is one document. -> (doc, new?)"""
        sha = hashlib.sha256(data).hexdigest()
        with self.lock:
            old = next((d for d in self.docs if d["sha"] == sha), None)
            if old:
                return old, False
            day = self.app.inbox / datetime.date.today().isoformat()
            day.mkdir(parents=True, exist_ok=True)
            path = day / name
            if not (path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == sha):   # else: kept earlier today
                path = free_name(day, name)
                path.write_bytes(data)
            doc = {"name": path.name, "path": path, "sha": sha, "kind": kind}
            self.docs.append(doc)
            self.app.log(f"document kept: {path.name} ({len(data)} bytes, {kind})")
            return doc, True

    def unread(self, name, code):
        name = safe_name(name)
        with self.lock:
            self.other_unread = [u for u in self.other_unread if u["name"] != name] + [{"name": name, "code": code}]
        self.app.log(f"not taken: {name} ({code})")
        self.rebuild()

    def doc_dirs(self):
        """where the bot and the validator look for an order's document: the folders of this session's copies"""
        with self.lock:
            return list(dict.fromkeys(d["path"].parent for d in reversed(self.docs))) \
                or [self.app.inbox / datetime.date.today().isoformat()]

    # ---- reading the PDFs (the reader thread)
    def read_soon(self, more=False):
        self.st.update(reading=True)          # the page hides Start until the list is up to date again
        self.more_until = time.time() + 3 if more else 0.0
        self.wake.set()

    def _reader(self):
        while True:
            self.wake.wait()
            while time.time() < self.more_until:      # the rest of the same drop is on its way: read once, not 20 times
                time.sleep(0.05)
            self.wake.clear()
            try:
                self.read()
            except Exception:
                self.app.log("READER " + traceback.format_exc())
                self.st.update(problem="unexpected")
            if not self.wake.is_set():
                self.st.update(reading=False)

    def read(self):
        """the WHOLE batch through the parser again, then the list"""
        with self.lock:
            pdfs = sorted((d for d in self.docs if d["kind"] == "pdf"), key=lambda d: (d["name"], str(d["path"])))
        self.app.log(f"reading {len(pdfs)} document(s) together: {[d['name'] for d in pdfs]}")
        with self.parse_lock:
            orders, skipped = parse_trips.parse_paths([str(d["path"]) for d in pdfs]) if pdfs else ([], [])
        unread, no_tool = [], False
        for entry in skipped:                 # "name" (unknown layout) or "name (ExcType: message)"
            self.app.log(f"not read: {entry}")
            if "(PdfToolMissing:" in entry:
                no_tool = True                # one clear message, not a row per document
            elif any(entry == d["name"] for d in pdfs):
                unread.append({"name": entry, "code": "unknown_layout"})
            else:
                name = next((d["name"] for d in pdfs if entry.startswith(d["name"] + " (")), entry.split(" (")[0])
                unread.append({"name": name, "code": "read_error"})
        with self.lock:
            self.parsed, self.pdf_unread = orders, unread
        if no_tool:
            self.st.update(problem="pdf_tool_missing")
        elif self.st.read(lambda s: s["problem"]) == "pdf_tool_missing":
            self.st.update(problem=None)
        self.rebuild()

    def rebuild(self):
        """the list again from everything this session holds: leave out what done.json has and what came twice,
        validate each order by itself. Rows the bot already worked on stay exactly as they are."""
        with self.build_lock:
            with self.lock:
                cand = [(o, "pdf") for o in self.parsed] + list(self.extra.values())
                unread = self.pdf_unread + self.other_unread
                removed, notes, dirs = set(self.removed), dict(self.notes), self.doc_dirs()
            done = self.app.done_now()
            worked = self.st.read(lambda s: {o["id"] for o in s["orders"] if o["status"] not in FRESH})
            new, seen, already, dupes = [], set(), 0, 0
            for n, (o, origin) in enumerate(cand):
                oid = order_id(o) or f"?{n + 1}"
                if oid in seen:
                    dupes += 1                # the same order from a second document ("x.pdf" and "x (1).pdf")
                    continue
                seen.add(oid)
                if oid in worked:
                    new.append((oid, None, None))             # the bot has it: its row stays, whatever was read now
                elif oid in removed:
                    continue
                elif oid in done:
                    already += 1
                else:
                    errors, warnings = check(o, dirs)
                    warnings += notes.get(oid, [])
                    for m in errors + warnings:
                        self.app.log(f"validate {oid}: {m}")
                    new.append((oid, row(oid, o, origin, errors, warnings),
                                {"order": o, "origin": origin, "warnings": warnings}))

            def put(s):
                old, rows = {r["id"]: r for r in s["orders"]}, []
                for oid, r, full in new:
                    cur = old.get(oid)
                    if cur is not None and (cur["status"] not in FRESH or r is None):
                        rows.append(cur)      # (also when the engine started on it while we were validating)
                    elif r is not None:
                        rows.append(r)
                        self.st.full[oid] = full
                rows += [r for r in s["orders"] if r["status"] not in FRESH and not any(x["id"] == r["id"] for x in rows)]
                for oid in [k for k in self.st.full if not any(r["id"] == k for r in rows)]:
                    del self.st.full[oid]
                s.update(orders=rows, unread=unread, left={"already": already, "dupes": dupes})
            self.st.update(put)

    # ---- orders that do not come from our parser
    def take_orders_file(self, name, data):
        """a .json file in the format of SCHEMA.md (made by parse_trips.py or by hand): taken as it is"""
        try:
            value = json.loads(data.decode("utf-8-sig"))
        except ValueError:                                        # also UnicodeDecodeError
            self.unread(name, "read_error")
            return {"ok": False, "code": "read_error"}
        orders = [value] if isinstance(value, dict) else value
        if not isinstance(orders, list) or not orders or not all(isinstance(o, dict) for o in orders):
            self.unread(name, "wrong_type")
            return {"ok": False, "code": "wrong_type"}
        self.app.log(f"orders file {name}: {len(orders)} order(s)")
        return {"ok": True, "added": self.add_extra(orders, "file", name)}

    def add_extra(self, orders, origin, tag):
        with self.lock:
            ids = []
            for n, o in enumerate(orders):
                oid = order_id(o) or f"?{tag}#{n + 1}"
                self.extra[oid] = (o, origin)
                self.removed.discard(oid)
                self.notes.pop(oid, None)
                ids.append(oid)
        self.rebuild()
        return ids

    def import_answer(self, text, photos=(), driver="", customer=""):
        """a chatbot's answer to photo_prompt.txt -> orders in the list, or what is wrong with it in plain words.
        photos: the names take() gave for the photos the operator chose; the first one is attached to the order."""
        with self.lock:
            photos = [p for p in photos if any(d["name"] == p for d in self.docs)]
        refuse = lambda code, **p: {"ok": False, "problems": [{"code": code, "p": p}], "fix": ""}
        if not photos:
            return refuse("import.no_photo")
        try:
            orders = chat_import.import_chat_answer(text, photos[0], driver.strip() or None, customer.strip() or None,
                                                    log=self.app.log)
        except chat_import.ImportProblem as e:
            self.app.log(f"chatbot answer refused: {e}")
            return refuse(e.key)
        unknown = [o["customer"] for o in orders if o["customer"] not in chat_import.CUSTOMERS]
        if unknown:                                               # the bot could not pick such a customer in Qargo
            self.app.log(f"chatbot answer: unknown customer {unknown[0]!r}")
            return {"ok": False, "need_customer": unknown[0] or "?", "choices": list(chat_import.CUSTOMERS),
                    "problems": [], "fix": ""}
        problems, lines = [], []
        for o in orders:
            errors, _ = check(o, None)
            lines += [f"{o['key']}: {m}" for m in errors]
            problems += [r for r in reasons(errors, "photo") if r not in problems]
        if problems:
            for line in lines:
                self.app.log(f"chatbot answer: {line}")
            return {"ok": False, "problems": problems, "fix": texts.correction(lines)}
        ids = self.add_extra(orders, "photo", "photo")
        if len(photos) > 1:
            with self.lock:
                for oid in ids:
                    self.notes[oid] = [f"app: only the first of {len(photos)} photos is attached"]
            self.rebuild()
        listed = self.st.read(lambda s: [o["id"] for o in s["orders"]])
        return {"ok": True, "added": [i for i in ids if i in listed], "already": len([i for i in ids if i not in listed])}

    # ---- taking things off the list
    def remove(self, oid):
        with self.lock:
            self.removed.add(oid)
            self.extra.pop(oid, None)
        self.st.update(lambda s: s.update(orders=[o for o in s["orders"] if not (o["id"] == oid and o["status"] in FRESH)]))

    def remove_doc(self, name):
        with self.lock:
            gone = [d for d in self.docs if d["name"] == name and any(u["name"] == name for u in self.pdf_unread)]
            self.docs = [d for d in self.docs if d not in gone]            # our copy stays in the inbox until it is 14 days old
            self.pdf_unread = [u for u in self.pdf_unread if u["name"] != name]
            self.other_unread = [u for u in self.other_unread if u["name"] != name]
        self.rebuild()



def clean_old(app, today=None):
    """Our own copies and logs do not stay forever: inbox folders after 14 days, logs, screenshots and reports
    after 30. Deleted, not put in the Trash: the documents are the operator's own files' copies, and attached
    to the orders in Qargo. Only names this program writes itself are touched."""
    today = today or datetime.date.today()
    gone = []
    for d in sorted(app.inbox.glob("*")):
        try:
            if d.is_dir() and DAY.fullmatch(d.name) and datetime.date.fromisoformat(d.name) < today - datetime.timedelta(days=KEEP_INBOX_DAYS):
                shutil.rmtree(d, ignore_errors=True)
                gone.append(f"inbox/{d.name}")
        except ValueError:
            pass
    limit = datetime.datetime.combine(today, datetime.time()).timestamp() - KEEP_LOG_DAYS * 86400
    # Next to the code (no QARGO_DATA_DIR) the logs folder is the command line's: its old logs and screenshots
    # go to the Trash by housekeeping.tidy(), where they can be taken back. Never deleted from here.
    ours = (("fill_log_*.txt", "error_*.png") if os.environ.get(paths.ENV_DATA) else ())
    for folder, patterns in ((app.logs, ours), (app.data / "reports", ("qargo-autofill-report-*.zip",))):
        for pattern in patterns:
            for f in sorted(folder.glob(pattern)):
                try:
                    if f.is_file() and f.stat().st_mtime < limit:
                        f.unlink()
                        gone.append(f.name)
                except OSError:
                    pass
    if gone:
        app.log(f"old copies and logs deleted: {gone}")
    return gone
