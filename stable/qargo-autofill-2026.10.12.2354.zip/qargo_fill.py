#!/usr/bin/env python3
"""Fill Qargo "Create order" forms from orders.json (made by parse_trips.py).

Each order is filled in its own browser tab and left open for review. Nothing is
saved unless you pass --save.

  python3 qargo_fill.py orders.json                 # all orders, review + Save yourself
  python3 qargo_fill.py orders.json --only CT-3991420 SL-7173602
  python3 qargo_fill.py orders.json --customer Cornelissen
  python3 qargo_fill.py orders.json --save          # also press Save (after you trust it)

First run: a Chromium window opens; log in to Qargo there, then press Enter in the
terminal. The login is kept in ./.qargo-profile for next time.
"""
import argparse, json, os, re, sys, time, datetime, difflib, unicodedata
from pathlib import Path
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate_orders import validate, find_source
import paths

# QARGO_TENANT_URL is for tests only: it points the bot at a local stand-in instead of Qargo
TENANT_URL = (os.environ.get("QARGO_TENANT_URL") or "https://app.qargo.com/denis-express").rstrip("/")
LOG_LINES = []
# For a program that drives the filling itself (the app's window) instead of main():
LOG_SINK = None     # callable(line): gets every log line after it is printed
STEP_HOOK = None    # callable(ctx, label): called before each step of an order; may raise Cancelled

class Cancelled(BaseException):
    """raised from STEP_HOOK to stop the order being filled. A BaseException on purpose: soft() and the
    per-order `except Exception` must let it through"""

def log(msg):
    line = f"{datetime.datetime.now():%H:%M:%S} {msg}"
    print(line, flush=True)
    LOG_LINES.append(line)
    if LOG_SINK:
        LOG_SINK(line)

def norm(s):
    # accents folded: the document prints "Australiehavenweg", Qargo has "Australiëhavenweg"
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().upper()
    s = re.sub(r"\b(NL|BE|DE)-", "", s)
    return re.sub(r"[^A-Z0-9]", "", s)

# ------------------------------------------------------------------ helpers
def by_id(page, el_id):
    # .first: shared stops (start/end) are rendered once per consignment row with the same id
    return page.locator(f'[id="{el_id}"]').first

def field_box(scope, el_id):
    """the block around a form field (Qargo renders the visible textarea/number input next to the id'd combobox)"""
    return scope.locator(f'[id="{el_id}"]').locator("xpath=ancestor::div[contains(concat(' ', normalize-space(@class), ' '), ' form-field ')][1]/..")

def field_textarea(scope, el_id):
    return field_box(scope, el_id).locator("textarea").first

def fill_field(scope, el_id, value):
    """Fill a Qargo form field. Some fields show a separate textarea / number input next to the
    id'd (hidden-ish) combobox, e.g. Ritnummer -> input#Ritnummer[role=spinbutton]."""
    visible = field_box(scope, el_id).locator("textarea, input[role=spinbutton]")
    target = visible.first if visible.count() else scope.locator(f'[id="{el_id}"]')
    target.fill(str(value), timeout=8000)

def visible_dropdown_options(page):
    return page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option")

def choose_static(page, input_id, text):
    sel = by_id(page, input_id).locator("xpath=ancestor::div[contains(@class,'ant-select')][1]")
    sel.click()
    opt = visible_dropdown_options(page).filter(has_text=re.compile(r"^\s*" + re.escape(text) + r"\s*$"))
    opt.first.click()
    page.wait_for_timeout(250)

def menu_item(page, text):
    item = page.locator(".ant-dropdown:not(.ant-dropdown-hidden) .ant-dropdown-menu-item").filter(
        has_text=re.compile(r"^\s*" + re.escape(text) + r"\s*$"))
    item.first.wait_for(state="visible", timeout=5000)
    item.first.click()
    page.wait_for_timeout(300)

def read_options(page, input_id):
    """[{name, address, recent, idx}] for the location dropdown of input_id"""
    return page.evaluate("""(id) => {
        const lb = document.getElementById(id + '_list');
        if (!lb) return [];
        return [...lb.querySelectorAll('[role=option]')].map((o, idx) => {
            const ell = [...o.querySelectorAll('.ellipsis')].map(e => e.getAttribute('title') || e.textContent);
            return {idx, id: o.id, name: ell[0] || o.textContent, address: ell[1] || '',
                    recent: !!o.querySelector('svg[aria-label=time]'), text: o.textContent};
        });
    }""", input_id)

def hint_tokens(name):
    toks = re.findall(r"[A-Za-z&@]{3,}|\d{3,}", name or "")
    stop = {"ALBERT", "HEIJN", "THE", "NETHERLANDS", "LOGISTICS", "DEPOT", "B.V", "TRANSPORT"}
    return [t.upper() for t in toks if t.upper() not in stop]

# Where Qargo has several records for one address, use this one: the start of its display name
# (only the display name: the record's own name can be renamed, e.g. DCZ's went from "Hoofdtocht 1" to
# the DC name on 9 Oct, which made the old "... (Hoofdtocht 1)" entry miss and pick "AH Winkel 1").
PREFERRED = {
    "5015BZ": "Albert Heijn Distribution Centre Tilburg",          # DCT Pegasusweg 1
    "1507CJ": "Albert Heijn Distributiecentrum Zaandam (DCZ)",     # DCZ and DCM (also "AH Winkel 1" there)
    "1551NC": "RETOURENCENTRUM ZAANDAM",                           # Kleine Steng 10 (also K&N MCZ)
    "3606AS": "Retourencentrum Maarsen Simon Loos",                # Industrieweg 24 (also K&N MCM)
    "2645EG": "Albert Heijn Distributiecentrum Pijnacker (DCP)",   # Laan van Ruyven 1 (renamed from "AH Winkel 75")
}
# Same, by the name on the document, whatever postcode it carries: a Cornelissen coupling place has no
# postcode and borrows one from a stop on the same street, e.g. "DCP Laan van Ruyven 1" got K&N MCP's 2645EE.
PREFERRED_BY_NAME = [
    (re.compile(r"^(DCP\b|Albert Heijn DC (Delfgauw|Pijnacker)\b)", re.I), "Albert Heijn Distributiecentrum Pijnacker (DCP)"),
]

def country_of(address):
    m = re.search(r"\b([A-Z]{2})-", address or "")
    return m.group(1) if m else None

def wait_options(page, input_id, timeout=6.0):
    """poll the dropdown until results stop changing (or timeout); returns the options"""
    deadline, last, same = time.time() + timeout, None, 0
    opts = []
    while time.time() < deadline:
        page.wait_for_timeout(350)
        opts = read_options(page, input_id)
        sig = tuple(o["id"] + o["name"] for o in opts)
        same = same + 1 if sig == last else 0
        last = sig
        if opts and same >= 2:
            break
        if not opts and same >= 6:      # ~2s of "no results"
            break
    return opts

def street_parts(s):
    """street name and house number, comparable across spellings:
    "'t Spil 37" / "Het Spil 37" -> ("het spil", "37"); "Burg. D. Kooimanweg 16, NL-..." -> ("burgemeester kooimanweg", "16")"""
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower().split(",")[0]
    m = re.search(r"\d+", s)
    s = re.sub(r"(^|\s)'t\s", r"\1het ", " " + s)
    s = re.sub(r"\bburg\b\.?", "burgemeester", s)
    s = re.sub(r"\b[a-z]\.\s*", " ", s)                       # initials: "D."
    name = re.sub(r"[^a-z]+", " ", re.sub(r"\d.*$", "", s))     # the name: everything before the number
    return re.sub(r"\s+", " ", name).strip(), (m.group(0) if m else None)

def street_similarity(a, b):
    a, b = a.replace(" ", ""), b.replace(" ", "")
    return difflib.SequenceMatcher(None, a, b).ratio() if a and b else 0.0

def qargo_postcode(address):
    """'Pakketweg 2, NL-5145 ND Waalwijk' -> '5145ND'; None when the record has no postcode"""
    m = re.search(r"\b[A-Z]{2}-(\d{4,5})(?:\s?([A-Z]{2}))?\b", address or "")
    return (m.group(1) + (m.group(2) or "")) if m else None

def pick_candidates(opts, loc):
    """return (candidates, note) for one result list; note = None or (level, text): level "check" is a warning
    (a person must look; --save won't save), "note" only goes in the log (same place, written differently)"""
    pc = norm(loc.get("postcode"))
    street_n = norm(loc.get("street"))
    store = loc.get("store")
    overrides_file = paths.overrides_file()      # optional {"<query>|<postcode>": "<exact Qargo name>"}
    overrides = json.loads(overrides_file.read_text(encoding="utf-8-sig")) if overrides_file.exists() else {}
    by_name = next((n for rx, n in PREFERRED_BY_NAME if rx.search(loc.get("name") or "")), None)
    want_name = overrides.get(f"{loc['query']}|{loc.get('postcode')}") or by_name or PREFERRED.get(pc)
    # never use a fuel station or a record in another country
    usable = [o for o in opts
              if ("SHELL" not in o["name"].upper() or "SHELL" in (loc.get("name") or "").upper())
              and (country_of(o["address"]) in (None, loc.get("country", "NL")))]
    if want_name:
        c = [o for o in usable if o["name"].strip().startswith(want_name)]
        if c:
            return c, None
        # not in these results: try the next search, and in the end say NO LOCATION. Never pick another
        # record for a place that has its own (renamed? deleted?) - that is how "AH Winkel 1" got picked.
        return [], None
    if store:
        mine = [o for o in usable if re.search(rf"\b(Winkel|Albert Heijn|AH)\s+{store}\b", o["name"], re.I)]
        same_street = [o for o in mine if street_n and street_n in norm(o["address"])]
        if same_street:
            return same_street, None
        if mine:
            # no exact match: the record on the most similar street ("Het Spil 37" = "'t Spil 37"), not simply
            # the unloading-address record (SL-7176261 got "AH Winkel 2261 unloading adress" / Lijnbaan that way)
            doc_name, doc_nr = street_parts(loc.get("street"))
            scored = sorted(mine, key=lambda o: street_similarity(doc_name, street_parts(o["address"])[0]), reverse=True)
            best = scored[0]
            q_name, q_nr = street_parts(best["address"])
            if street_similarity(doc_name, q_name) >= 0.8:
                if doc_nr and q_nr and doc_nr != q_nr:
                    return [best], ("check", f"store {store}: house number differs: document '{loc.get('street')}', "
                                             f"Qargo '{best['address']}'")
                what = "Qargo record has no house number" if doc_nr and not q_nr else "street written differently"
                return [best], ("note", f"store {store}: {what}: document '{loc.get('street')}', Qargo '{best['address']}'")
            unloading = [o for o in mine if "unloading" in o["name"].lower()]
            c = unloading or mine
            return c, ("check", f"store {store}: document street '{loc.get('street')}', Qargo '{c[0]['address']}'")
    if pc:
        c = [o for o in usable if pc in norm(o["address"]) or pc in norm(o["name"])]
        if c:
            # the postcode alone is not proof: VRD-220670 'GAMMA Gouda, Elburgplein 7, 2803PX' got the record
            # 'GAMMA Elburg / Westerlengte 2, NL-2803 PX Gouda'. Records on the document's street come first;
            # when there is none, a person must look.
            doc_name, doc_nr = street_parts(loc.get("street"))
            def same_street(o):
                q_name, q_nr = street_parts(o["address"])
                return street_similarity(doc_name, q_name) >= 0.8 and (not doc_nr or not q_nr or doc_nr == q_nr)
            good = [o for o in c if same_street(o)]
            if good or not doc_name:
                return good or c, None
            return c, ("check", f"same postcode but another street: document '{loc.get('street')}' "
                                f"({loc.get('name')}), Qargo '{c[0]['name']} / {c[0]['address']}'")
    c = [o for o in usable if street_n and street_n in norm(o["address"] + o["name"])]
    if c:
        if not pc:
            return c, None
        qpc = qargo_postcode(c[0]["address"])
        # same street name in another town is another place: VRD-220697 'GAMMA Epe, De Meent 19, 8161ZN Epe' got
        # 'AH Winkel 8778 / De Meent 19, NL-1218 CB Hilversumse Meent'. Never pick it; try the next search.
        city = norm(loc.get("city"))
        if qpc and qpc[:4] != pc[:4] and city and city not in norm(c[0]["address"]):
            return [], None
        text = f"postcode differs for '{loc['street']}': document {loc.get('postcode')}, Qargo '{c[0]['address']}'"
        # same street + number; the record has no postcode, or only the letters differ: same place
        return c, ("note" if qpc is None or qpc[:4] == pc[:4] else "check", text)
    return [], None

def choose_location(page, inp, input_id, loc, ctx):
    """Search a Qargo location and pick the matching record. Tries the store number, then the
    street, then the name. Returns what was chosen, or None."""
    queries = [loc["query"]]
    mq = re.match(r"^(.*?\d+)", loc.get("street") or "")
    # last: the name without store numbers ("ACTION 2014 Temse" -> "ACTION Temse"; Qargo has "Action Temse").
    # Still only picked on a postcode / street match, so a name search can't pick another place.
    bare = "" if loc.get("store") else re.sub(r"\s+", " ", re.sub(r"\b\d+\b", " ", loc.get("name") or "")).strip()
    # very last: the postcode, written as Qargo indexes it ("1046 BP"). The street search misses a record whose
    # street is spelt differently (PN-B-008663-0085: "Australiehavenweg 100" vs Qargo's "Australiëhavenweg 100").
    pc = norm(loc.get("postcode"))
    pc_q = f"{pc[:4]} {pc[4:]}" if re.fullmatch(r"\d{4}[A-Z]{2}", pc) else pc
    for q in (mq.group(1) if mq else loc.get("street"), loc.get("name"), bare, pc_q):
        if q and q not in queries:
            queries.append(q)
    seen = []
    for q in queries:
        inp.click()
        inp.fill("")
        inp.press_sequentially(q, delay=10)
        opts = wait_options(page, input_id)
        seen += [o["name"] + " / " + o["address"] for o in opts][:4]
        cands, note = pick_candidates(opts, loc)
        if not cands:
            continue
        if note and note[1].startswith("same postcode but another street") and can_create(loc, ctx):
            continue                                 # not this address: it gets a record of its own below
        if note and note[0] == "check":
            ctx["warnings"].append("CHECK " + note[1])
        elif note:
            ctx.setdefault("notes", []).append(note[1])
        hints = hint_tokens(loc.get("name"))
        def score(o):
            t = norm(o["name"] + " " + o["address"])
            return (sum(1 for h in hints if norm(h) in t), o["recent"])
        cands.sort(key=score, reverse=True)
        best = cands[0]
        if len(cands) > 1 and score(cands[0]) == score(cands[1]) and cands[0]["name"] != cands[1]["name"]:
            ctx["warnings"].append(f"AMBIGUOUS location '{q}': picked '{best['name']}', "
                                   f"also: {[c['name'] for c in cands[1:4]]}")
        # click through JS: the dropdown can open above the field / outside the visible area
        page.evaluate("id => document.getElementById(id).click()", best["id"])
        page.wait_for_timeout(300)
        return f"{best['name']} / {best['address']}"
    if can_create(loc, ctx):
        made = create_location(page, inp, input_id, loc, ctx)
        if made:
            return made
    ctx["warnings"].append(f"NO LOCATION for {loc.get('name')!r} ({loc.get('street')}, {loc.get('postcode')} "
                           f"{loc.get('city')}); tried {queries}; seen: {seen[:6]}")
    inp.fill("")
    page.keyboard.press("Escape")
    return None

# ---- --create-locations: an address Qargo does not have gets a new location record ("Add location manually")
COUNTRY_NAMES = {"NL": "Netherlands", "BE": "Belgium", "DE": "Germany"}
CREATED = {}        # (street, postcode) -> name, for this run: never create the same address twice
DRAWER_READ_JS = """d => { const g = id => { const e = d.querySelector('[id="' + id + '"]'); return e ? e.value : '' };
    const c = d.querySelector('[id="country"]'), b = c && c.closest('.ant-select'), i = b && b.querySelector('.ant-select-selection-item');
    return {name: g('name'), address: g('address'), postcode: g('postal_code'), city: g('city'),
            country: i ? i.textContent.trim() : '', lat: g('latitude'), lon: g('longitude')} }"""

def can_create(loc, ctx):
    """only a full, printed address: never an AH store (Qargo names those 'AH Winkel <nr>'), a guessed one-line
    address, or an address without postcode or house number"""
    return bool(ctx.get("create_locations") and not loc.get("store") and not loc.get("unverified")
                and loc.get("postcode") and loc.get("city") and street_parts(loc.get("street"))[1]
                and loc.get("country", "NL") in COUNTRY_NAMES)

def selected_location(page, input_id):
    return page.evaluate("""id => { const i = document.getElementById(id), s = i && i.closest('.ant-select'),
        x = s && s.querySelector('.ant-select-selection-item'); return x ? (x.getAttribute('title') || x.textContent || '').trim() : '' }""", input_id)

def same_address(loc, got):
    """does the dialog hold the document's address? street name, house number, postcode and country"""
    d_name, d_nr = street_parts(loc.get("street"))
    g_name, g_nr = street_parts(got["address"])
    return (street_similarity(d_name, g_name) >= 0.8 and d_nr == g_nr and norm(got["postcode"]) == norm(loc["postcode"])
            and got["country"] == COUNTRY_NAMES[loc.get("country", "NL")])

def cancel_drawer(page, drawer):
    """Cancel the "Add location manually" dialog and wait until it has slid away (it covers the form meanwhile)"""
    try:
        if drawer.count() and drawer.is_visible():
            page.keyboard.press("Escape")            # the Google result list
            drawer.locator('button:has-text("Cancel")').last.click(timeout=5000)
        drawer.wait_for(state="hidden", timeout=8000)
    except Exception:
        pass
    page.wait_for_timeout(800)

def create_location(page, inp, input_id, loc, ctx):
    """Qargo has no record at this address: make one. The address comes from the dialog's Google search (that also
    gives the coordinates) and is only saved when Google's street, house number, postcode and country are the
    document's. Returns what was created, or None (then the caller reports NO LOCATION)."""
    key = (norm(loc["street"]), norm(loc["postcode"]))
    label = f"{loc['name']!r} ({loc['street']}, {loc['postcode']} {loc['city']})"
    if key in CREATED:
        ctx["warnings"].append(f"location {label} was created earlier in this run as {CREATED[key]!r} but the search "
                               f"does not show it yet: pick it by hand")
        return None
    drawer = page.locator(".ant-drawer-open").filter(has_text="Add location manually").last
    try:
        for attempt in (1, 2):                       # the "Create new location" line comes with the search result
            try:
                page.keyboard.press("Escape")
                inp.click(); inp.fill(""); inp.press_sequentially(loc["query"], delay=10)
                wait_options(page, input_id)
                page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").get_by_text(
                    "Create new location").first.click(timeout=5000)
                drawer.wait_for(state="visible", timeout=8000)
                break
            except PWTimeout:
                if attempt == 2:
                    raise
        page.wait_for_timeout(1000)                  # the dialog slides in and copies the search text into its own
        g = drawer.locator("input[role=combobox]").first
        want = f"{loc['street']}, {loc['postcode']} {loc['city']}"
        opts = page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option")
        for attempt in (1, 2):
            g.click(); g.fill(""); page.wait_for_timeout(400)
            g.press_sequentially(want, delay=15)
            page.wait_for_timeout(2500)              # Google answers while typing; wait for the answer to the whole text
            if g.input_value() == want:
                break
        got = None
        for n in range(min(opts.count(), 4)):        # the first Google result that is this very address
            opts.nth(n).click(timeout=5000)
            page.wait_for_timeout(2500)
            got = drawer.evaluate(DRAWER_READ_JS)
            if same_address(loc, got) and got["lat"] and got["lon"]:
                break
            got = dict(got, wrong=True)
            g.click(); g.fill(""); g.press_sequentially(want, delay=15); page.wait_for_timeout(2500)
            if opts.count() <= n + 1:
                break
        if not got or got.get("wrong"):
            why = f"Google gives {got['address']}, {got['postcode']} {got['city']}, {got['country']}" if got \
                else "Google does not know the address"
            cancel_drawer(page, drawer)
            ctx["warnings"].append(f"location {label} NOT created: {why}. Create it by hand")
            return None
        drawer.locator('[id="name"]').fill(loc["name"], timeout=5000)
        drawer.locator('button:has-text("Save")').last.click(timeout=5000)
        drawer.wait_for(state="hidden", timeout=15000)
        page.wait_for_timeout(800)
    except Exception as e:
        cancel_drawer(page, drawer)
        ctx["warnings"].append(f"location {label} NOT created ({type(e).__name__}: {str(e).splitlines()[0][:120]}). "
                               f"Create it by hand")
        return None
    CREATED[key] = loc["name"]
    made = f"{loc['name']} / {got['address']}, {got['postcode']} {got['city']}"
    ctx["warnings"].append(f"CREATED location {made} ({got['lat']}, {got['lon']}) - new in Qargo, check it")
    page.wait_for_timeout(1500)
    if not selected_location(page, input_id):        # Qargo did not put the new record in the stop: pick it
        for _ in range(3):
            inp.click(); inp.fill(""); inp.press_sequentially(loc["query"], delay=10)
            cands, _note = pick_candidates(wait_options(page, input_id), loc)
            if cands:
                page.evaluate("id => document.getElementById(id).click()", cands[0]["id"])
                page.wait_for_timeout(300)
                break
            page.wait_for_timeout(2000)
    return f"CREATED {made}"

SWITCH_LABELS_JS = """fs => [...fs.querySelectorAll('button[role=switch]')].map(sw => {
    // name each switch after the nearest label around it: 'enforce', 'empty' (Empty trip) or '?'
    let n = sw;
    for (let i = 0; i < 6 && n.parentElement; i++) {
        n = n.parentElement;
        const t = n.textContent || '';
        const enf = /Enforce/.test(t), emp = /Empty trip/i.test(t);
        if (enf && !emp) return 'enforce';
        if (emp && !enf) return 'empty';
        if (enf && emp) return '?';
    }
    return '?';
})"""

def switch(fs, name):
    """the switch in this stop card labelled `name` ('enforce' / 'empty'), or None"""
    names = fs.evaluate(SWITCH_LABELS_JS)
    return fs.locator("button[role=switch]").nth(names.index(name)) if name in names else None

def set_time_fields(fs, start, end, ctx, label):
    tins = fs.locator('input[placeholder="08:00"]')
    if start:
        tins.nth(0).fill(start); tins.nth(0).press("Tab")
    if end:
        tins.nth(1).fill(end); tins.nth(1).press("Tab")
    if start or end:
        # NOT .first: an "Uncouple trailer" stop also has the "Empty trip" switch before Enforce
        sw = switch(fs, "enforce")
        if sw is None:
            ctx["warnings"].append(f"{label}: Enforce switch not found")
            return
        if sw.get_attribute("aria-checked") != "true":
            sw.click()
        if sw.get_attribute("aria-checked") != "true":
            ctx["warnings"].append(f"{label}: Enforce switch not on")

def fill_stop(page, prefix, st, ctx, label, is_setup_like=False):
    ctx["stop"] = label         # the location warnings (NO LOCATION, AMBIGUOUS, CHECK store ...) do not name their stop
    loc_id = f"{prefix}.location"
    inp = by_id(page, loc_id)
    fs = inp.locator("xpath=ancestor::fieldset[1]")          # this stop's card
    soft(ctx, f"{label} scroll", lambda: inp.scroll_into_view_if_needed(timeout=5000))
    if st.get("activity"):
        def act():
            fs.locator(".ant-select").first.click(timeout=5000)
            visible_dropdown_options(page).filter(
                has_text=re.compile(r"^\s*" + re.escape(st["activity"]) + r"\s*$")).first.click(timeout=5000)
            page.wait_for_timeout(300)
        soft(ctx, f"{label} activity", act)
    def location():
        ctx["chosen"].append(f"{label}: {choose_location(page, inp, loc_id, st['location'], ctx)}")
    soft(ctx, f"{label} location", location)
    def date():
        d = fs.locator(f'[id="{prefix}.date"]').first
        d.fill(st["date"], timeout=5000); d.press("Escape")
    soft(ctx, f"{label} date", date)
    soft(ctx, f"{label} time", lambda: set_time_fields(fs, st.get("start"), st.get("end"), ctx, label))
    if st.get("duration"):
        def duration():
            dur = fs.locator('[name$=".duration"] input').first
            dur.click(timeout=5000); dur.fill(st["duration"], timeout=5000)
            page.keyboard.press("Enter"); page.keyboard.press("Escape")
        soft(ctx, f"{label} duration", duration)
    if st.get("reference"):
        soft(ctx, f"{label} reference", lambda: fill_field(fs, f"{prefix}.reference_number", st["reference"]))
    if st.get("phone") and not is_setup_like and not prefix.startswith(("setup_input", "teardown_input")):
        def phone():
            pid = f"{prefix}.phone_number"
            if not page.locator(f'[id="{pid}"]').count():
                fs.locator("xpath=ancestor::div[contains(concat(' ', normalize-space(@class), ' '), ' ant-card ')][1]") \
                  .locator('button:has-text("Add information")').first.click(timeout=5000)
                menu_item(page, "Phone number")
            by_id(page, pid).wait_for(state="attached", timeout=5000)
            fill_field(page, pid, st["phone"])
        soft(ctx, f"{label} phone", phone)
    if st.get("note"):
        soft(ctx, f"{label} note", lambda: fill_field(fs, f"{prefix}.note", st["note"]))
    def no_empty_trip():
        # never "Plan trip to couple empty trailer" (shows up on Uncouple trailer stops)
        sw = switch(fs, "empty")
        if sw is not None and sw.get_attribute("aria-checked") == "true":
            sw.click()
            page.wait_for_timeout(200)
            if sw.get_attribute("aria-checked") == "true":
                ctx["warnings"].append(f"{label}: could not switch off 'Plan trip to couple empty trailer'")
    soft(ctx, f"{label} empty trip off", no_empty_trip)
    page.keyboard.press("Escape")

def soft(ctx, label, fn):
    """run one step; on failure log it and carry on with the rest of the order"""
    if STEP_HOOK:
        STEP_HOOK(ctx, label)
    try:
        fn()
    except Exception as e:
        ctx["warnings"].append(f"SKIPPED {label}: {type(e).__name__}: {str(e).splitlines()[0][:160]}")

WEIGHT_INPUT_JS = """q => {
    // Qargo renders two inputs with id "Total weight (kg)": a hidden autocomplete search box and the
    // real number field (role=spinbutton). Walk up from this item's Quantity to the smallest box that
    // holds a weight number field, and mark that field.
    const SEL = 'input[role=spinbutton][id="Total weight (kg)"], input[role=spinbutton][placeholder="100.00"]';
    let n = q;
    while (n && !n.querySelector(SEL)) n = n.parentElement;
    if (!n || n.querySelectorAll('[id$=".ordered_quantity"]').length !== 1) return null;
    const el = n.querySelector(SEL);
    el.setAttribute('data-qa-weight', '1');
    return el.id || '(no id)';
}"""

def fill_weight(page, base, kg, ctx, label):
    """Total weight (kg) of one cargo item (the number field in the same cargo card as its Quantity)."""
    val = f"{kg:g}" if isinstance(kg, float) else str(kg)
    page.evaluate("() => document.querySelectorAll('[data-qa-weight]').forEach(e => e.removeAttribute('data-qa-weight'))")
    found = by_id(page, f"{base}.ordered_quantity").evaluate(WEIGHT_INPUT_JS)
    if not found:
        raise RuntimeError("Total weight field not found in this cargo item")
    inp = page.locator("[data-qa-weight]").first
    inp.scroll_into_view_if_needed(timeout=5000)
    inp.click(timeout=5000)
    inp.fill(val, timeout=5000)
    inp.press("Tab")
    page.wait_for_timeout(200)
    got = re.sub(r"[^\d.,]", "", inp.input_value() or "")
    if not got or abs(float(got.replace(",", "")) - float(kg)) > 0.5:
        ctx["warnings"].append(f"CHECK {label}: weight should be {val} kg, form has {inp.input_value()!r}")

def add_order_info(page, item):
    page.locator('button:has-text("Add information")').first.click(timeout=5000)
    menu_item(page, item)

# Qargo checks the Customer Reference against every order (any customer, exact match) when the field
# loses focus, and shows "Possible duplicate detected in order: <link Or-...>" ~0.2 s later.
DUPLICATE_JS = r"""() => {
    for (const a of document.querySelectorAll('a[href*="/orders/"]')) {
        if (!/\/orders\/[0-9a-f-]{36}/.test(a.getAttribute('href') || '')) continue;
        if (/duplica|dubbel/i.test((a.parentElement && a.parentElement.textContent) || ''))
            return {order: a.textContent.trim(), url: a.href};
    }
    return null;
}"""

class DuplicateOrder(Exception):
    """Qargo already has an order with this customer reference"""

def qargo_duplicate(page, wait_s=0.0):
    """{'order': 'Or-0000059', 'url': ...} when Qargo shows its duplicate warning (polls up to wait_s), else None"""
    deadline = time.time() + wait_s
    while True:
        hit = page.evaluate(DUPLICATE_JS)
        if hit or time.time() >= deadline:
            return hit
        page.wait_for_timeout(100)

def select_pages(page, first, last, ctx):
    """The PDF holds other orders too: keep only this order's pages (Qargo "Select page range" -> a new
    "Split from PDF 1" document tab next to the original "PDF 1"), then close the original."""
    page.get_by_text("Select page range", exact=True).first.click(timeout=8000)
    page.locator('[id="__documentScanRangeStart"]').fill(str(first))
    page.locator('[id="__documentScanRangeEnd"]').fill(str(last))
    page.get_by_role("button", name="Apply").first.click()
    split = page.locator('[role=tab]').filter(has_text=re.compile(r"^\s*Split from PDF"))
    try:
        split.first.wait_for(timeout=10000)
    except PWTimeout:
        ctx["warnings"].append(f"CHECK document: asked for pages {first}-{last}, but no 'Split from PDF' appeared")
        return
    # close the original whole PDF ("PDF 1"), so only this order's pages are saved with it
    original = page.locator('.ant-tabs-tab').filter(
        has=page.locator('[role=tab]', has_text=re.compile(r"^\s*PDF \d+\s*$")))
    for _ in range(original.count()):
        original.first.locator('.ant-tabs-tab-remove').click(timeout=5000)
        page.wait_for_timeout(800)
    if original.count() or not split.count():
        ctx["warnings"].append(f"CHECK document: pages {first}-{last} split, but closing the original PDF tab failed "
                               f"- check which documents are attached")
        return
    ctx.setdefault("notes", []).append(f"document: only pages {first}-{last} of the PDF (original closed)")

def fill_order(page, o, pdf_dir, ctx):
    page.set_default_timeout(8000)
    page.goto(f"{TENANT_URL}/orders/new")
    page.get_by_text("Transport", exact=True).first.wait_for(timeout=20000)
    page.get_by_text("Transport", exact=True).first.click()
    # customer (required - stop if this fails)
    cust = by_id(page, "customer")
    cust.wait_for(timeout=10000)
    cust.click(); cust.press_sequentially(o["customer"], delay=20)
    opt = page.locator('[id="customer_list"] [role=option]').filter(has_text=re.compile("^" + re.escape(o["customer"])))
    opt.first.wait_for(timeout=8000); opt.first.click()
    by_id(page, "consignments[0].actual_pickup_stop.location").wait_for(state="attached", timeout=10000)
    n = len(o["consignments"])
    # same collection (place, date, time) for every consignment -> one collection, several deliveries
    pk = lambda c: (c["pickup"]["location"].get("query"), c["pickup"]["location"].get("postcode"),
                    c["pickup"]["date"], c["pickup"].get("start"), c["pickup"].get("end"))
    shared_pickup = n > 1 and len({pk(c) for c in o["consignments"]}) == 1
    ctx["shared_pickup"] = shared_pickup
    if n > 1:
        choose_static(page, "__multipleConsignmentKey",
                      "Multiple deliveries" if shared_pickup else "Multiple collections and deliveries")
        for i in range(1, n):
            page.locator('button:has-text("Add consignment")').filter(has_not_text="information").last.click()
            by_id(page, f"consignments[{i}].actual_delivery_stop.location").wait_for(state="attached", timeout=5000)
    # references + order instructions
    soft(ctx, "customer reference", lambda: by_id(page, "customer_reference_number").fill(o["customer_reference"]))
    # already in Qargo? Leaving the field makes Qargo check; stop before filling anything else
    soft(ctx, "duplicate check", lambda: by_id(page, "customer_reference_number").press("Tab"))
    dup = qargo_duplicate(page, wait_s=5)
    if dup and not ctx.get("allow_duplicate"):
        raise DuplicateOrder(f"already in Qargo as {dup['order']} ({dup['url']})")
    if dup:
        ctx["notes"].append(f"Qargo: same customer reference as {dup['order']} - filled anyway (--allow-duplicate)")
    if o.get("ritnummer"):
        def rit():
            if not by_id(page, "filtered_custom_fields.ritnummer").count():
                add_order_info(page, "Ritnummer")
            by_id(page, "filtered_custom_fields.ritnummer").wait_for(state="attached", timeout=5000)
            fill_field(page, "filtered_custom_fields.ritnummer", o["ritnummer"])
        soft(ctx, "ritnummer", rit)
    if o.get("instructions"):
        def instr():
            if not by_id(page, "instructions").count():
                add_order_info(page, "Instructions")
            by_id(page, "instructions").wait_for(state="attached", timeout=5000)
            fill_field(page, "instructions", o["instructions"])
        soft(ctx, "order instructions", instr)
    page.keyboard.press("Escape")
    # consignments
    for i, c in enumerate(o["consignments"]):
        if not (shared_pickup and i > 0):
            fill_stop(page, f"consignments[{i}].actual_pickup_stop", c["pickup"], ctx, f"c{i+1} collect")
        fill_stop(page, f"consignments[{i}].actual_delivery_stop", c["delivery"], ctx, f"c{i+1} deliver")
        def ddate():
            # Qargo copies the collection date into the delivery date; set it again explicitly
            d = by_id(page, f"consignments[{i}].actual_delivery_stop.date")
            if d.input_value() != c["delivery"]["date"]:
                d.fill(c["delivery"]["date"]); d.press("Escape")
        soft(ctx, f"c{i+1} delivery date", ddate)
        if c.get("reference"):
            def cref():
                if not by_id(page, f"consignments[{i}].consignment_reference_number").count():
                    page.locator('button:has-text("Add consignment information")').nth(i).click()
                    menu_item(page, "Consignment reference")
                by_id(page, f"consignments[{i}].consignment_reference_number").wait_for(state="attached", timeout=5000)
                fill_field(page, f"consignments[{i}].consignment_reference_number", c["reference"])
            soft(ctx, f"c{i+1} consignment reference", cref)
        if c.get("instructions"):
            def cinstr():
                if not by_id(page, f"consignments[{i}].instructions").count():
                    page.locator('button:has-text("Add consignment information")').nth(i).click()
                    menu_item(page, "Instructions")
                by_id(page, f"consignments[{i}].instructions").wait_for(state="attached", timeout=5000)
                fill_field(page, f"consignments[{i}].instructions", c["instructions"])
            soft(ctx, f"c{i+1} instructions", cinstr)
        for g_i, g in enumerate(c.get("goods") or []):
            def goods(g_i=g_i, g=g):
                if g_i > 0:
                    page.locator('button:has-text("Add cargo item")').nth(i).click()
                    by_id(page, f"consignments[{i}].goods[{g_i}].ordered_quantity").wait_for(state="attached", timeout=5000)
                if g.get("quantity") is not None:
                    field_box(page, f"consignments[{i}].goods[{g_i}].ordered_quantity").locator(
                        "input[role=spinbutton]").first.fill(str(g["quantity"]))
                if g.get("description"):
                    fill_field(page, f"consignments[{i}].goods[{g_i}].description", g["description"])

            soft(ctx, f"c{i+1} goods {g_i+1}", goods)
            if g.get("weight_kg") is not None:
                soft(ctx, f"c{i+1} goods {g_i+1} weight",
                     lambda g_i=g_i, g=g: fill_weight(page, f"consignments[{i}].goods[{g_i}]", g["weight_kg"], ctx,
                                                      f"c{i+1} goods {g_i+1}"))
        page.keyboard.press("Escape")
    # setup / teardown (shared by all consignments). Filled after the consignments: filling a
    # collection (the shared DC pickup in "Multiple deliveries") can reset an already filled start stop.
    row0 = page.locator('.row-no-wrap:has(> .col-evenly [id="consignments[0].actual_pickup_stop.location"])').first
    if o.get("setup"):
        def setup():
            row0.locator(":scope > .col").first.locator("button").click()
            by_id(page, "setup_input[0].location").wait_for(state="attached", timeout=5000)
        soft(ctx, "add start stop", setup)
        if by_id(page, "setup_input[0].location").count():
            fill_stop(page, "setup_input[0]", o["setup"], ctx, "start")
    if o.get("teardown"):
        def teardown():
            row0.locator(":scope > .col").last.locator("button").click()
            by_id(page, "teardown_input[0].location").wait_for(state="attached", timeout=5000)
        soft(ctx, "add end stop", teardown)
        if by_id(page, "teardown_input[0].location").count():
            fill_stop(page, "teardown_input[0]", o["teardown"], ctx, "end")
    # source document
    pdf = find_source(o["source"], pdf_dir)
    if pdf:
        def attach():
            page.locator('input[type=file][name=file]').first.set_input_files(str(pdf))
            page.wait_for_timeout(2500)
        soft(ctx, "attach PDF", attach)
        if o.get("pages"):
            soft(ctx, "PDF page range", lambda: select_pages(page, *o["pages"], ctx))
    else:
        ctx["warnings"].append(f"document {o['source']} not found in {[str(d) for d in pdf_dir]}")
    verify(page, o, ctx)

STOP_READBACK_JS = """prefix => {
    const inp = document.getElementById(prefix + '.location');
    if (!inp) return null;
    const fs = inp.closest('fieldset');
    const item = inp.closest('.ant-select') && inp.closest('.ant-select').querySelector('.ant-select-selection-item');
    const date = fs && fs.querySelector('[id="' + prefix + '.date"]');
    return {location: item ? (item.getAttribute('title') || item.textContent || '').trim() : '',
            date: date ? date.value : null,
            times: fs ? [...fs.querySelectorAll('input[placeholder="08:00"]')].map(i => i.value) : []};
}"""

def verify(page, o, ctx):
    """read the form back and compare with what should be there"""
    dup = qargo_duplicate(page)
    if dup and not ctx.get("allow_duplicate"):
        ctx["warnings"].append(f"!!! DUPLICATE: Qargo says customer reference {o['customer_reference']!r} "
                               f"is already in {dup['order']} ({dup['url']})")
    def val(i):
        loc = by_id(page, i)
        return loc.input_value() if loc.count() else None
    checks = [("customer_reference_number", o["customer_reference"])]
    if o.get("ritnummer"):
        checks.append(("filtered_custom_fields.ritnummer", str(o["ritnummer"])))
    for i, c in enumerate(o["consignments"]):
        if not (ctx.get("shared_pickup") and i > 0):
            checks.append((f"consignments[{i}].actual_pickup_stop.date", c["pickup"]["date"]))
        checks.append((f"consignments[{i}].actual_delivery_stop.date", c["delivery"]["date"]))
        if c.get("reference"):
            checks.append((f"consignments[{i}].consignment_reference_number", c["reference"]))
    for fid, want in checks:
        got = val(fid)
        if got != want:
            ctx["warnings"].append(f"CHECK {fid}: expected {want!r}, form has {got!r}")
    # start / end stop: location, date and times (these came out empty before; say so loudly)
    for k, label, s in (("setup_input[0]", "START", o.get("setup")), ("teardown_input[0]", "END", o.get("teardown"))):
        if not s:
            continue
        got = page.evaluate(STOP_READBACK_JS, k)
        if got is None:
            ctx["warnings"].append(f"!!! {label} STOP MISSING: no {k} in the form")
            continue
        if not got["location"]:
            ctx["warnings"].append(f"!!! {label} STOP LOCATION EMPTY ({s['location'].get('name')})")
        if got["date"] != s["date"]:
            ctx["warnings"].append(f"!!! {label} STOP DATE: expected {s['date']!r}, form has {got['date']!r}")
        for i, key in enumerate(("start", "end")):
            if s.get(key) and (got["times"][i:i+1] or [None])[0] != s[key]:
                ctx["warnings"].append(f"!!! {label} STOP {key.upper()} TIME: expected {s[key]!r}, "
                                       f"form has {(got['times'][i:i+1] or [None])[0]!r}")
    # every location field must have a selection
    empty = page.evaluate("""() => [...document.querySelectorAll('[id$=".location"]')]
        .filter(i => !i.closest('.ant-select').querySelector('.ant-select-selection-item'))
        .map(i => i.id)""")
    for e in empty:
        ctx["warnings"].append(f"EMPTY location field {e}")

def open_browser(p, profile, *, channel=None, headless=False, extra_args=()):
    """the browser window with the Qargo login kept in `profile` (channel: None = Playwright's own Chromium,
    or "chrome" / "msedge")"""
    # no fixed viewport: the page follows the window size, so the Save bar stays on screen
    ctxb = p.chromium.launch_persistent_context(str(profile), headless=headless, no_viewport=True, channel=channel,
                                                args=["--start-maximized",
                                                      "--disable-background-timer-throttling",
                                                      "--disable-backgrounding-occluded-windows",
                                                      "--disable-renderer-backgrounding", *extra_args])
    ctxb.add_init_script(ENGLISH_JS)
    return ctxb

# Qargo keeps its language per browser (localStorage USER_LOCALE), not per account, and a new browser profile
# starts in Dutch - but every button the bot presses is found by its English text.
ENGLISH_JS = """(() => {
    try {
        if (location.hostname === %r && localStorage.getItem('USER_LOCALE') !== '"en"')
            localStorage.setItem('USER_LOCALE', '"en"');
    } catch (e) {}
})()""" % TENANT_URL.split("://", 1)[-1].split("/")[0].split(":")[0]

def login_state(page):
    """is this page inside Qargo ("in"), or somewhere else (the login site) or asking for a password ("out")?"""
    if TENANT_URL.split("://", 1)[-1] not in page.url or page.locator('input[type=password]').count():
        return "out"
    return "in"

def fill_one(ctxb, o, pdf_dir, *, save=False, allow_duplicate=False, doc_warnings=(), done=None, done_path=None,
             create_locations=False):
    """Fill one order in a new tab of the browser context ctxb, classify the result and log it.
    doc_warnings: the validator's warnings for this order. save: press Save when there are no warnings at all;
    the saved order then goes into `done` and done_path (default: done.json).
    Returns (status, ctx, tab); tab is None when it was closed. Cancelled (from STEP_HOOK) closes the tab and
    goes on up to the caller."""
    if save:
        done_path = done_path or paths.done_file()
        if done is None:
            done = json.loads(done_path.read_text(encoding="utf-8-sig")) if done_path.exists() else {}
    # validator / parser doubts count as warnings too: --save leaves such an order for you to check
    ctx = {"warnings": [f"JSON: {m}" for m in doc_warnings], "chosen": [], "notes": [],
           "allow_duplicate": allow_duplicate, "create_locations": create_locations}
    tab = ctxb.new_page()
    tab.bring_to_front()          # background tabs get paused by Chromium -> "frozen" runs
    log(f"--- {o['key']} ({o['customer']} {o['customer_reference']}, {len(o['consignments'])} consignments)")
    try:
        fill_order(tab, o, pdf_dir, ctx)
        status = "FILLED"
    except DuplicateOrder as e:
        # nothing else was filled: close the tab, say where the order is
        status = f"DUPLICATE ({str(e).split(' as ')[1].split(' ')[0]})"
        ctx["warnings"].append(f"{e}. Not filled. If it really is another order: "
                               f"--allow-duplicate {o['key']}")
        tab.close(run_before_unload=False)
    except Exception as e:
        status = "ERROR"
        ctx["warnings"].append(f"{type(e).__name__}: {str(e).splitlines()[0][:300]}")
        try:
            # the key of a hand-made orders file can hold what a file name cannot ("/", ":" ...)
            shot = paths.logs_dir() / f"error_{re.sub(r'[^A-Za-z0-9._-]', '_', str(o['key']))}.png"
            tab.screenshot(path=str(shot), full_page=True)
            ctx["warnings"].append(f"screenshot: {shot.name}")
        except Exception:
            pass
    except Cancelled:
        try:
            tab.close(run_before_unload=False)      # never leave a half-filled form behind
        except Exception:
            pass                                    # the window is gone as well: still Cancelled, nothing else
        raise
    for c in ctx["chosen"]:
        log(f"    {c}")
    for n in ctx["notes"]:
        log(f"    note: {n}")
    for w in ctx["warnings"]:
        log(f"    !! {w}")
    if status == "FILLED" and save and not ctx["warnings"]:
        tab.locator('button:has-text("Save")').last.click()
        try:
            tab.wait_for_url(re.compile(r"/orders/(?!new)[0-9a-f-]{36}"), timeout=20000)
            status = "SAVED"
            done[o["key"]] = tab.url
            done_path.write_text(json.dumps(done, indent=1), encoding="utf-8")
        except PWTimeout:
            status = "SAVE?"; ctx["warnings"].append("Save clicked but no order page opened - check the tab")
    elif status == "FILLED" and save:
        status = "FILLED (not saved: warnings)"
    log(f"    => {status}")
    return status, ctx, (None if tab.is_closed() else tab)

def run_fill(orders_path, *, only=None, customer=None, skip=(), save=False, allow_duplicate=(), pdf_dir=None,
             profile=None, create_locations=False):
    """What `python3 qargo_fill.py ...` does, with the options as arguments (pdf_dir: a list of folders;
    profile: default ./.qargo-profile). Asks twice in the terminal (log in; finished).
    Returns [(key, status, number of warnings)]."""
    LOG_LINES.clear()             # a second run in the same process must not repeat the first run's lines
    orders_path = Path(orders_path).resolve()
    orders = json.loads(orders_path.read_text(encoding="utf-8-sig"))
    pdf_dir = [Path(d).expanduser().resolve() for d in (pdf_dir or [paths.documents_dir(), paths.downloads_dir()])]
    done_path = paths.done_file()
    done = json.loads(done_path.read_text(encoding="utf-8-sig")) if done_path.exists() else {}
    sel = [o for o in orders
           if (not only or o["key"] in only)
           and (not customer or o["customer"].lower() == customer.lower())
           and o["key"] not in skip and o["key"] not in done]
    # never fill an order the validator rejects (wrong dates, missing locations, typos in the JSON...)
    errors, warnings = validate(sel, pdf_dir)
    bad = sorted({k for k, _ in errors})
    for k, m in errors:
        log(f"INVALID {k}: {m}")
    if bad:
        log(f"not filling {len(bad)} invalid order(s): {bad} - fix the JSON or the parser first")
        sel = [o for o in sel if o.get("key") not in bad]
    log(f"{len(sel)} orders to fill (skipping {len(done)} already saved per done.json)")
    results = []
    with sync_playwright() as p:
        try:
            ctxb = open_browser(p, profile or paths.profile_dir("chromium"))
            page = ctxb.pages[0] if ctxb.pages else ctxb.new_page()
            page.goto(f"{TENANT_URL}/orders")
            page.wait_for_timeout(3000)
            if login_state(page) == "out":
                input(">>> Log in to Qargo in the browser window, open the Orders page, then press Enter here... ")
            doc_warnings = {}
            for k, m in warnings:
                doc_warnings.setdefault(k, []).append(m)
            for o in sel:
                status, ctx, tab = fill_one(ctxb, o, pdf_dir, save=save, allow_duplicate=o["key"] in allow_duplicate,
                                            create_locations=create_locations,
                                            doc_warnings=doc_warnings.get(o["key"], []), done=done, done_path=done_path)
                results.append((o["key"], status, len(ctx["warnings"])))
            log("==== summary")
            for k, s, w in results:
                log(f"{k:20} {s:28} warnings={w}")
        finally:
            # before the prompt below, as always (the tabs can stay open for hours) - and also when something
            # stopped the run: the log then says how far it got
            log_file = paths.logs_dir() / f"fill_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"
            log_file.write_text("\n".join(LOG_LINES), encoding="utf-8")
        input(">>> DONE filling. Check each tab and press Save there. Press Enter here only when you're finished - it closes the browser... ")
        ctxb.close()
    return results

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("orders")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--customer")
    ap.add_argument("--skip", nargs="*", default=[])
    ap.add_argument("--save", action="store_true", help="press Save after filling (only when no warnings)")
    ap.add_argument("--allow-duplicate", nargs="*", default=[], metavar="KEY",
                    help="fill these orders even though Qargo already has an order with the same customer reference")
    ap.add_argument("--create-locations", action="store_true",
                    help="an address Qargo has no location for gets a new location record (never AH stores or guessed "
                         "addresses); such an order is never saved automatically")
    ap.add_argument("--pdf-dir", action="append",
                    help="folder with the source documents, searched recursively (repeatable; "
                         "default: ./documents, then ~/Downloads)")
    ap.add_argument("--profile")
    a = ap.parse_args()
    run_fill(a.orders, only=a.only, customer=a.customer, skip=a.skip, save=a.save, allow_duplicate=a.allow_duplicate,
             pdf_dir=a.pdf_dir, profile=a.profile, create_locations=a.create_locations)

if __name__ == "__main__":
    main()
