"""SVZ: the driver's planning for PLUS Oss, as an alertmydriver mail (rule in MAPPING.md, "SVZ").

SVZ sends no document. The planning comes as a mail "Planning Dienst 22-10-2026" from no-reply@alertmydriver.com
to planning@denis-express.nl, no PDF, every stop in the text: one mail per driver and day, around 16:00 the day
before, the same kind of mail again when the planning changes. Each "Rit:" block in it is one order.

    is_planning_dienst(sender, subject)  the alertmydriver planning mails (SVZ's and Albert Heijn's alike)
    kind(text)                           "svz" (Beste <driver>, planafdeling PLUS Oss), "ah" (Beste (DENIBARExx):
                                         the AH planning for a Simon Loos charter, nothing to do), or None
    write_rits(text, folder, ...)        one small PDF per planned rit (the mail's header and that rit's block),
                                         so the order carries what SVZ sent and run.py / the parser read it like
                                         any document; the rits not planned yet are returned apart, no PDF
    parse_text(text, source)             the orders in a mail text or a rit PDF's text (parse_trips.py calls it)

The mail's "Bevestigen" link is the driver's confirmation to SVZ: nothing here opens it.
"""
import datetime, re
from pathlib import Path

CUSTOMER, PREFIX = "SVZ", "SVZ-"
SENDER = "alertmydriver.com"
SUBJECT = re.compile(r"^\s*(?:(?:re|fw|fwd|aw)\s*:\s*)*planning dienst\b", re.I)
LABEL = re.compile(r"^\s*(Beste|Geplande starttijd dienst|Geplande eindtijd dienst|Truck|Trailer|Rit|Starttijd|"
                   r"Omschrijving|Laden|Lossen|Geplande tijd|Opmerking|Adresopmerking)\s*:?\s*(.*?)\s*$")
# text that is not a field: the greeting lines, the confirm link, Mail's picture placeholders
BOILERPLATE = re.compile(r"^(Hierbij sturen we je de transportplanning|Let op deze eindtijd|Bevestigen$|￼)", re.I)
LABELLIKE = re.compile(r"^[A-Z][a-z]+(?: [a-z]+)*\s*:")       # "Foo bar:" = a field the parser does not know
PLANAFDELING = re.compile(r"planafdeling\s+(.+?)\s+op\s+(?:nummer\s+)?([\d-]+)", re.I)
WINDOW = re.compile(r"^(\d{2}:\d{2})\s*-\s*(\d{2}:\d{2})$")
START = re.compile(r"^(\d{2}:\d{2})\s*/\s*(\d{1,2})-(\d{1,2})-(\d{4})$")
PC_NL = re.compile(r"^(\d{4})\s?([A-Z]{2})$")
CHARTER = re.compile(r"\((DENIS\s*\d+[A-Z]?)\)")
NOT_PLANNED = "not planned yet"


def is_planning_dienst(sender, subject):
    return SENDER in (sender or "").lower() and SUBJECT.match(subject or "") is not None


def lines_of(text):
    """the mail's lines, without the picture placeholders and empty lines"""
    out = []
    for raw in (text or "").splitlines():
        line = raw.replace("￼", " ").strip()
        if line:
            out.append(line)
    return out


def joined(text):
    """every line of the mail, wrapped lines joined again (a rit PDF wraps the long ones)"""
    head, rits = blocks(text)
    return head + [l for b in rits for l in b]


def kind(text):
    """which alertmydriver planning this is: 'svz', 'ah', or None (another layout: not read)"""
    lines = joined(text)
    greeting = next((l for l in lines if l.startswith("Beste")), "")
    if not greeting:
        return None
    if re.match(r"Beste\s*\(", greeting):
        return "ah"
    if any("PLUS Oss" in l and "planafdeling" in l.lower() for l in lines):
        return "svz"
    return None


def header(text):
    """(driver as greeted, 'Beste Petrov' -> 'Petrov'; the planning date 'YYYY-MM-DD' or ''; the planafdeling line)"""
    lines = joined(text)
    driver = next((l[5:].strip() for l in lines if l.startswith("Beste")), "")
    date = ""
    for l in lines:
        m = re.search(r"transportplanning voor (\d{1,2})-(\d{1,2})-(\d{4})", l)
        if m:
            date = f"{m.group(3)}-{int(m.group(2)):02d}-{int(m.group(1)):02d}"
            break
    pa = next((PLANAFDELING.search(l) for l in lines if PLANAFDELING.search(l)), None)
    return driver, date, (f"Planafdeling {pa.group(1)} {pa.group(2)}" if pa else "")


def label_of(line):
    """the field a line starts with ('Laden'), or '' for text that is no field"""
    m = LABEL.match(line)
    return m.group(1) if m else ""


def blocks(text):
    """(the header lines, [the lines of each Rit block]): a block starts at its Truck line, or at a Rit line when
    the open block already has its Rit. A line that is no field and no 'Word:' runs on from the line before it."""
    head, rits = [], []
    for line in lines_of(text):
        label = label_of(line)
        current = rits[-1] if rits else head
        if label == "Truck" or (label == "Rit" and any(label_of(l) == "Rit" for l in current if rits)):
            rits.append([]); current = rits[-1]
        if not label and current and not BOILERPLATE.match(line) and not LABELLIKE.match(line):
            current[-1] += " " + line                 # a wrapped line of the field before it
            continue
        current.append(line)
    return head, rits


def rit_number(block):
    for l in block:
        if label_of(l) == "Rit":
            return re.sub(r"\D", "", LABEL.match(l).group(2))
    return ""


def planned(block):
    """a rit with at least one Lossen and a real time window; '09:30 uur melden in Oss' has neither"""
    has_lossen = any(label_of(l) == "Lossen" for l in block)
    windows = [window_of(LABEL.match(l).group(2)) for l in block if label_of(l) == "Geplande tijd"]
    return has_lossen and any(w is not None for w in windows)


def window_of(value):
    """'05:37 - 06:09' -> ('05:37', '06:09'); '00:00 - 00:00' (no time planned) -> None; anything else -> False"""
    w = WINDOW.match(value)
    if not w:
        return False
    return None if w.groups() == ("00:00", "00:00") else w.groups()


def not_planned_record(block, driver, date):
    """what the report says about a rit that is not planned yet"""
    desc = next((LABEL.match(l).group(2) for l in block if label_of(l) == "Omschrijving"), "")
    rit = rit_number(block)
    return {"key": f"{PREFIX}{rit}", "rit": rit, "driver": driver, "date": date, "text": desc,
            "summary": f"{PREFIX}{rit} {driver} {date[8:10]}-{date[5:7]}: {desc or '(no Omschrijving)'}"}


def write_rits(text, folder, received=None):
    """one PDF per planned rit in folder (the header and that rit's lines, as the mail prints them); returns
    ([paths], [not-planned records]). A rit without a number gets no PDF and a record with the reason."""
    head, rits = blocks(text)
    driver, date, _ = header(text)
    paths, not_planned = [], []
    for block in rits:
        rit = rit_number(block)
        if not rit or not planned(block):
            rec = not_planned_record(block, driver, date)
            if not rit:
                rec["summary"] = f"a rit without a Rit number for {driver} {date}: {rec['text'] or '(no Omschrijving)'}"
            not_planned.append(rec)
            continue
        p = Path(folder) / f"Planning Dienst {date or 'x'} rit {rit}.pdf"
        Path(folder).mkdir(parents=True, exist_ok=True)
        p.write_bytes(text_pdf([f"Planning Dienst {date}" if date else "Planning Dienst", ""] + head + [""] + block))
        if received is not None:
            import os
            os.utime(p, (received.timestamp(), received.timestamp()))
        paths.append(p)
    return paths, not_planned


def is_svz_text(text):
    """a rit PDF written by write_rits (its first line is 'Planning Dienst <date>'; the mail has that in its subject)"""
    return "Planning Dienst" in text and kind(text) == "svz"


def _place(value):
    """'PLUS Retail Oss - Keltenweg 30 - 5342 LP - OSS' -> location dict, or None when it is not name - street -
    postcode - city"""
    parts = [p.strip() for p in value.split(" - ")]
    if len(parts) < 4:
        return None
    name, street, pc, city = " - ".join(parts[:-3]), parts[-3], parts[-2], parts[-1]
    m = PC_NL.match(pc)
    if not m or not re.search(r"\d", street):
        return None
    mq = re.match(r"^(.*?\d+)", street)
    return {"name": name, "street": street, "postcode": m.group(1) + m.group(2), "city": city, "country": "NL",
            "query": (mq.group(1) if mq else street).strip()}


def parse_text(text, source):
    """the orders in a mail text, or in one rit PDF's text (write_rits): one per Rit block. A rit not planned yet
    or with a line the parser does not know is refused through `unread` (never filled); nothing is dropped."""
    head, rits = blocks(text)
    driver, date, planafdeling = header(text)
    dienst = {}
    for l in head:
        m = LABEL.match(l)
        if m and m.group(1) in ("Geplande starttijd dienst", "Geplande eindtijd dienst"):
            dienst[m.group(1)] = m.group(2)
        elif not m and not BOILERPLATE.match(l) and not l.startswith("Beste") and "Planning Dienst" not in l:
            dienst.setdefault("unread", []).append(l)
    out = []
    for block in rits:
        rit = rit_number(block)
        unread = list(dienst.get("unread", []))
        if not rit:
            unread.append("a Rit block without a Rit number")
        truck = trailer = desc = start = ""
        stops = []                       # {"kind", "loc", "window", "note", "raw"}
        for l in block:
            m = LABEL.match(l)
            label, value = (m.group(1), m.group(2)) if m else ("", l)
            if label == "Truck": truck = value
            elif label == "Trailer": trailer = value
            elif label == "Rit": pass
            elif label == "Starttijd": start = value
            elif label == "Omschrijving": desc = value
            elif label in ("Laden", "Lossen"):
                loc = _place(value)
                if not loc:
                    unread.append(f"{label} line not read as name - street - postcode - city: {value}")
                stops.append({"kind": label, "loc": loc, "window": None, "note": [], "raw": value})
            elif label in ("Geplande tijd", "Opmerking", "Adresopmerking"):
                if not stops:
                    unread.append(f"{label} printed before any Laden / Lossen: {value}")
                elif label == "Geplande tijd":
                    w = window_of(value)                  # None: '00:00 - 00:00', no time planned for this stop
                    if w is False:
                        unread.append(f"time window not read: {value}")
                    stops[-1]["window"] = w or None
                else:
                    stops[-1]["note"].append(value)
            elif BOILERPLATE.match(l):
                pass
            else:
                unread.append(f"line not read: {l}")
        if not planned(block):
            unread.append(f"{NOT_PLANNED}: {desc or '(no Omschrijving)'}: only {len(stops)} stop(s), no time window")
        sm = START.match(start)
        if sm:
            day = datetime.date(int(sm.group(4)), int(sm.group(3)), int(sm.group(2)))
        elif date:
            day = datetime.date.fromisoformat(date)
        else:
            day, unread = None, unread + [f"no date: Starttijd {start!r}, no planning date in the mail"]
        # the stop's date: the rit's day; a window that starts earlier than the stop before it is the next day
        consignments, load, clock, offset = [], None, None, 0
        for s in stops:
            if s["window"] and clock and s["window"][0] < clock:
                offset += 1
            if s["window"]:
                clock = s["window"][0]
            d = (day + datetime.timedelta(days=offset)).strftime("%d/%m/%Y") if day else "00/00/0000"
            st = {"location": s["loc"] or {"name": s["raw"], "street": "", "country": "NL", "query": s["raw"]}, "date": d}
            if s["window"]:
                st["start"], st["end"] = s["window"]
            if s["note"]:
                st["note"] = "\n".join(s["note"])
            s["stop"] = st
            if s["kind"] == "Laden":
                if load is not None and not load.get("used"):
                    unread.append(f"load {load['raw']} has no Lossen after it: NOT a stop in the order")
                load = dict(s, used=False)
                continue
            if load is None:
                unread.append(f"Lossen {s['raw']} printed before any Laden: NOT a stop in the order")
                continue
            note = " ".join(s["note"])
            mo = re.search(r"Ordernummer:\s*(\S+)", note)
            mq = re.search(r"Ladingdragers:\s*(\d+(?:[.,]\d+)?)", note)
            q = float(mq.group(1).replace(",", ".")) if mq else None
            if q == 0:
                unread.append(f"Lossen {s['raw']} prints Ladingdragers: 0 - nothing to deliver? not read")
            goods = [{"quantity": int(q) if q == int(q) else q, "description": "ladingdragers"}] if q else [{"quantity": 1}]
            consignments.append({"reference": mo.group(1) if mo else None, "instructions": None,
                                 "pickup": dict(load["stop"]), "delivery": st, "goods": goods})
            load["used"] = True
        if load is not None and not load.get("used"):
            unread.append(f"load {load['raw']} has no Lossen after it: NOT a stop in the order")
        if not consignments:
            consignments = [{"reference": None, "instructions": None,
                             "pickup": {"location": {"name": "?", "street": "?", "country": "NL", "query": "?"}, "date": "00/00/0000"},
                             "delivery": {"location": {"name": "?", "street": "?", "country": "NL", "query": "?"}, "date": "00/00/0000"},
                             "goods": [{"quantity": 1}]}]
        code = CHARTER.search(truck)
        instructions = [re.sub(r"\s+", "", code.group(1)).upper()] if code else []
        instructions += [x for x in (driver, f"Truck: {truck}" if truck else "", f"Trailer: {trailer}" if trailer.strip("() ") else "",
                                     f"Omschrijving: {desc}" if desc else "",
                                     (f"Dienst: {dienst.get('Geplande starttijd dienst', '?')} - "
                                      f"{dienst.get('Geplande eindtijd dienst', '?')}") if dienst.get("Geplande starttijd dienst") else "",
                                     planafdeling) if x]
        o = {"customer": CUSTOMER, "customer_reference": rit or "?", "ritnummer": int(rit) if rit else None,
             "instructions": "\n".join(instructions), "setup": None, "teardown": None,
             "consignments": consignments, "source": source, "key": f"{PREFIX}{rit or '?'}"}
        if unread:
            o["unread"] = list(dict.fromkeys(unread))
        out.append(o)
    return out


# ------------------------------------------------------------------ a PDF of plain text, no library needed
def _pdf_text(s):
    b = s.encode("cp1252", "replace")
    return b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)")


def text_pdf(lines, per_page=58):
    """a PDF (A4 height, Helvetica 10 pt, one text line per line) that pdfminer reads back line by line. The page
    is as wide as its longest line, so no line is ever wrapped: the parser gets the mail's lines as they were."""
    width = max(595, 80 + int(6 * max((len(l) for l in lines), default=0)))
    pages = [lines[i:i + per_page] for i in range(0, len(lines), per_page)] or [[""]]
    objs = []                                      # object bodies, 1-based
    objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objs.append(b"")                               # 2: the pages, filled below
    font_no = 3 + 2 * len(pages)
    kids = []
    for pg in pages:
        content = b"BT /F1 10 Tf 13 TL 40 800 Td " + b" ".join(b"(" + _pdf_text(l) + b") Tj T*" for l in pg) + b" ET"
        kids.append(len(objs) + 1)
        objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %d 842] /Contents %d 0 R "
                    b"/Resources << /Font << /F1 %d 0 R >> >> >>" % (width, len(objs) + 2, font_no))
        objs.append(b"<< /Length %d >>\nstream\n" % len(content) + content + b"\nendstream")
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
    objs[1] = b"<< /Type /Pages /Kids [" + b" ".join(b"%d 0 R" % k for k in kids) + b"] /Count %d >>" % len(kids)
    out, offsets = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"), []
    for n, body in enumerate(objs, 1):
        offsets.append(len(out))
        out += b"%d 0 obj\n" % n + body + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
    for off in offsets:
        out += b"%010d 00000 n \n" % off
    out += b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objs) + 1, xref)
    return bytes(out)
