"""The seam between the app's engine and the bot: everything the engine wants from "something that fills
Qargo" is on this one class. QargoFiller is the real thing, qargo_fill.py through the functions it offers
(open_browser, login_state, fill_one, STEP_HOOK, LOG_SINK, Cancelled). The self-test puts a stand-in for the
local stand-in site in its place (tests/fake_qargo.py); the engine does not know which one it talks to.
"""
import re
from collections import namedtuple
from playwright.sync_api import Error as PWError

# status: "filled" | "duplicate" | "failed". warnings: the bot's own messages, as it logs them. tab: the order's
# tab when it is still open. qargo: the number of the order Qargo already has ("Or-0000059") for a duplicate.
# A change (order["change"]) the bot made in Qargo's Edit order form is "filled" too: the tab holds it, unsaved;
# a change that turned out to be no change at all ("UNCHANGED (Or-...)") is a "duplicate", one the bot did not make
# (several orders with the reference, another customer's order) is "not_changed".
Result = namedtuple("Result", "status warnings tab qargo")

# Is this order page showing that customer reference? In a field of the page, or as a word of its own in the text.
SHOWS_REFERENCE_JS = r"""ref => {
    const norm = s => (s || '').replace(/\s+/g, ' ').trim();
    for (const el of document.querySelectorAll('input, textarea'))
        if (norm(el.value) === ref) return true;
    if (ref.length < 4) return false;                 // too short to look for in running text
    const text = document.body ? document.body.innerText : '';
    for (let i = text.indexOf(ref); i >= 0; i = text.indexOf(ref, i + 1))
        if (!/[A-Za-z0-9]/.test(text[i - 1] || ' ') && !/[A-Za-z0-9]/.test(text[i + ref.length] || ' ')) return true;
    return false;
}"""


class QargoFiller:
    # A logged-out visit loads Qargo's own page first and is sent to the login page a moment later, so "inside
    # Qargo" only counts after it has lasted this long. The command line waits 3 seconds for the same reason.
    settle = 3.0

    def __init__(self):
        import qargo_fill                    # reads QARGO_TENANT_URL when it is imported
        self.qf = qargo_fill
        self.saved_re = qargo_fill.SAVED_RE  # an order's own page (not new, not /edit), as fill_one recognises it
        self.tenant = qargo_fill.TENANT_URL
        self.Cancelled = qargo_fill.Cancelled

    def set_log(self, sink):
        self.qf.LOG_SINK = sink

    def open_browser(self, pw, profile, channel, headless, extra_args):
        return self.qf.open_browser(pw, profile, channel=channel, headless=headless, extra_args=extra_args)

    def login_state(self, page):
        """"in" / "out", or "unknown" while the page is on its way somewhere"""
        try:
            return self.qf.login_state(page)
        except PWError:
            return "unknown"

    def steps(self, o):
        """how many steps fill_order will take for this order (one per soft() call), for "Being filled (4/31)" """
        def stop(st, start_or_end=False):
            return 5 + sum(bool(st.get(k)) for k in ("activity", "duration", "reference", "note")) \
                + bool(st.get("phone") and not start_or_end)
        try:
            cons = o["consignments"]
            pk = lambda c: (c["pickup"]["location"].get("query"), c["pickup"]["location"].get("postcode"),
                            c["pickup"]["date"], c["pickup"].get("start"), c["pickup"].get("end"))
            shared = len(cons) > 1 and len({pk(c) for c in cons}) == 1
            n = 2 + bool(o.get("ritnummer")) + bool(o.get("instructions")) + 1 + bool(o.get("pages"))
            for i, c in enumerate(cons):
                n += (0 if shared and i else stop(c["pickup"])) + stop(c["delivery"]) + 1
                n += bool(c.get("reference")) + bool(c.get("instructions"))
                n += sum(1 + (g.get("weight_kg") is not None) + (g.get("temperature_c") is not None) for g in c.get("goods") or [])
                n += sum(2 + stop(x) for x in c.get("stops") or [])          # add, position, stop action ...
            for k in ("setup", "teardown"):
                if o.get(k):
                    n += 1 + stop(o[k], True)
            return n
        except Exception:
            return 10

    def fill(self, ctxb, o, pdf_dirs, doc_warnings, step):
        """Fill one order in a new tab. step(ctx, label) is called before every step and may raise Cancelled
        (the tab is closed then). Nothing is saved here."""
        qf = self.qf
        qf.STEP_HOOK = step
        qf.LOG_LINES.clear()                  # fill_one only adds to it; the app has its own log
        try:
            # a place Qargo does not have is made (as --create-locations); the CREATED note is logged and the order can be saved
            status, ctx, tab = qf.fill_one(ctxb, o, pdf_dirs, doc_warnings=doc_warnings, create_locations=True)
        finally:
            qf.STEP_HOOK = None
        if status.startswith(("DUPLICATE", "UNCHANGED")):
            return Result("duplicate", ctx["warnings"], None, status[status.index("(") + 1:-1])
        if status == "NOT CHANGED":                   # nothing touched, no tab: its own result, the reason is what counts
            return Result("not_changed", ctx["warnings"], None, None)
        return Result("failed" if status == "ERROR" else "filled", ctx["warnings"], tab, None)

    def press_save(self, tab):
        """Qargo's own Save, as `qargo_fill.py --save` presses it, "Are you sure" dialog and all (the app never
        allows a duplicate). None when saved; the warning when Qargo asked about something the bot leaves to the
        operator (the dialog is Cancelled). Raises a Playwright timeout when no order page opens"""
        try:
            self.qf.press_save(tab, timeout_s=20)
        except self.qf.SaveRefused as e:
            return f"QARGO ASKED before saving: {e}. Not saved: check the tab and press Save yourself"

    def shows_reference(self, tab, ref):
        try:
            return bool(tab.evaluate(SHOWS_REFERENCE_JS, " ".join(str(ref).split())))
        except PWError:                       # the page is loading, or gone
            return False
