#!/usr/bin/env python3
"""Cancel every Qargo order whose requested delivery date is before today and that is not delivered.

  python3 cancel_overdue.py --dry-run     # only list what it would cancel
  python3 cancel_overdue.py               # cancel them (Qargo's own bulk "Cancel orders")

- "Not delivered" = status Blocked, To plan, Planned, Departed or In transit. Completed, invoiced and cancelled
  orders are never touched. Trips a driver already started are cancelled too (decided 21 Oct 2026).
- Requested delivery date = the date of the order's last delivery stop, as Qargo's order list shows it.
- A cancelled order cannot be invoiced. Undo: "UNDO order Cancellation" on the order, or the bulk uncancel on
  the Cancelled tab (the order goes back to To plan).
- Runs in a hidden browser on a copy of the Qargo login, so the bot or the app can be open at the same time.
- Every answer from Qargo is waited for (deadline), never a fixed pause; no answer = nothing cancelled + error.
- Writes cancel_log_<date>_<time>.txt (next to fill_log_*); exit code 1 when anything went wrong.
"""
import argparse, collections, datetime, json, shutil, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import paths

OPEN = ("BLOCKED", "TO_PLAN", "PLANNED", "DEPARTED", "IN_TRANSIT")
DRIVER_STARTED = ("ROUTE_TO_STOP", "AT_STOP", "COMPLETED")      # stop statuses seen on the live system, 21 Oct 2026
# the bulk cancel the Orders page sends (Quick actions -> Cancel orders). Qargo only accepts the exact texts its
# own app sends: if Qargo changes it, this run fails with "query is not allowed" and cancels nothing.
CANCEL_MUTATION = ("mutation BulkOrderUpsertMutation($args: [OrderInput!]!) {\n  AsyncBulkUpsertOrder(args: $args) {\n"
                   "    job_group_id\n    __typename\n  }\n}\n")
PAGE_ANSWER_S, CANCEL_ANSWER_S = 90, 600


class NoAnswer(Exception):
    """Qargo did not answer in time (internet?) or the login is gone: nothing may be concluded"""


def delivery_date(order):
    """the requested date of the order's last delivery stop ('2026-10-20'), or None"""
    return (((order.get("summary") or {}).get("last_consignment_stop") or {}).get("date")) or None


def overdue(orders, today):
    """the orders to cancel: still open and due before `today` (a date). Sorted by date, then Or-number."""
    out = [o for o in orders
           if o.get("status") in OPEN and delivery_date(o) and delivery_date(o) < today.isoformat()]
    return sorted(out, key=lambda o: (delivery_date(o), o.get("name") or ""))


def started(order):
    """is a driver already on the way to, at, or done with a stop of this order? (To plan / Planned: not started)"""
    return any(s.get("status") in DRIVER_STARTED for s in order.get("actual_stops") or [])


def line(order):
    cust = (order.get("customer") or {}).get("name") or "?"
    extra = "  (trip already started)" if started(order) else ""
    return (f"{order.get('name')}  {delivery_date(order)}  {cust}  ref {order.get('customer_reference_number') or '-'}"
            f"  [{order.get('status')}]{extra}")


class Qargo:
    """a hidden, logged-in Qargo Orders page; runs the app's own queries from inside it"""

    def __init__(self, pw, profile):
        from qargo_fill import TENANT_URL, ENGLISH_JS, login_state
        self.ctx = pw.chromium.launch_persistent_context(str(profile), headless=True,
                                                         viewport={"width": 1600, "height": 1000})
        self.ctx.add_init_script(ENGLISH_JS)
        self.page = self.ctx.new_page()
        self.seen = {}                         # operationName -> (url, headers, query text) as the app sent it
        self.page.on("request", self._on_request)
        self.page.goto(TENANT_URL + "/orders", wait_until="load", timeout=PAGE_ANSWER_S * 1000)
        deadline = time.time() + PAGE_ANSWER_S
        while not {"ElasticQuery", "OrderListPageQuery"} <= self.seen.keys():
            if login_state(self.page) == "out":
                raise NoAnswer("LOGGED OUT of Qargo: log in once with the bot (python3 run.py) and run this again")
            if time.time() > deadline:
                raise NoAnswer(f"NO ANSWER: the Orders page did not load its list within {PAGE_ANSWER_S} s (internet?)")
            self.page.wait_for_timeout(500)

    def _on_request(self, r):
        if r.method == "POST" and "graphql" in r.url:
            try:
                body = r.post_data_json or {}
            except Exception:
                return
            op = body.get("operationName")
            if op and op not in self.seen:
                self.seen[op] = (r.url, {k: v for k, v in r.headers.items() if not k.startswith(":")}, body.get("query"))

    def run(self, op, query, variables):
        url, headers, _ = self.seen["ElasticQuery"]
        res = self.page.evaluate(
            """async ([url, h, body, ms]) => {
                 const c = new AbortController(); const t = setTimeout(() => c.abort(), ms);
                 try { const r = await fetch(url, {method: 'POST', headers: h, body: JSON.stringify(body),
                                                   credentials: 'include', signal: c.signal});
                       return await r.json(); }
                 catch (e) { return {no_answer: String(e)}; } finally { clearTimeout(t); } }""",
            [url, headers, {"operationName": op, "query": query, "variables": variables}, PAGE_ANSWER_S * 1000])
        if res.get("no_answer"):
            raise NoAnswer(f"NO ANSWER from Qargo for {op} (internet?): {res['no_answer']}")
        if res.get("errors"):
            raise RuntimeError(f"Qargo refused {op}: {json.dumps(res['errors'])[:500]}")
        return res["data"]

    def search(self, today):
        """row ids of open orders whose last delivery stop is requested before today"""
        _, _, text = self.seen["ElasticQuery"]
        yesterday = (today - datetime.timedelta(days=1)).isoformat()
        ids, offset = [], 0
        while True:
            q = {"filter": {"bool": {"filter": [
                    {"terms": {"status": list(OPEN)}},
                    {"range": {"last_consignment_stop_requested_date": {"lte": yesterday}}}]}},
                 "index": "ORDER_SUMMARY_V6", "offset": offset, "size": 1000,
                 "sort": [{"timestamp_created": {"order": "desc", "missing": "_last"}}]}
            d = self.run("ElasticQuery", text, {"query": q})["Search"]
            ids += [h["row_id"] for h in d["hits"]]
            offset += 1000
            if offset >= d["hit_count"] or not d["hits"]:
                return list(dict.fromkeys(ids))

    def orders(self, ids):
        _, _, text = self.seen["OrderListPageQuery"]
        out = []
        for i in range(0, len(ids), 50):
            out += self.run("OrderListPageQuery", text, {"rowIds": ids[i:i + 50]})["data"]
        return out

    def cancel(self, ids):
        return self.run("BulkOrderUpsertMutation", CANCEL_MUTATION,
                        {"args": [{"row_id": i, "status": "CANCELLED"} for i in ids]})

    def close(self):
        self.ctx.close()


def copy_profile(src, dst):
    """the Qargo login, without the lock files of a browser that may have it open right now"""
    shutil.copytree(src, dst, symlinks=True,
                    ignore=shutil.ignore_patterns("Singleton*", "RunningChromeVersion", "*.lock", "lockfile"))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--dry-run", action="store_true", help="only list the orders it would cancel")
    ap.add_argument("--profile", type=Path, help="browser profile with the Qargo login (default: the bot's)")
    ap.add_argument("--today", type=datetime.date.fromisoformat,
                    help="test only, with --dry-run: act as if today were this date (YYYY-MM-DD)")
    args = ap.parse_args(argv)
    if args.today and not args.dry_run:
        ap.error("--today only works with --dry-run")
    today = args.today or datetime.date.today()
    log_path = paths.logs_dir() / f"cancel_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"
    lines = []

    def say(s=""):
        print(s, flush=True)
        lines.append(s)

    profile = args.profile or paths.profile_dir("chromium")
    ok = True
    say(f"cancel_overdue {datetime.datetime.now():%Y-%m-%d %H:%M}: open orders due before {today}"
        + ("  (DRY RUN: nothing is cancelled)" if args.dry_run else ""))
    from playwright.sync_api import sync_playwright
    with tempfile.TemporaryDirectory(prefix="qargo-cancel-") as tmp, sync_playwright() as pw:
        q = None
        try:
            if not profile.is_dir():
                raise NoAnswer(f"no Qargo login found ({profile}): log in once with the bot (python3 run.py)")
            copy_profile(profile, Path(tmp) / "profile")
            q = Qargo(pw, Path(tmp) / "profile")
            todo = overdue(q.orders(q.search(today)), today)
            if not todo:
                say("Nothing to cancel.")
            else:
                say(f"{len(todo)} order(s) to cancel:")
                for o in todo:
                    say("  " + line(o))
                if not args.dry_run:
                    q.cancel([o["row_id"] for o in todo])
                    deadline = time.time() + CANCEL_ANSWER_S
                    while True:
                        now = {o["row_id"]: o["status"] for o in q.orders([o["row_id"] for o in todo])}
                        left = [o for o in todo if now.get(o["row_id"]) in OPEN]
                        if not left or time.time() > deadline:
                            break
                        q.page.wait_for_timeout(5000)
                    by = collections.Counter(now.get(o["row_id"]) for o in todo)
                    say(f"CANCELLED {by.get('CANCELLED', 0)} of {len(todo)}.")
                    for o in todo:
                        st = now.get(o["row_id"])
                        if st != "CANCELLED":
                            ok = False
                            say(f"  NOT CANCELLED {o['name']}: Qargo shows {st or 'nothing'}"
                                + (f" after {CANCEL_ANSWER_S // 60} min (internet?)" if st in OPEN else ""))
        except NoAnswer as e:
            ok = False
            say(f"!! {e}. Nothing was concluded; run it again.")
        except Exception as e:
            ok = False
            say(f"!! FAILED: {e}")
        finally:
            if q:
                q.close()
    try:
        log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"(log: {log_path})")
    except OSError as e:
        print(f"!! could not write the log {log_path}: {e}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
