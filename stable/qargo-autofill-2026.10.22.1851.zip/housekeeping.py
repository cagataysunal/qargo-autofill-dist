#!/usr/bin/env python3
"""Keep each day's trip documents together, and don't keep them forever.

  python3 housekeeping.py                  # move trip PDFs out of ~/Downloads, trash old files
  python3 housekeeping.py --keep-days 30

1. Trip PDFs the parser recognises (Cornelissen, Simon Loos, PostNL, Vredeveld, OCT, RD Container Transport, DFDS) are moved from ~/Downloads to
   documents/<today>/. Other files in Downloads are left alone; PDFs of the last 3 days among them are listed,
   so a trip document in a layout the parser does not know is never skipped in silence.
2. Things older than --keep-days (default 14) go to the macOS Trash - recoverable, never deleted outright:
   dated folders documents/<YYYY-MM-DD>/ and run output in this folder (orders_*.json, fill_log_*.txt, cancel_log_*.txt, mail_log_*.txt,
   error_*.png). The PDFs are attached to the orders in Qargo anyway.
   Always kept: orders.json and any documents folder that holds a file named .keep
   (documents/2026-10-09 is the parser's regression check).
run.py does both at the start of every run.
"""
import argparse, datetime, re, shutil, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import paths
TRASH = Path.home() / ".Trash"
KEEP_DAYS = 14
RUN_OUTPUT = ("orders_*.json", "fill_log_*.txt", "cancel_log_*.txt", "mail_log_*.txt", "assign_log_*.txt", "error_*.png")


def is_trip_pdf(path):
    from parse_trips import pdftext, detect, PdfToolMissing
    try:
        # page 1 names the customer; behind a cover sheet page 2 or 3 does. A big unrelated PDF stays quick.
        return detect(pdftext(path, max_pages=1)) is not None or detect(pdftext(path, max_pages=3)) is not None
    except PdfToolMissing:
        raise                 # no PDF can be read at all: that is not the same as "no trip PDFs today"
    except Exception:
        return False


def _free_name(folder, name):
    """name, or 'stem (2).pdf', 'stem (3).pdf'... if folder already has it"""
    p = folder / name
    n = 2
    while p.exists():
        p = folder / f"{Path(name).stem} ({n}){Path(name).suffix}"
        n += 1
    return p


def collect(downloads=None, documents=None, day=None, recognise=is_trip_pdf, trash=TRASH):
    """move recognised trip PDFs from downloads to documents/<day>/; returns the new paths"""
    downloads, documents = downloads or paths.downloads_dir(), documents or paths.documents_dir()
    day = day or datetime.date.today().isoformat()
    dest = documents / day
    moved = []
    for f in pdfs(downloads):
        if not recognise(f):
            continue
        dest.mkdir(parents=True, exist_ok=True)
        same = dest / f.name
        if same.exists() and same.read_bytes() == f.read_bytes():
            to_trash(f, trash)            # already there: the copy in Downloads goes to the Trash
            moved.append(same)
            continue
        target = _free_name(dest, f.name)
        try:
            shutil.move(str(f), str(target))
        except OSError as e:
            # e.g. still open in a PDF viewer (Windows locks it): say so and carry on with the other documents
            print(f"!! could not move {f} to {dest} ({type(e).__name__}: {e}); left it where it is "
                  f"(still open in another program?)")
            continue
        moved.append(target)
    return moved


def pdfs(folder):
    """the PDF files in folder, whatever the case of the extension"""
    return sorted(f for f in Path(folder).iterdir() if f.suffix.lower() == ".pdf" and f.is_file())


def left_behind(downloads=None, hours=72, now=None):
    """PDFs that arrived in downloads in the last `hours` (72: a Friday download is still seen on Monday) and are
    still there after collect(): no layout the parser knows. They are not read, so the caller must say so."""
    limit = (now or time.time()) - hours * 3600
    def arrived(f):                                  # a saved mail attachment can keep an older modification time
        try:
            st = f.stat()
        except OSError:
            return limit                             # cannot be looked at: list it rather than skip it
        return max(st.st_mtime, getattr(st, "st_birthtime", st.st_ctime))
    return [f for f in pdfs(downloads or paths.downloads_dir()) if arrived(f) >= limit]


def old_items(here=None, documents=None, keep_days=KEEP_DAYS, today=None):
    """dated document folders and run output older than keep_days (never orders.json or a folder with .keep)"""
    # run output: next to the code as always, or the data folder (orders) and its logs folder (logs, screenshots)
    folders = [here] if here else list(dict.fromkeys([paths.data_dir(), paths.logs_dir()]))
    documents = documents or paths.documents_dir()
    today = today or datetime.date.today()
    limit = today - datetime.timedelta(days=keep_days)
    out = []
    for d in sorted(Path(documents).glob("*")):
        if not (d.is_dir() and re.fullmatch(r"\d{4}-\d{2}-\d{2}", d.name)) or (d / ".keep").exists():
            continue
        try:
            if datetime.date.fromisoformat(d.name) < limit:
                out.append(d)
        except ValueError:
            pass
    for pattern in RUN_OUTPUT:
        for f in sorted(f for d in folders for f in Path(d).glob(pattern)):
            if f.name != "orders.json" and datetime.date.fromtimestamp(f.stat().st_mtime) < limit:
                out.append(f)
    return out


def to_trash(path, trash=TRASH):
    """move to the Trash (recoverable); returns the new path, or None if it could not be moved"""
    try:
        if not Path(trash).is_dir():      # Windows has no ~/.Trash: moving a folder there would quietly make one up
            raise FileNotFoundError(f"there is no folder {trash}")
        target = _free_name(Path(trash), Path(path).name)
        shutil.move(str(path), str(target))
        return target
    except Exception as e:
        print(f"!! could not move {path} to the Trash ({type(e).__name__}: {e}); left it where it is")
        return None


def tidy(keep_days=KEEP_DAYS, trash=TRASH):
    """trash old documents and run output; returns what was moved"""
    gone = [p for p in old_items(keep_days=keep_days) if to_trash(p, trash)]
    if gone:
        print(f"moved to the Trash (older than {keep_days} days): {[p.name for p in gone]}")
    return gone


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--keep-days", type=int, default=KEEP_DAYS)
    a = ap.parse_args()
    moved = collect()
    print(f"{len(moved)} trip PDF(s) from Downloads -> documents/{datetime.date.today().isoformat()}/")
    other = left_behind()
    if other:
        print(f"!! NOT READ, left in ~/Downloads (not a trip layout the parser knows): {[p.name for p in other]}")
    tidy(a.keep_days)


if __name__ == "__main__":
    main()
