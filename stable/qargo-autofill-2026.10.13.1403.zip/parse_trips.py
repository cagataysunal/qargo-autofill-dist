#!/usr/bin/env python3
"""Turn customer trip PDFs (Cornelissen, Simon Loos, PostNL route sheets, Vredeveld) into orders.json
for the Qargo autofill script.

Usage:  python3 parse_trips.py <pdf or folder> [...] -o orders.json
Needs the pip package pdfminer.six (pdf_layout.py reads the PDFs with it), or else `pdftotext` (poppler;
on macOS: brew install poppler).
"""
import json, re, shutil, subprocess, sys, argparse
from datetime import datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate_orders import validate, report

# ---------------------------------------------------------------- helpers
class PdfToolMissing(RuntimeError):
    """no PDF can be read on this machine: neither pdfminer.six nor poppler's pdftotext is there"""

def pdftext(path, max_pages=None):
    """the text of the PDF exactly as `pdftotext -layout <pdf> -` prints it (every page ends with a form feed).
    Made by pdf_layout.py (pdfminer.six + a port of poppler's layout rules): the same on Windows and macOS,
    no poppler needed. Only a Python without pdfminer.six still runs poppler's pdftotext itself.
    max_pages=1 reads only the first page (enough for detect())."""
    try:
        import pdfminer.pdfinterp        # brings in every pdfminer module pdf_layout.py uses
    except ImportError as e:
        exe = shutil.which("pdftotext")
        if not exe:
            raise PdfToolMissing(f"no PDF reader: pdfminer.six cannot be imported ({e}) and pdftotext (poppler) "
                                 f"is not on the PATH") from None
        # UTF-8 and \n whatever the system's settings are (Windows: ANSI code page, CRLF); bytes, so nothing is translated
        cmd = [exe, "-layout", "-enc", "UTF-8", "-eol", "unix"] + (["-l", str(max_pages)] if max_pages else [])
        return subprocess.run(cmd + [str(path), "-"], capture_output=True, check=True).stdout.decode("utf-8")
    from pdf_layout import pdf_layout_text
    return pdf_layout_text(path, max_pages)

def segs(line):
    """split a layout line into (start_col, text) segments separated by 2+ spaces"""
    return [(m.start(), m.group().strip()) for m in re.finditer(r"\S+(?: \S+)*", line)]

PC_RE = re.compile(r"^(\d{4})\s?([A-Z]{2})\b\s*(.*)$")          # NL postcode
BE_PC_RE = re.compile(r"^(\d{4})\s+([A-Z][\w' -]+)$")           # BE postcode + city

def norm_pc(pc):
    return re.sub(r"\s+", "", pc or "").upper()

def dmy(d):
    """'10/9/2026' (M/D/YYYY, Cornelissen) handled by caller; this takes D-M-YYYY or D/M/YYYY"""
    d_, m_, y_ = re.split(r"[-/]", d)
    return f"{int(d_):02d}/{int(m_):02d}/{y_}"

def mdy(d):
    m_, d_, y_ = d.split("/")
    return f"{int(d_):02d}/{int(m_):02d}/{y_}"

def loc(name, street, postcode=None, city=None, country="NL", query=None):
    street = (street or "").replace("<<NoData>>", "").strip()
    name = (name or "").strip()
    # Albert Heijn stores: "Albert Heijn 2266" (Simon Loos) or just "4149" / "3002 De Koel" (Cornelissen).
    # In Qargo they are stored as "AH Winkel <nr>" (+ "AH Winkel <nr> unloading adress").
    m = re.match(r"^(?:Albert Heijn\s+)?(\d{4})(?:\s|$)", name)
    store = m.group(1) if m else None
    if not query:
        mq = re.match(r"^(.*?\d+)", street)          # "Doornepol 11 -13" -> "Doornepol 11"
        query = mq.group(1) if mq else (street or name)
    d = {
        "name": name,
        "street": street,
        "postcode": norm_pc(postcode),
        "city": (city or "").strip(),
        "country": country,
        "query": query.strip(),
    }
    if store:
        d["store"] = store
        d["query"] = f"Winkel {store}"
    return d

def nl_join(*xs):
    """the non-empty texts, one per line (None when there are none)"""
    return "\n".join(x for x in xs if x) or None

def stop(location, date, start=None, end=None, duration=None, note=None, reference=None):
    s = {"location": location, "date": date}
    if start: s["start"] = start
    if end: s["end"] = end
    if duration: s["duration"] = duration
    if note: s["note"] = note
    if reference: s["reference"] = reference
    return s

# ------------------------------------------------------------- Cornelissen
KEEP_UNCOUPLE = True    # Afkoppelen = end stop (decided 9 Oct); --uncouple-as-note puts it in Instructions instead
CT_KEYS = ["Aankoppelen", "Afkoppelen", "Laden", "Lossen", "AH Stop", "Rust", "Wachten"]
CT_HEAD = re.compile(r"^\s*(" + "|".join(CT_KEYS) + r")\s+(\d{1,2}/\d{1,2}/\d{4})\s*(.*)$")
CT_PAGE = re.compile(r"^\d{1,2}/\d{1,2}/\d{4} \d{1,2}:\d{2}:\d{2} [AP]M\s+\d+\s*$")
TIME_RE = re.compile(r"^\d{2}:\d{2}$")
CT_GOODS = re.compile(r"\s*(\d+(?:\.\d+)?)\s+(.+?)\s{2,}[\d.]+\s+ldm")
CT_ROUTE_REF = re.compile(r"\b[A-Z]{2,6}\|\d{4}\|[\d-]+\b")    # "DCT|2026|41-6-620", "NOTE|2026|41-5-595724" (Referentie)

def ct_remarks(body):
    """Remark lines after the 'Opmerkingen' line, verbatim (route directions, 'VOORKANT', 'Niet op navigatie!').
    The page's 'Referentie DCT|2026|...' line can be printed over a remark line; pdftotext then gives
    'Referentie Verkeerslichten' + 'DCT|2026|41-6-620  links,' -> rebuilt as 'Verkeerslichten links,'.
    Returns (text or None, problem or None)."""
    i = next((k for k, x in enumerate(body) if x.strip().startswith("Opmerkingen")), None)
    if i is None:
        return None, None
    out, start, problem = [], None, None
    for x in body[i + 1:]:
        s = x.strip()
        if not s or CT_GOODS.match(x):
            continue
        if s.startswith("Referentie"):
            rest = s[len("Referentie"):].strip()
            if rest and not CT_ROUTE_REF.fullmatch(rest):
                start = rest                     # the start of a remark line that is printed over
            continue
        if CT_ROUTE_REF.search(s):
            s = re.sub(r"\s+", " ", CT_ROUTE_REF.sub("", s)).strip()
            if start is None:
                problem = f"a remark line is printed over by the route number: {x.strip()!r}"
            if not s:
                continue                         # the rest of the line follows on the next line
        if start is not None:
            s, start = f"{start} {s}", None
        out.append(s)
    if start is not None:
        out.append(start)
    return "\n".join(out) or None, problem

def parse_cornelissen(text, src):
    lines = [l for l in text.splitlines() if not CT_PAGE.match(l.strip())]
    rit = re.search(r"Ritnr\s+(\d+)", text).group(1)
    ma = re.search(r"Auto\s+T?(\S+)", text)
    charter = ma.group(1) if ma else None
    # an empty 'Klant Route nr' is followed on the same line by the 'Klant kilometers' label
    mr = re.search(r"Klant Route nr[ \t]+(?!Klant\b)(\S+)", text)
    route = mr.group(1) if mr else ""
    blocks, cur = [], None
    for l in lines:
        m = CT_HEAD.match(l)
        if m:
            cur = {"kind": m.group(1), "date": mdy(m.group(2)), "rest": m.group(3), "lines": []}
            blocks.append(cur)
        elif cur is not None:
            cur["lines"].append(l)
    loads, unloads, events, setup, teardown, header_note = {}, [], [], None, None, None
    load_recs, review = [], []      # every Laden in document order (two with the same dossier would overwrite in `loads`)
    if not route:
        review.append("'Klant Route nr' is empty on the document: customer reference left empty")
    if not any(b["kind"] in ("Laden", "Lossen") for b in blocks):
        review.append("the document prints no Laden or Lossen (only: "
                      + ", ".join(f"{b['kind']} {b['rest'].strip()}".strip() for b in blocks)
                      + "): there is nothing to make a consignment from, so this rit cannot be filled")
    for b in blocks:
        body = [x for x in b["lines"] if x.strip()]
        notes = [x.strip()[len("Opmerkingen"):].strip() for x in body if x.strip().startswith("Opmerkingen")]
        # address, time and dossier columns end at the goods line (or the remarks): remarks can run on
        # for many lines (route directions) and must not be read as address lines
        end = next((i for i, x in enumerate(body) if CT_GOODS.match(x)
                    or x.strip().startswith(("Opmerkingen", "Referentie"))), len(body))
        body_wo = body[:end] + [x for x in body[end:] if CT_GOODS.match(x)]
        time = None
        for x in body_wo:
            for _, t in segs(x):
                t2 = t.replace("•> Dock:", "").strip()
                mm = re.search(r"(\d{2}:\d{2})$", t2)
                if mm and (TIME_RE.match(t) or t.startswith("•>")):
                    time = time or mm.group(1)
        dock = None
        for x in body_wo:
            md = re.search(r"Dock:\s*(\S+)", x)
            if md: dock = md.group(1)
        remarks, problem = ct_remarks(body)
        if problem:
            review.append(f"{b['kind']} {b['date'][:5]} {time}: {problem}; check the PDF")
        if b["kind"] in ("Aankoppelen", "Afkoppelen"):
            # "DCT Pegasusweg 1 Tilburg" -> no postcode on the document
            place = b["rest"].strip()
            st = stop({"raw": place}, b["date"], time, time, note=nl_join(f"Dock: {dock}" if dock else None, remarks))
            if b["kind"] == "Aankoppelen":
                setup = st
                if notes and notes[0] and notes[0] != route.replace("|2026|", "|2026|"):
                    header_note = notes[0]
            elif KEEP_UNCOUPLE:
                teardown = st
            else:
                # Afkoppelen is often followed right away by the next rit's Aankoppelen at the same
                # place (overlapping times in Qargo) - keep it as a note, not as a stop
                events.append(nl_join(f"Afkoppelen {b['date'][:5]} {time} {place}", remarks))
            continue
        if b["kind"] in ("AH Stop", "Rust", "Wachten"):
            extra = f" ({notes[0]})" if notes and notes[0] else ""
            events.append(nl_join(f"{b['kind']} {b['date'][:5]} {time}{extra}", remarks))
            continue
        # Laden / Lossen: name on head line (before 'Klant'), address column = first segment per line
        name = re.split(r"\s{2,}Klant\b", b["rest"])[0].strip()
        addr, dossier, goods = [], None, None
        for x in body_wo:
            sg = segs(x)
            for _, t in sg:
                md = re.match(r"Dossier\s+(\S+)", t)
                if md: dossier = md.group(1)
            mg = CT_GOODS.match(x)
            if mg:
                goods = {"quantity": int(float(mg.group(1))), "description": mg.group(2).strip()}
                continue
            first = [t for _, t in sg if not TIME_RE.match(t) and not t.startswith("•>")
                     and not t.startswith("Dossier") and not t.startswith("Klant")
                     and not t.startswith("Laadplaats") and not t.startswith("Referentie")]
            if first and sg and sg[0][0] < 60:
                addr.append(first[0])
        # addr: [name-continuation..., street, postcode city, country]
        country = "NL"
        if addr and addr[-1] in ("Nederland", "België", "Belgie", "Duitsland"):
            country = {"Nederland": "NL", "België": "BE", "Belgie": "BE", "Duitsland": "DE"}[addr.pop()]
        pc = city = None
        if addr:
            m1 = PC_RE.match(addr[-1]) or BE_PC_RE.match(addr[-1])
            if m1:
                pc_line = addr.pop()
                if PC_RE.match(pc_line):
                    mm = PC_RE.match(pc_line); pc, city = mm.group(1) + mm.group(2), mm.group(3)
                else:
                    mm = BE_PC_RE.match(pc_line); pc, city = mm.group(1), mm.group(2)
        street = addr.pop() if addr else ""
        street = street.replace("Losadres:", "").strip()
        if addr: name = (name + " " + " ".join(addr)).strip()
        n = {"duration": None, "dock": dock, "text": [], "remarks": remarks}
        for nt in notes:
            md = re.search(r"(Lostijd|Laadtijd)\s+(\d{2}:\d{2})#?", nt)
            if md: n["duration"] = md.group(2); nt = nt.replace(md.group(0), "")
            nt = re.sub(r"Dock\s+\S+#", "", nt)
            parts = [p.strip(" #") for p in nt.split("|") if p.strip(" #")]
            n["text"] += parts
        if remarks:
            n["remarks"] = nl_join(" | ".join(n["text"]), remarks)
        rec = {"kind": b["kind"], "date": b["date"], "time": time, "dossier": dossier, "seq": len(load_recs) + len(unloads),
               "loc": loc(name, street, pc, city, country), "goods": goods, "notes": n}
        if b["kind"] == "Laden":
            loads[dossier] = rec
            load_recs.append(rec)
        else:
            unloads.append(rec)
    # registry to resolve coupling places (no postcode printed)
    consignments = []
    for u in unloads:
        l = loads.get(u["dossier"])
        if not l:
            raise ValueError(f"{src}: unload dossier {u['dossier']} has no load")
        instr = list(dict.fromkeys(l["notes"]["text"] + u["notes"]["text"]))
        consignments.append({
            "reference": u["dossier"],
            "instructions": "\n".join(instr) or None,
            "pickup": stop(l["loc"], l["date"], l["time"], l["time"], l["notes"]["duration"],
                           note=nl_join(f"Dock: {l['notes']['dock']}" if l["notes"]["dock"] else None, l["notes"]["remarks"])),
            "delivery": stop(u["loc"], u["date"], u["time"], u["time"], u["notes"]["duration"],
                             note=u["notes"]["remarks"]),
            "goods": [l["goods"] or u["goods"] or {"quantity": 1}],
        })
    # a Laden no Lossen uses still gets its own collection stop (nothing printed may disappear),
    # paired with the first unload after it
    used = {id(loads[u["dossier"]]) for u in unloads if u["dossier"] in loads}
    for l in load_recs:
        if id(l) in used: continue
        u = next((u for u in unloads if u["seq"] > l["seq"]), None)
        if u is None:
            events.append(f"Laden {l['date'][:5]} {l['time']} {l['loc']['name']} {l['loc']['street']} (dossier {l['dossier']})")
            review.append(f"load {l['loc']['name']} {l['time']} (dossier {l['dossier']}) comes after the last unload: "
                          f"NOT a stop in the order (only in Instructions) - add it by hand")
            continue
        review.append(f"load {l['loc']['name']} {l['time']} (dossier {l['dossier']}) has no unload of its own; "
                      f"paired with the first unload after it ({u['loc']['name']} {u['time']}, dossier {u['dossier']})")
        consignments.append({
            "reference": l["dossier"], "instructions": "\n".join(l["notes"]["text"]) or None,
            "pickup": stop(l["loc"], l["date"], l["time"], l["time"], l["notes"]["duration"],
                           note=nl_join(f"Dock: {l['notes']['dock']}" if l["notes"]["dock"] else None, l["notes"]["remarks"])),
            "delivery": stop(u["loc"], u["date"], u["time"], u["time"], u["notes"]["duration"],
                             note=u["notes"]["remarks"]),
            "goods": [l["goods"] or {"quantity": 1}],
        })
    # In the order the stops are driven: by unload time, then load time. The loads are printed (and loaded) last
    # drop first, so load order would put the deliveries in Qargo the wrong way round (CT-3994523: unloads
    # 17:59, 16:30, 15:08). Same times: the document's load order.
    order_idx = {d: i for i, d in enumerate(loads)}
    when = lambda s: datetime.strptime(f"{s['date']} {s.get('start') or s.get('end') or '00:00'}", "%d/%m/%Y %H:%M")
    consignments.sort(key=lambda c: (when(c["delivery"]), when(c["pickup"]), order_idx.get(c["reference"], 99)))
    instr = ([charter] if charter else []) + ([header_note] if header_note else []) + events
    return {
        "customer": "Cornelissen", "customer_reference": route, "ritnummer": int(rit),
        "instructions": "\n".join(instr) or None,
        "setup": setup, "teardown": teardown, "consignments": consignments,
        "source": src, "key": f"CT-{rit}",
        **({"review": review} if review else {}),
    }

# -------------------------------------------------------------- Simon Loos
def parse_simonloos(text, src):
    out = []
    for part in text.split("TRANSPORTOPDRACHT")[1:]:
        if "REFERENTIENUMMER" not in part:
            continue
        ref = re.search(r"REFERENTIENUMMER:\s*(\d+)", part).group(1)
        desc = re.search(r"Ritomschrijving:\s*(.+)", part).group(1).strip().rstrip(" -")
        # every Ordernummer and every "Ritnr. 183" in the stop remarks, in printed order: a "koppel" rit
        # ("DCZ koppel 2311 - route 183/231") is two trips under one REFERENTIENUMMER
        ordnrs = list(dict.fromkeys(re.findall(r"Ordernummer:\s*(\d+)", part)))
        md = re.search(r"Ritnr\.?\s+(\d+)", desc)
        ritnrs = [md.group(1)] if md else list(dict.fromkeys(re.findall(r"Ritnr\.?\s+(\d+)", part)))
        mt = re.search(r"Getrokken eenheid:\s*\S*?/(\S+)", part)
        charter = mt.group(1) if mt else None
        body = part.split("OVEREENGEKOMEN PRIJS")[0]
        lines = [l for l in body.splitlines()
                 if l.strip() and not re.match(r"^\s*Pagina \d+ van \d+", l) and not l.strip().startswith("---")
                 and "Aantal palletplaatsen" not in l]
        stops, cur = [], None
        for l in lines:
            m = re.match(r"^(LADEN|LOSSEN)\s+(.*?)\s*Referentie:\s*$", l)
            if m:
                cur = {"kind": m.group(1), "name": m.group(2).strip(), "lines": []}
                stops.append(cur); continue
            if cur is not None:
                cur["lines"].append(l.strip())
        parsed = []
        for s in stops:
            L = s["lines"]
            m = re.match(r"(\d{1,2}-\d{1,2}-\d{4})\s+(\d{2}:\d{2})-(\d{2}:\d{2})\s+(.*)", L[0])
            date, t1, t2, street = dmy(m.group(1)), m.group(2), m.group(3), m.group(4)
            country = "NL"
            mp = next((PC_RE.match(x) for x in L[1:4] if PC_RE.match(x)), None)
            if mp:
                pc, city = mp.group(1) + mp.group(2), mp.group(3).title()
            else:
                mb = next((BE_PC_RE.match(x) for x in L[1:4] if BE_PC_RE.match(x)), None)
                if not mb:
                    raise ValueError(f"{src} {ref}: no postcode line after {L[:4]}")
                pc, city, country = mb.group(1), mb.group(2).title(), "BE"
            notes = []
            if "Opmerkingen:" in L:
                i = L.index("Opmerkingen:") + 1
                while i < len(L) and not L[i].startswith("Ordernummer:"):
                    notes.append(L[i]); i += 1
            parsed.append({"kind": s["kind"], "loc": loc(s["name"], street, pc, city, country),
                           "date": date, "start": t1, "end": t2, "note": " ".join(notes) or None})
        load, load_used = None, False
        consignments, review, pending = [], [], []
        if len(ritnrs) != 1:
            review.append((f"no 'Ritnr' in the Ritomschrijving {desc!r} and the stop remarks name "
                           f"{len(ritnrs)} trip numbers ({', '.join(ritnrs)})" if ritnrs else
                           f"no 'Ritnr' anywhere in the PDF (Ritomschrijving {desc!r})")
                          + ": ritnummer left empty - fill it in by hand")
        teardown = None
        sl_stop = lambda x: stop(x["loc"], x["date"], x["start"], x["end"], note=x["note"])
        for p in parsed:
            if p["kind"] == "LADEN":
                # LADEN right after LADEN (e.g. DCZ dock 429, DCZ dock 134, then DCM): the earlier one has no
                # LOSSEN of its own. It still gets its own collection stop (nothing printed may disappear),
                # paired with the first delivery after it.
                if load is not None and not load_used:
                    pending.append(load)
                load, load_used = p, False
                continue
            for u in pending:
                consignments.append({"reference": None, "instructions": None, "pickup": sl_stop(u),
                                     "delivery": sl_stop(p), "goods": [{"quantity": 1}]})
                review.append(f"load {u['loc']['name']} {u['start']}-{u['end']} ({u['note'] or 'no dock'}) has no "
                              f"unload of its own in the PDF; paired with the first delivery after it "
                              f"({p['loc']['name']} {p['start']})")
            pending = []
            consignments.append({
                "reference": None, "instructions": None,
                "pickup": sl_stop(load), "delivery": sl_stop(p),
                "goods": [{"quantity": 1}],
            })
            load_used = True
        extra = []
        for u in pending + ([load] if load is not None and not load_used else []):
            # a load after the last delivery: no printed stop to pair it with - say so loudly
            extra.append(f"Ook laden: {u['loc']['name']} {u['loc']['street']} {u['date'][:5]} {u['start']}-{u['end']}"
                         + (f" {u['note']}" if u["note"] else ""))
            review.append(f"load {u['loc']['name']} {u['start']}-{u['end']} comes after the last delivery: "
                          f"NOT a stop in the order (only in Instructions) - add it by hand")
        out.append({
            "customer": "Simon Loos", "customer_reference": ref,
            "ritnummer": int(ritnrs[0]) if len(ritnrs) == 1 else None,
            "instructions": "\n".join(([charter] if charter else []) + [desc]
                                      + ([f"Ordernummer: {', '.join(ordnrs)}"] if ordnrs else []) + extra),
            "setup": None, "teardown": teardown, "consignments": consignments,
            "source": src, "key": f"SL-{ref}",
            **({"review": review} if review else {}),
        })
    return out

# ------------------------------------------------------------------ PostNL
PN_ACTIONS = ["Startactie's", "Eindactie's", "Start", "Einde", "Pauze", "Laden", "Lossen", "Wachten"]
PN_HEAD = re.compile(r"^\s?(" + "|".join(re.escape(a) for a in PN_ACTIONS) + r")(\s{2,}|$)")
PN_SKIP = re.compile(r"^\s*(Routenaam|Route-inhoud|Back-up middel|Kilometers|Pauze \(min\)|Startlocatie|Actie\s+Adres|starttijd|Pagina \d|Bij calamiteiten|nemen met|E-mail|CRTS|Telefoon)")
TD = re.compile(r"(\d{2}:\d{2}) (\d{2}-\d{2}-\d{4})")

def parse_postnl(text, src):
    out = []
    # each route = pages sharing the same Dienstnummer
    routes = {}
    for page in text.split("\f"):
        m = re.search(r"Dienstnummer\s+(\S+)", page)
        if not m: continue
        routes.setdefault(m.group(1), {"name": re.search(r"Routenaam\s+(\S+)", page).group(1), "pages": []})["pages"].append(page)
    for dienst, r in routes.items():
        cols = None; rows = []; cur = None
        for page in r["pages"]:
            for l in page.splitlines():
                if re.match(r"^\s*Actie\s+Adres", l):
                    cols = {"mid": l.index("Geplande"), "goods": l.index("Ladingdragers")}
                if not l.strip() or PN_SKIP.match(l): continue
                m = PN_HEAD.match(l)
                if m:
                    cur = {"action": m.group(1), "first": l, "cont": []}; rows.append(cur)
                elif cur is not None:
                    cur["cont"].append(l)
        recs = []
        for row in rows:
            sg = segs(row["first"])
            name = sg[1][1] if len(sg) > 1 and not TD.match(sg[1][1]) else ""
            tds = TD.findall(row["first"])
            goods = [t for c, t in sg if c >= cols["goods"] - 3]
            addr, mid = [], []
            for l in row["cont"]:
                for c, t in segs(l):
                    if c >= cols["goods"] - 3: goods.append(t)
                    elif c >= cols["mid"] - 3: mid.append(t)
                    else: addr.append(t)
            pc = city = None; country = "NL"; street = addr[0] if addr else ""
            for i, a in enumerate(addr[1:], 1):
                mm = re.match(r"^(\d{4})\s?([A-Z]{2})\s+(.*)$", a)
                if mm: pc, city = mm.group(1) + mm.group(2), mm.group(3).title()
                mb = re.match(r"^(\d{4})\s+(.+?)\s+BE$", a)
                if mb: pc, city, country = mb.group(1), mb.group(2), "BE"
                # the street is the line above the postcode. Lines above that are the rest of a long name:
                # "FEDEX EXPRESS OPERATIONS FIC" / "VELDHOVEN" / "De Run 4255" / "5503LM VELDHOVEN" (B-009196-0026)
                if (mm or mb) and i > 1 and street == addr[0]:
                    name, street = " ".join([name] + addr[:i - 1]).strip(), addr[i - 1]
            code = mid[-1] if mid else None
            notes = [x for x in mid[:-1]] if mid else []
            # "OVP EINDHOVEN (CONTROLEER KLEP)": a hint inside the stop name (check the tail lift). The Qargo location
            # is just "OVP Eindhoven", so keep the hint as a stop note too
            if re.search(r"\([^)]+\)", name):
                notes.append(f"Printed: {name}")
            g = []
            for t in goods:
                mg = re.match(r"(\d+)\s+(.+)", t)
                if mg: g.append({"quantity": int(mg.group(1)), "description": mg.group(2)})
            recs.append({"action": row["action"], "name": name,
                         "loc": loc(name, street, pc, city, country),
                         "start": tds[0][0] if tds else None, "sdate": dmy(tds[0][1]) if tds else None,
                         "end": tds[1][0] if len(tds) > 1 else None, "edate": dmy(tds[1][1]) if len(tds) > 1 else None,
                         "code": code, "notes": notes, "goods": g, "raw_mid": mid})
        setup = teardown = None; events = []; loads = []; consignments = []; used = set(); review = []
        pn_pair = lambda l, u: {
            "reference": u["code"], "instructions": None,
            "pickup": stop(l["loc"], l["sdate"], l["start"], l["end"],
                           note="\n".join(l["notes"]) or None, reference=l["code"]),
            "delivery": stop(u["loc"], u["sdate"], u["start"], u["end"],
                             note="\n".join(u["notes"]) or None, reference=u["code"]),
            "goods": l["goods"] or u["goods"] or [{"quantity": 1}],
        }
        for rc in recs:
            a = rc["action"]
            if a == "Start":
                setup = stop(rc["loc"], rc["sdate"], rc["start"], rc["start"])
                setup["activity"] = "Start of day"
            elif a == "Einde":
                teardown = stop(rc["loc"], rc["sdate"], rc["start"], rc["start"])
                teardown["activity"] = "End of day"
            elif a in ("Pauze", "Wachten"):
                if a == "Pauze":
                    events.append(f"Pauze {rc['start']}-{rc['end']} {rc['loc']['street']} {rc['loc']['city']}".strip())
                else:
                    events.append(f"Wachten: {rc['name']}")
            elif a == "Laden":
                loads.append(rc)
            elif a == "Lossen":
                match = [l for l in loads if l["code"] == rc["code"]]
                l = match[-1] if match else (loads[-1] if loads else None)
                if l is None: raise ValueError(f"{src} {dienst}: unload without load")
                if not match:
                    print(f"WARNING {dienst}: unload {rc['name']} code {rc['code']} paired with previous load {l['name']}", file=sys.stderr)
                    review.append(f"unload {rc['name']} {rc['start']} (code {rc['code']}) has no load with that code; "
                                  f"paired with the previous load {l['name']} {l['start']}")
                used.add(id(l))
                consignments.append(pn_pair(l, rc))
        # a Laden no Lossen uses still gets its own collection stop, paired with the first Lossen after it
        for i, l in enumerate(recs):
            if l["action"] != "Laden" or id(l) in used: continue
            u = next((u for u in recs[i + 1:] if u["action"] == "Lossen"), None)
            if u is None:
                events.append(f"Laden {l['start']} {l['name']} (code {l['code']})")
                review.append(f"load {l['name']} {l['start']} (code {l['code']}) comes after the last unload: "
                              f"NOT a stop in the order (only in Instructions) - add it by hand")
                continue
            review.append(f"load {l['name']} {l['start']} (code {l['code']}) has no unload with that code; "
                          f"paired with the first unload after it ({u['name']} {u['start']})")
            consignments.append(pn_pair(l, u))
        hired = sorted({g["description"] for c in consignments for g in c["goods"]
                        if re.search(r"auto met chauffeur", g.get("description") or "", re.I)})
        if hired:
            review.append(f"goods are {hired[0]!r} ('dagspoed'): PostNL books the truck with driver for the day, "
                          f"not a load - check what this order should be")
        out.append({
            "customer": "PostNL", "customer_reference": dienst, "ritnummer": None,
            "instructions": "\n".join([r["name"]] + events),
            "setup": setup, "teardown": teardown, "consignments": consignments,
            "source": src, "key": f"PN-{dienst}",
            **({"review": review} if review else {}),
        })
    return out

# --------------------------------------------------------------- Vredeveld
VRD_COLS = re.compile(r"^\s*Laden\s+Lossen\s+Gewicht\s*$")
VRD_ROW = re.compile(r"^\s*(\d{2}-\d{2}-\d{4})\s+(\S.*?)\s+(\d{2}-\d{2}-\d{4})\s+(\S.*?)\s*$")
VRD_GOODS = re.compile(r"^\s*[\d.,]+\s?ton\s+(.*?)\s{2,}(\S+)\s+([\d.,]+)\s?kg\s*$")
VRD_TOTAL = re.compile(r"^\s*(Subtotaal|Totaal Gewicht)\s+([\d.,]+)\s?kg\s*$")
VRD_PC = re.compile(r"^(\d{4}\s?[A-Z]{2}|\d{4,5})\s+(.+?),\s*(\S.*)$")      # "6651 KD Druten, Nederland"
# "0600u leveren", "lossen om 0600 uur": the delivery time, printed left under a row
VRD_TIME = re.compile(r"^(?:(?:lossen|leveren)\s+om\s+)?(\d{2})[:.]?(\d{2})\s?u(?:ur)?(?:\s+(?:leveren|lossen))?$", re.I)
VRD_AFTER = re.compile(r"\bna\s+(\d{1,2})[.:](\d{2})\s*(?:u(?:ur)?\s+)?leveren\b", re.I)   # "Na 09.00 leveren" in a note
VRD_CLOCK = re.compile(r"\b\d{1,2}[.:]\d{2}\b|\b\d{4}\s?u(?:ur)?\b", re.I)
VRD_COUNTRY = {"nederland": "NL", "belgië": "BE", "belgie": "BE", "duitsland": "DE"}
VRD_ZE = re.compile(r"zero.?emissie", re.I)

def vrd_kg(s):
    """'31.815' -> 31815, '84' -> 84, '1.234,5' -> 1234.5 (the dot is the thousands separator)"""
    kg = float(s.replace(".", "").replace(",", "."))
    return int(kg) if kg == int(kg) else kg

def vrd_address(lines, src):
    """address lines of one side of a row (name, street, 'postcode city, country', anything printed under it)
    -> (location, extra lines)"""
    i = next((k for k, x in enumerate(lines) if k and VRD_PC.match(x)), None)
    if i is None:
        raise ValueError(f"{src}: no 'postcode city, country' line under {lines[0]!r}: {lines[1:]}")
    m = VRD_PC.match(lines[i])
    country = VRD_COUNTRY.get(m.group(3).strip().lower())
    if not country:
        raise ValueError(f"{src}: unknown country {m.group(3)!r} under {lines[0]!r}")
    return loc(lines[0], " ".join(lines[1:i]), m.group(1), m.group(2), country), lines[i + 1:]

def parse_vredeveld(text, src):
    """'Transportopdracht' of Vredeveld Logistic Solutions: one trip per PDF. Mapping as decided on 8 Oct 2026:
    Laadreferentie -> Customer Reference, Rit nr. -> Ritnummer, Opmerking -> Instructions, one consignment per
    VO-number (also when one row lists several), the kg column -> Total weight, the notes under a row ('Tel:' text,
    'i.c.m. VO-...') -> consignment instructions, '0600u leveren' / 'lossen om 0600 uur' / a note 'Na 09.00 leveren'
    -> delivery start time."""
    if len(set(re.findall(r"Rit nr\.\s+(\d+)", text))) > 1 or len(re.findall(r"Totaal Gewicht", text)) > 1:
        raise ValueError(f"{src}: several trips in one PDF; only one per PDF is read")
    body = []
    for page in text.split("\f"):                    # per page: what is between the letterhead and the footer
        L = page.splitlines()
        a = next((i for i, x in enumerate(L) if "K.v.K.-nr." in x), None)
        if a is None:
            if page.strip():
                raise ValueError(f"{src}: a page without the Vredeveld letterhead")
            continue
        b = next((i for i, x in enumerate(L) if "GRAAG BEVESTIGING" in x), len(L))
        body += L[a + 1:b]
    k = next((i for i, x in enumerate(body) if x.strip().startswith("Kosten Omschrijving")), len(body))
    body = [x for x in body[:k] if x.strip()]        # the cost table and the signature are not part of the order
    head = "\n".join(body)
    rits = set(re.findall(r"Rit nr\.\s+(\d+)", head))
    refs = set(re.findall(r"Laadreferentie[ \t]+(\S(?:.*\S)?)[ \t]*$", head, re.M))
    if len(rits) != 1 or len(refs) != 1:
        raise ValueError(f"{src}: expected one Rit nr. and one Laadreferentie, found {sorted(rits)} / {sorted(refs)}")
    rit, ref = rits.pop(), refs.pop()
    c0 = next((i for i, x in enumerate(body) if VRD_COLS.match(x)), None)
    if c0 is None:
        raise ValueError(f"{src}: no 'Laden / Lossen / Gewicht' header")
    o0 = next((i for i, x in enumerate(body[:c0]) if "Opmerking:" in x), None)
    review, remark = [], None
    for x in body[:c0 if o0 is None else o0 + 1]:    # the header fields; anything else printed there is reported
        x = x.split("Opmerking:")[0].strip()
        if x and not re.match(r"(Rit nr\.|Datum\s|Crediteur nr\.)", x):
            review.append(f"line above the rows is not in the order: {x!r}")
    if o0 is not None:                               # the trip remark, e.g. "KOOIAAP"; usually empty
        remark = nl_join(*[re.sub(r"\s+", " ", x).strip()
                           for x in [body[o0].split("Opmerking:", 1)[1]] + body[o0 + 1:c0]])
    blocks, cur, total = [], None, None
    for l in body[c0 + 1:]:
        if VRD_COLS.match(l):
            continue
        m = VRD_ROW.match(l)
        if m:
            cur = {"dates": (dmy(m.group(1)), dmy(m.group(3))), "split": m.start(3), "addr": ([m.group(2)], [m.group(4)]),
                   "goods": [], "subtotal": None, "left": [], "notes": []}
            blocks.append(cur); continue
        m = VRD_TOTAL.match(l)
        if m and m.group(1) == "Totaal Gewicht":
            total = vrd_kg(m.group(2)); continue
        if cur is None:
            review.append(f"line above the first load is not in the order: {l.strip()!r}"); continue
        if m:
            cur["subtotal"] = vrd_kg(m.group(2)); continue
        m = VRD_GOODS.match(l)
        if m:
            cur["goods"].append((m.group(1).strip(), m.group(2), vrd_kg(m.group(3)))); continue
        if not cur["goods"]:                         # still in the address: left of the unload date = load side
            for col, t in segs(l):
                cur["addr"][0 if col < cur["split"] else 1].append(t)
            continue
        # under the goods lines: left a delivery time ("0600u leveren"), right the notes. 'Tel:' starts a note,
        # a line without it continues the note above (a wrapped line), or is a note of its own ("i.c.m. VO-...")
        (col, first), rest = segs(l)[0], l.strip()
        if col < cur["split"] // 2:
            cur["left"].append(first)
            rest = l[col + len(first):].strip()
        rest = re.sub(r"\s+", " ", rest)
        if rest.startswith("Tel:"):
            cur["notes"].append(rest[4:].strip())
        elif rest and cur["notes"]:
            cur["notes"][-1] = f"{cur['notes'][-1]} {rest}".strip()
        elif rest:
            cur["notes"].append(rest)
    if not blocks:
        raise ValueError(f"{src}: no load / unload rows found")
    consignments, zero_emission, timed = [], [], set()
    for b in blocks:
        b["sides"] = [vrd_address(lines, src) for lines in b["addr"]]
        if any(VRD_TIME.match(x) for x in b["left"]):
            timed.add(json.dumps(b["sides"][1][0], sort_keys=True))
    for b in blocks:
        where = f"{b['addr'][0][0]} -> {b['addr'][1][0]}"
        sides = []
        for L, extra in b["sides"]:
            note = []
            for x in extra:                          # printed under the address, e.g. "Let op: ZERO-emissiezone!"
                if VRD_ZE.search(x):
                    note.append("!!! LET OP: ZERO-EMISSIEZONE !!!")
                    line = f"!!! LET OP: ZERO-EMISSIEZONE bij {L['name']} ({L['street']}) !!!"
                    if line not in zero_emission:
                        zero_emission.append(line)
                    if re.sub(r"let op:?|zero.?emissie\s?zone|\W", "", x, flags=re.I):
                        note.append(x)               # more than the usual sentence on that line: keep it as printed
                else:
                    note.append(x)
                    review.append(f"{where}: {x!r} is printed under the address of {L['name']}; kept as that "
                                  f"stop's note")
            sides.append((L, nl_join(*note)))
        times, texts = [], []
        for x in b["left"]:
            m = VRD_TIME.match(x)
            if m: times.append(f"{m.group(1)}:{m.group(2)}")
            else: texts.append(x)
        if texts:
            review.append(f"{where}: {texts} is printed where the delivery time usually is; kept in the instructions")
        if len(set(times)) > 1:
            review.append(f"{where}: several delivery times printed {times}; the first one is used")
        # the row's notes go to every consignment of the row; a note that is part of another one is not repeated
        notes = list(dict.fromkeys(n for n in b["notes"] if n))
        notes = [n for n in notes if not any(n != other and n in other for other in notes)]
        # "Na 09.00 leveren" in a note is a delivery time like "0900u leveren" (decided 12 Oct); the note stays too
        if not times:
            times = [f"{int(m.group(1)):02d}:{m.group(2)}" for n in notes for m in VRD_AFTER.finditer(n)][:1]
        # any other note with a time stays a note: someone must decide whether it is a time window.
        # Not for a return from a place that has its delivery time: there the same remark is printed again.
        if not times and any(VRD_CLOCK.search(n) for n in notes) \
                and json.dumps(sides[0][0], sort_keys=True) not in timed:
            review.append(f"{where}: the note {' / '.join(notes)!r} names a time, but no time window is set "
                          f"(only '0600u leveren' / 'lossen om 0600 uur' / 'Na 09.00 leveren' set one)")
        if not b["goods"]:
            review.append(f"{where}: no goods line (VO-number, weight) under this row")
        odd = [vo for _, vo, _ in b["goods"] if not re.fullmatch(r"VO-\d+", vo)]
        if odd:
            review.append(f"{where}: {odd} does not look like a VO-number; check the goods line")
        if datetime.strptime(b["dates"][1], "%d/%m/%Y") < datetime.strptime(b["dates"][0], "%d/%m/%Y"):
            review.append(f"{where}: the PDF prints the unload date {b['dates'][1]} before the load date "
                          f"{b['dates'][0]}; ask Vredeveld which is right")
        weights = [kg for _, _, kg in b["goods"]]
        if b["subtotal"] is not None and abs(sum(weights) - b["subtotal"]) > 0.5:
            review.append(f"{where}: the goods lines add up to {sum(weights):g} kg, the PDF prints Subtotaal "
                          f"{b['subtotal']:g} kg - a line was not read")
        for desc, vo, kg in b["goods"] or [(None, None, None)]:
            g = {"quantity": 1}
            if desc: g["description"] = desc
            if kg is not None: g["weight_kg"] = kg
            consignments.append({
                "reference": vo, "instructions": nl_join(*texts, *notes),
                "pickup": stop(sides[0][0], b["dates"][0], note=sides[0][1]),
                "delivery": stop(sides[1][0], b["dates"][1], start=times[0] if times else None, note=sides[1][1]),
                "goods": [g],
            })
    weights = [g["weight_kg"] for c in consignments for g in c["goods"] if "weight_kg" in g]
    if total is None:
        review.append("no 'Totaal Gewicht' line found: check that every row of the PDF is in the order")
    elif abs(sum(weights) - total) > 0.5:
        review.append(f"the consignments add up to {sum(weights):g} kg, the PDF prints Totaal Gewicht {total:g} kg "
                      f"- a row was not read")
    return {
        "customer": "Vredeveld", "customer_reference": ref, "ritnummer": int(rit),
        "instructions": nl_join(remark, *zero_emission),
        "setup": None, "teardown": None, "consignments": consignments,
        "source": src, "key": f"VRD-{rit}",
        **({"review": review} if review else {}),
    }

# ------------------------------------------------------------------- main
def detect(text):
    if "Cornelissen Transport" in text and "Chauffeurs instructie" in text: return "cornelissen"
    if "Simon Loos" in text and "TRANSPORTOPDRACHT" in text: return "simonloos"
    if "Route-inhoud" in text and "Dienstnummer" in text: return "postnl"
    if "Vredeveld Logistic Solutions" in text and "Laadreferentie" in text: return "vredeveld"
    return None

def resolve_coupling(orders):
    """Coupling/uncoupling places are printed as one string without postcode, e.g.
    'DCT Pegasusweg 1 Tilburg'. Match them to a street seen elsewhere in the batch."""
    known = {}
    for o in orders:
        for c in o["consignments"]:
            for s in (c["pickup"], c["delivery"]):
                L = s["location"]
                if L.get("street"): known.setdefault(L["street"].lower(), L)
    for o in orders:
        for key in ("setup", "teardown"):
            s = o.get(key)
            if not s or "raw" not in s["location"]: continue
            raw = s["location"]["raw"]
            hit = None
            for st, L in sorted(known.items(), key=lambda kv: -len(kv[0])):
                if st and st in raw.lower():
                    hit = L; break
            if hit:
                s["location"] = dict(hit, name=raw)
            else:
                m = re.search(r"([A-Za-z][\w'.-]*\s+\d+(?:\s?[A-Z]\b)?)\s+([A-Za-z][\w -]*)$", raw)
                street, city = (m.group(1), m.group(2)) if m else (raw, "")
                s["location"] = loc(raw, street, None, city)
                s["location"]["unverified"] = True

def add_page_ranges(orders, text):
    """Several orders in one PDF (Simon Loos: 2-3 rits, PostNL: several routes): give each its pages
    ([first, last], 1-based, inclusive: its own first page up to the page before the next order), so the bot attaches
    only those pages ("Select page range" in Qargo). An order whose first page can't be found gets the whole PDF."""
    if len(orders) < 2:
        return
    pages = text.split("\f")
    last = max((i for i, pg in enumerate(pages, 1) if pg.strip()), default=1)
    marker = {"Simon Loos": r"REFERENTIENUMMER:\s*{}\b", "PostNL": r"Dienstnummer\s+{}\b"}
    def first_page(o):
        rx = marker.get(o["customer"], "").format(re.escape(o["customer_reference"]))
        return next((i for i, pg in enumerate(pages, 1) if rx and re.search(rx, pg)), None)
    starts = [(first_page(o), n) for n, o in enumerate(orders)]
    found = sorted(s for s in starts if s[0] is not None)
    for k, (s, n) in enumerate(found):
        orders[n]["pages"] = [s, found[k + 1][0] - 1 if k + 1 < len(found) else last]
    for s, n in starts:
        if s is None:
            orders[n].setdefault("review", []).append("could not find this order's pages in the PDF: the whole PDF "
                                                      "is attached (it holds other orders too)")

def parse_paths(paths, uncouple_as_note=False):
    """PDFs and folders of PDFs -> (orders, skipped). skipped = file names that could not be read,
    with the reason; one bad PDF never stops the others."""
    global KEEP_UNCOUPLE
    KEEP_UNCOUPLE = not uncouple_as_note
    files = []
    for p in paths:
        p = Path(p).expanduser()
        files += sorted(f for f in p.iterdir() if f.suffix.lower() == ".pdf") if p.is_dir() else [p]
    orders, skipped = [], []
    for f in files:
        try:
            t = pdftext(f); kind = detect(t)
            if kind == "cornelissen": orders.append(parse_cornelissen(t, f.name))
            elif kind == "vredeveld": orders.append(parse_vredeveld(t, f.name))
            elif kind in ("simonloos", "postnl"):
                found = (parse_simonloos if kind == "simonloos" else parse_postnl)(t, f.name)
                add_page_ranges(found, t)
                orders += found
            else: skipped.append(f.name)
        except Exception as e:
            skipped.append(f"{f.name} ({type(e).__name__}: {e})")
    resolve_coupling(orders)
    return orders, skipped

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("-o", "--out", default="orders.json")
    ap.add_argument("--uncouple-as-note", action="store_true",
                    help="Cornelissen: put Afkoppelen in the Instructions instead of an end stop")
    a = ap.parse_args()
    orders, skipped = parse_paths(a.paths, a.uncouple_as_note)
    Path(a.out).write_text(json.dumps(orders, indent=1, ensure_ascii=False), encoding="utf-8")
    print(f"{len(orders)} orders -> {a.out}")
    if skipped:
        print(f"!! NOT READ (unknown layout, enter these another way): {skipped}")
    errors, warnings = validate(orders)
    report(errors, warnings)
    if errors:
        print(f"!! {len({k for k, _ in errors})} order(s) have errors; qargo_fill.py will refuse them")
        sys.exit(1)

if __name__ == "__main__":
    main()
