"""Message catalogue for the app's window: what the tool's own English strings mean.

The command line keeps printing those strings as they are; other code (and the tests) classify them. Here
each one gets a stable key and the id of a sentence for the operator:

    classify(raw) -> (stable_key, text_id, params)      raw = a validator message, a filler warning, a review note
    reason(raw, origin="pdf", stop=None) -> {"code": text_id, "p": {...}}      what the app's page shows

The sentences themselves are not here: they are "r.<text id>" in qargo_app/strings/<language>.json, and the page
fills in the parameters. Two parameters are names the page looks up in the same table: "stop"
({"k": "deliver", "n": 2} -> "stop.deliver") and "field" ("date" -> "field.date").

Severity: "info" (nothing to do), "check" (look before pressing Save), "stop" (this order cannot be filled).
"""
import re

SEVERITY = {
    # parser doubts (order["review"]) and the importer's notes
    "review.load_paired": "check", "review.unload_paired": "check",
    "review.remark_overprinted": "check", "review.hired_truck": "check", "review.pages_not_found": "check",
    "review.line_elsewhere": "check", "review.time_unclear": "check", "review.goods_unclear": "check",
    "review.dates_swapped": "check", "review.rit_several": "check", "review.no_reference": "check",
    "review.date_assumed": "check", "review.via_client": "check", "review.scenario_guessed": "check",
    "review.drop_full_label": "info", "review.adr": "check", "review.temperature": "check",
    "review.extra_stop": "check", "review.page_unread": "check", "review.shunt_elsewhere": "check", "review.same_place": "check",
    "review.no_container_number": "check",
    "review.laadref_several": "check", "review.laadref_other_rit": "check",
    "review.nothing_to_fill": "stop", "review.other": "check",
    "import.empty": "stop", "import.no_json": "stop", "import.cut_off": "stop", "import.photo_unclear": "stop",
    "import.customer_unknown": "stop", "import.no_photo": "stop", "import.bad_format": "stop",
    "import.only_one_photo": "check", "import.photo_unsure": "check",
    # the program reading the photos itself (reader.py)
    "import.no_key": "stop", "import.bad_key": "stop", "import.no_credit": "stop", "import.busy": "stop",
    "import.offline": "stop", "import.api_error": "stop", "import.heic": "stop", "import.photo_too_big": "stop",
    "import.refused": "stop", "import.read_cut_off": "stop",
    "import.value_dropped": "check", "import.extra_field": "check", "import.consignment_dropped": "check",
    "import.check_country": "check",
    # validator
    "order.invalid": "stop", "val.missing_field": "stop", "val.date_bad": "stop", "val.date_far": "check",
    "val.time_bad": "stop", "val.postcode_bad": "stop", "val.no_postcode": "check",
    "val.address_guessed": "check", "val.phone_bad": "stop", "val.cargo_bad": "stop",
    "val.delivery_before_pickup": "stop", "val.delivery_no_time": "check", "val.idle_same_place": "check", "val.long_gap": "check",
    "val.trip_too_long": "check", "val.start_after_first_pickup": "check", "val.end_before_last_delivery": "check",
    "val.no_ritnummer": "check", "val.no_scenario": "stop", "doc.not_attached": "check",
    # filling Qargo
    "fill.no_location": "check", "fill.no_location_doubt": "check", "fill.no_answer_location": "check", "fill.no_answer_field": "check", "fill.no_answer": "stop",
    "fill.document_not_attached": "check", "fill.location_ambiguous": "check", "fill.location_check": "check",
    "fill.location_empty": "check", "fill.field_skipped": "check", "fill.field_differs": "check",
    "fill.enforce": "check", "fill.empty_trip_on": "check", "fill.pages_check": "check", "fill.pages_skipped": "check", "fill.ocean_liner": "check",
    "fill.start_end_stop": "check", "fill.duplicate_after_fill": "check", "fill.check": "check",
    "fill.save_unsure": "check", "fill.save_other_order": "check", "fill.qargo_asked": "check",
    "fill.differs": "check", "fill.by_hand": "check", "fill.change_new": "check", "fill.change_check": "check",
    "fill.not_changed": "stop",
    "fill.error": "stop", "fill.early_stop": "stop", "fill.browser_closed": "stop", "fill.duplicate": "stop",
    "fill.screenshot": "info", "fill.location_created": "info",
}
# doubts that do not hold an order back from Save (decided with him 21 Oct 2026): the order is complete as
# printed, the note only says what the bot decided. fill_one logs them as "note: ..." and saves; the mail report
# prints them under the saved order. An empty stop (NO LOCATION) or a field left empty still holds the order.
SAVES_ANYWAY = {"review.load_paired", "review.unload_paired", "fill.location_created"}
STOPS = ("start", "end", "collect", "deliver", "goods", "extra", "order", "document")      # "stop.<k>" in the string tables
FIELDS = ("customer_reference", "consignments", "instructions", "ritnummer", "reference", "location", "duration",
          "activity", "customer", "document", "delivery", "country", "street", "pickup", "weight", "source",
          "phone", "query", "goods", "date", "time", "note", "name", "key", "vehicle_category", "temperature",
          "position")   # "field.<name>"

W = r"(?P<where>order|start stop|end stop|c\d+(?: (?:collect|deliver|goods \d+|extra stop \d+))?)(?P<loc>\.location)?"

# (stable key, regex on the whole raw text, text id)
VALIDATOR = [      # validate_orders.py
 ("val.not_a_list", r"the file must contain a list of orders", "import.bad_format"),
 ("val.not_an_object", W + r": expected an object, got (?P<type>\w+)", "import.bad_format"),
 ("val.unread", r"not read: (?P<text>.*)", "order.invalid"),      # the parser's "unread" list
 ("val.unread_format", r"unread must be a list of texts", "import.bad_format"),
 ("val.missing_field", W + r": '(?P<field>\w+)' is missing or empty", "val.missing_field"),
 ("val.unknown_field", W + r": unknown field '(?P<name>[^']*)' \(typo\? the bot would ignore it\)", "import.bad_format"),
 ("val.date_format", W + r": date (?P<value>.+) is not DD/MM/YYYY", "val.date_bad"),
 ("val.date_far", W + r": date (?P<value>\S+) is more than 60 days from today \(day/month swapped\?\)", "val.date_far"),
 ("val.date_impossible", W + r": date (?P<value>\S+) does not exist", "val.date_bad"),
 ("val.time_format", W + r": (?P<field>start|end|duration) (?P<value>.+) is not HH:MM", "val.time_bad"),
 ("val.activity", W + r": activity (?P<value>.+) is not possible here; use one of (?P<allowed>\[.*\])", "import.bad_format"),
 ("val.extra_stop_activity", W + r": activity must be the name of a stop action in Qargo", "import.bad_format"),
 ("val.extra_stop_position", W + r": position (?P<value>.+) must be one of Qargo's 'Before \.\.\.' / 'After \.\.\.' options", "import.bad_format"),
 ("val.extra_stops_not_list", W + r": stops must be a list", "import.bad_format"),
 ("val.extra_stops_service", W + r": extra stops are only made on the container services, not (?P<value>.+)", "import.bad_format"),
 ("val.phone_on_start_end", W + r": start/end stops have no phone number in Qargo; remove 'phone'", "import.bad_format"),
 ("val.phone_format", W + r": phone (?P<value>.+) does not look like a phone number", "val.phone_bad"),
 ("val.stop_text", W + r": (?P<field>reference|note|instructions) must be text", "import.bad_format"),
 ("val.postcode", W + r": postcode (?P<value>.+) is not a valid (?P<country>\w+) postcode \(write it without spaces, e\.g\. 1507CJ\)", "val.postcode_bad"),
 ("val.no_postcode", W + r": no postcode for (?P<name>.+) - the bot can only match on street/name", "val.no_postcode"),
 ("val.address_guessed", W + r": (?P<name>.+) was guessed from a one-line address; check the picked location", "val.address_guessed"),
 ("val.store_format", W + r": store (?P<value>.+) must be the 4-digit AH store number", "import.bad_format"),
 ("val.store_query", W + r": AH store (?P<store>\S+) should be searched as 'Winkel \S+', not (?P<name>.+)", "val.address_guessed"),
 ("val.idle_same_place", r"stays at (?P<name>.+) for (?P<gap>.+?) \((?P<a>.+?) \d\d:\d\d -> (?P<b>.+?) \d\d:\d\d\) with nothing in between - is this a real trip\? check with the customer", "val.idle_same_place"),
 ("val.long_gap", r"nothing happens for (?P<gap>.+?) \(.+ \d\d:\d\d -> .+ \d\d:\d\d\) - check the order", "val.long_gap"),
 ("val.duplicate_key", r"key appears twice \(orders #(?P<a>\d+) and #(?P<b>\d+)\); the bot would fill only one", "import.bad_format"),
 ("val.key_prefix", r"key should start with (?P<prefix>\S+) for (?P<customer>.+)", "import.bad_format"),
 ("val.reference_not_text", r"customer_reference must be text \(put it in quotes\)", "import.bad_format"),
 ("val.ritnummer_format", r"ritnummer (?P<value>.+) must be a whole number or null", "import.bad_format"),
 ("val.no_ritnummer", r"no ritnummer, but (?P<customer>.+) documents always have one", "val.no_ritnummer"),
 ("val.instructions_not_text", r"instructions must be text", "import.bad_format"),
 ("val.service", r"service (?P<value>.+) is not one Qargo offers; use one of (?P<allowed>\[.*\])", "import.bad_format"),
 ("val.container_service", r"container fields need a container service, not (?P<value>.+)", "import.bad_format"),
 ("val.container_text", r"container: (?P<field>\w+) must be text", "import.bad_format"),
 ("val.container_scenario", r"container: scenario (?P<value>.+) must be one of (?P<allowed>\[.*\])", "import.bad_format"),
 ("val.vehicle_category", r"vehicle_category must be text \(the name of a vehicle category in Qargo, e\.g\. 'Chassis'\) or null", "import.bad_format"),
 ("val.no_scenario", r"no Import/Export scenario: Qargo requires one for 'Container import/export' and shows different stops for each; make this order by hand", "val.no_scenario"),
 ("val.pages_format", r"pages (?P<value>.+) must be \[first, last\]: whole page numbers, first <= last", "import.bad_format"),
 ("val.review_format", r"review must be a list of texts", "import.bad_format"),
 ("val.source_missing", r"source file (?P<file>.+?) not found in (?P<dirs>.+); nothing will be attached", "doc.not_attached"),
 ("val.no_consignment", r"needs at least one consignment", "order.invalid"),
 ("val.delivery_before_pickup", r"c(?P<n>\d+): delivery \((?P<d>.*)\) is before its collection \((?P<p>.*)\)", "val.delivery_before_pickup"),
 ("val.delivery_no_time", W + r": no time, on the day of its collection \((?P<p>.*)\); check the delivery time", "val.delivery_no_time"),
 ("val.goods_not_list", W + r": goods must be a list", "import.bad_format"),
 ("val.quantity", W + r": quantity (?P<value>.+) must be a positive number", "val.cargo_bad"),
 ("val.weight", W + r": weight_kg (?P<value>.+) must be a number of kg between 0 and 45000", "val.cargo_bad"),
 ("val.temperature", W + r": temperature_c (?P<value>.+) must be a number of degrees Celsius between -70 and 70", "val.cargo_bad"),
 ("val.empty_cargo", W + r": empty cargo line", "val.cargo_bad"),
 ("val.start_after_first_pickup", r"start stop is later than the first collection", "val.start_after_first_pickup"),
 ("val.end_before_last_delivery", r"end stop is earlier than the last delivery", "val.end_before_last_delivery"),
 ("val.trip_too_long", r"trip spans (?P<gap>.+) - wrong date somewhere\?", "val.trip_too_long"),
 ("val.crashed", r"validator crashed: (?P<detail>.*)", "import.bad_format"),      # qargo_app/documents.py: check()
]
REVIEW = [         # the text after "check: ": parse_trips.py's review notes, then chat_import.py's
 ("review.remark_overprinted", r"(?P<kind>Aankoppelen|Afkoppelen|Laden|Lossen|AH Stop|Rust|Wachten) (?P<date>\d\d/\d\d) (?P<time>\S+): a remark line is printed over by the route number: .*; check the PDF", "review.remark_overprinted"),
 ("review.load_paired", r"load (?P<what>.+) has no unload (?:of its own|with that code)(?: in the PDF)?; paired with the first (?:unload|delivery) after it \((?P<to>.+)\)", "review.load_paired"),
 ("review.unload_paired", r"unload (?P<what>.+) has no load with that code; paired with the previous load (?P<to>.+)", "review.unload_paired"),
 ("review.hired_truck", r"goods are (?P<desc>.+) \('dagspoed'\): PostNL books the truck with driver for the day, not a load - check what this order should be", "review.hired_truck"),
 ("review.pages_not_found", r"could not find this order's pages in the PDF: the whole PDF is attached \(it holds other orders too\)", "review.pages_not_found"),
 ("review.rit_several", r"no 'Ritnr' in the Ritomschrijving (?P<desc>.+) and the stop remarks name (?P<n>\d+) trip numbers \((?P<numbers>.+)\): ritnummer left empty - fill it in by hand", "review.rit_several"),
 ("review.rit_none", r"no 'Ritnr' anywhere in the PDF \(Ritomschrijving (?P<desc>.+)\): ritnummer left empty - fill it in by hand", "val.no_ritnummer"),
 ("review.no_reference", r"'Klant Route nr' is empty on the document: customer reference left empty", "review.no_reference"),
 ("review.nothing_to_fill", r"the document prints no Laden or Lossen \(only: (?P<stops>.*)\): there is nothing to make a consignment from, so this rit cannot be filled", "review.nothing_to_fill"),
 # Vredeveld (parse_vredeveld); "row" is "<load name> -> <unload name>", not a stop the page can name
 ("review.vrd_line_above", r"line above the (?:rows|first load) is not in the order: (?P<line>.*)", "review.line_elsewhere"),
 ("review.vrd_under_address", r"(?P<row>.+?): (?P<line>.+) is printed under the address of (?P<name>.+); kept as that stop's note", "review.line_elsewhere"),
 ("review.vrd_left_text", r"(?P<row>.+?): (?P<line>.+) is printed where the delivery time usually is; kept in the instructions", "review.line_elsewhere"),
 ("review.vrd_several_times", r"(?P<row>.+?): several delivery times printed (?P<times>\[.*\]); the first one is used", "review.time_unclear"),
 ("review.vrd_note_time", r"(?P<row>.+?): the note (?P<note>.+) names a time, but no time window is set \(.*\)", "review.time_unclear"),
 ("review.vrd_no_goods", r"(?P<row>.+?): no goods line \(VO-number, weight\) under this row", "review.goods_unclear"),
 ("review.vrd_odd_vo", r"(?P<row>.+?): (?P<odd>\[.*\]) does not look like a VO-number; check the goods line", "review.goods_unclear"),
 ("review.vrd_no_total", r"no 'Totaal Gewicht' line found: check that every row of the PDF is in the order", "review.goods_unclear"),
 ("review.vrd_dates", r"(?P<row>.+?): the PDF prints the unload date (?P<d>\S+) before the load date (?P<p>\S+); ask Vredeveld which is right", "review.dates_swapped"),
 ("review.vrd_laadrefs", r"(?P<n>\d+) Laadreferenties printed \((?P<refs>.+?)\): (?P<ref>\S+) is the Customer Reference; the other\(s\) are in the instructions of their consignments and in the order Instructions", "review.laadref_several"),
 ("review.vrd_laadrefs_tie", r"(?P<n>\d+) Laadreferenties printed \((?P<refs>.+?)\), none on most rows: all of them are the Customer Reference \((?P<ref>.+?)\); each is in the instructions of its consignments and in the order Instructions", "review.laadref_several"),
 ("review.vrd_laadref_twice", r"(?P<row>.+?): two Laadreferenties printed under this row \((?P<refs>.+?)\); the last one is used", "review.laadref_several"),
 ("review.vrd_laadref_missing", r"(?P<row>.+?): no Laadreferentie printed under this row, the other rows have one; check which one it belongs to", "review.laadref_several"),
 ("review.vrd_laadref_other_rit", r"Laadreferentie (?P<ref>\S+) is also the Laadreferentie of rit (?P<rit>\d+) \((?P<file>.+?)\) in this run", "review.laadref_other_rit"),
 # OCT (parse_oct)
 ("review.oct_date_assumed", r"no (?:delivery )?date (?:on the document|for the stop at (?P<name>.+?)) \((?P<label>.+?) (?:empty|prints no date)\): the date of the stop (?P<side>before|after) it, (?P<date>\S+), is used", "review.date_assumed"),
 ("review.oct_slot_two_days", r"(?P<label>.+?) runs from (?P<a>\S+) to (?P<b>\S+): Qargo has one date per stop, so the window is kept on the first day", "review.time_unclear"),
 ("review.oct_unknown_field", r"the field '(?P<line>.+?)' is not one the parser knows; its value is kept in the Instructions", "review.line_elsewhere"),
 ("review.oct_field_without_address", r"the field '(?P<line>.+?)' is filled in, but 'Container bestemd voor' has no address: its value is kept in the Instructions", "review.line_elsewhere"),
 ("review.oct_stray_line", r"a line printed outside the fields is kept in the Instructions: (?P<line>.*)", "review.line_elsewhere"),
 ("review.oct_field_twice", r"the field '(?P<line>.+?)' is printed twice on the form; both values are kept", "review.line_elsewhere"),
 ("review.oct_scenario", r"Import or Export\? The form names a sea vessel under neither Uithalen nor Inleveren \(or under both\), and a numbered container without Lading says nothing: Qargo's stops depend on it, so this order has to be made by hand", "val.no_scenario"),
 ("review.oct_scenario_guessed", r"Import or Export\? No sea vessel printed; (?P<why>.+): (?P<scenario>Import|Export)", "review.scenario_guessed"),
 ("review.oct_full_label", r"no Containernummer: an empty container of type (?P<type>.+?) goes from (?P<name>.+?) to (?P<to>.+?); Qargo's Export form can only call the last stop 'Drop full container'", "review.drop_full_label"),
 ("review.oct_adr", r"Gevaargoed details printed \((?P<text>.+)\): set ADR on the cargo item in Qargo, the bot leaves it at 'No dangerous goods'", "review.adr"),
 ("review.oct_via_client", r"the container goes to (?P<name>.+?) first \(Container bestemd voor\): (?P<scenario>Import|Export) in Qargo, (?P<stops>.+); check the stops", "review.via_client"),
 # RD Container Transport (parse_rd); the unknown-field, printed-twice, stray-line, date and Tijdslot notes are the OCT ones
 ("review.rd_part_no_address", r"the part '(?P<line>.+?)' of the form has no address: its values are kept in the Instructions", "review.line_elsewhere"),
 ("review.rd_extra_stop", r"the stop at (?P<name>.+?) \((?P<part>.+?)\) is an extra stop of the order \(Stops: (?P<value>.+?)\); Qargo's help does not say how the driver's app shows such a stop: check it", "review.extra_stop"),
 ("review.rd_shunt_elsewhere", r"(?P<part>Lossen|Laden) reads (?P<name>.+?) \(overrijden: drop the full container there\?\) but Afzetten is another place; the stops are made as printed: check the order", "review.shunt_elsewhere"),
 ("review.rd_same_place", r"(?P<part>Lossen|Laden) and Afzetten are the same place \((?P<name>.+?)\): the box is (?:unloaded|loaded) and left there; if it is only driven over \(overrijden\), change the order", "review.same_place"),
 ("review.rd_adr", r"ADR printed on the form \(next to (?P<text>.+?)\): set ADR on the cargo item in Qargo, the bot leaves it at 'No dangerous goods'", "review.adr"),
 ("review.rd_temperature", r"Temperatuur reads (?P<value>.+?), not one number: set the Requested temperature of the cargo item in Qargo yourself \(the text is in the consignment instructions\)", "review.temperature"),
 ("review.rd_container_type_only", r"the Container field reads (?P<value>.+?), a container type without a box number: Container number stays empty, fill it in when RD Container Transport sends the number", "review.no_container_number"),
 ("review.rd_page_unread", r"page (?P<n>\d+) of Transportopdracht (?P<value>\d+) is neither the order table nor the standard 'Aanvullende instructies': it was not read, look at the PDF", "review.page_unread"),
 ("import.time_dropped", W + r": the (?P<field>start|end|duration) time (?P<value>.+) could not be understood and was left empty", "import.value_dropped"),
 ("import.phone_dropped", W + r": the (?P<field>phone) number (?P<value>.+) could not be used and was left empty", "import.value_dropped"),
 ("import.activity_dropped", W + r": kind of stop (?P<value>.+) is not possible here; Qargo's normal one is used", "import.value_dropped"),
 ("import.quantity_dropped", W + r": quantity (?P<value>.+) could not be read and was left empty", "import.value_dropped"),
 ("import.weight_dropped", W + r": weight (?P<value>.+) could not be used and was left empty", "import.value_dropped"),
 ("import.temperature_dropped", W + r": temperature (?P<value>.+) could not be used and was left empty", "import.value_dropped"),
 ("import.extra_field", W + r": the chat program also wrote '(?P<name>[^']*)': (?P<value>.*)", "import.extra_field"),
 ("import.consignment_dropped", r"c(?P<n>\d+): not understood and left out", "import.consignment_dropped"),
 ("import.check_country", W + r": no country on the answer; check the country of (?P<name>.*)", "import.check_country"),
]
# the end of a NO LOCATION line for a place an earlier order did not find (missing_locations.json)
_MISSING = r"(?:; already missing on (?P<missing_since>\S+) \((?P<missing_order>[^()]*)\), searched once)?"
FILLER = [         # ctx["warnings"] entries of qargo_fill.py, logged as "    !! <text>"
 ("fill.location_created", r"CREATED location (?P<made>.+?) \((?P<lat>[-\d.]+), (?P<lon>[-\d.]+)\) - new in Qargo, check it", "fill.location_created"),
 ("fill.store_house_number", r"CHECK store (?P<store>\S+): house number differs: document '(?P<doc>.*)', Qargo '(?P<qargo>.*)'", "fill.location_check"),
 ("fill.store_street", r"CHECK store (?P<store>\S+): document street '(?P<doc>.*)', Qargo '(?P<qargo>.*)'", "fill.location_check"),
 ("fill.postcode_other_street", r"CHECK same postcode but another street: document '(?P<doc>.*)' \((?P<name>.*)\), Qargo '(?P<qargo>.*)'", "fill.location_check"),
 ("fill.postcode_differs", r"CHECK postcode differs for '(?P<street>.*)': document (?P<doc>\S+), Qargo '(?P<qargo>.*)'", "fill.location_check"),
 ("fill.location_ambiguous", r"AMBIGUOUS location '(?P<query>.*)': picked '(?P<picked>.*)', also: (?P<others>\[.*\])", "fill.location_ambiguous"),
 # a record that may be this place ("not filled: [...]"): a person checks it, nothing is created
 ("fill.no_location_doubt", r"NO LOCATION for (?P<name>.+?) \((?P<addr>.*)\); tried (?P<queries>\[.*\]); seen: (?P<seen>\[.*\]); not filled: (?P<doubts>\[.*\])" + _MISSING, "fill.no_location_doubt"),
 ("fill.no_location", r"NO LOCATION for (?P<name>.+?) \((?P<addr>.*)\); tried (?P<queries>\[.*\]); seen: (?P<seen>\[.*?\])" + _MISSING, "fill.no_location"),
 ("fill.no_answer_location", r"NO ANSWER FROM QARGO for (?P<name>.+?) \((?P<addr>.*?)\): (?P<detail>.*?) \(internet\?\); location left empty, pick it by hand; tried (?P<queries>\[.*\]); seen: (?P<seen>\[.*?\])(?:; not filled: (?P<doubts>\[.*\]))?", "fill.no_answer_location"),
 ("fill.no_answer_stop_action", r"NO ANSWER FROM QARGO for the stop action (?P<value>.+?) of (?P<label>c\d+ extra stop \d+): (?P<detail>.*?) \(internet\?\); Stop action left empty, pick it by hand if Qargo has it", "fill.no_answer_field"),
 ("fill.extra_stop_position", r"!!! (?P<label>c\d+ extra stop \d+): Qargo does not offer the position (?P<value>.+?); options: (?P<options>\[.*\])", "fill.start_end_stop"),
 ("fill.extra_stop_missing", r"!!! EXTRA STOP MISSING: no (?P<field_id>\S+) in the form \((?P<name>.*)\)", "fill.start_end_stop"),
 ("fill.enforce_not_found", r"(?P<label>.+): Enforce switch not found", "fill.enforce"),
 ("fill.enforce_not_on", r"(?P<label>.+): Enforce switch not on", "fill.enforce"),
 ("fill.empty_trip_on", r"(?P<label>.+): could not switch off 'Plan trip to couple empty trailer'", "fill.empty_trip_on"),
 ("fill.pages_skipped", r"SKIPPED PDF page range (?P<first>\d+)-(?P<last>\d+): (?P<exc>\w+): (?P<detail>.*)", "fill.pages_skipped"),
 ("fill.skipped", r"SKIPPED (?P<step>.+?): (?P<exc>\w+): (?P<detail>.*)", "fill.field_skipped"),
 ("fill.ocean_liner", r"CHECK ocean liner: (?P<liner>.+) fits (?P<n>\d+) SCAC codes (?P<options>\[.*\]); pick the Ocean liner SCAC in Qargo", "fill.ocean_liner"),
 ("fill.weight_differs", r"CHECK (?P<label>c\d+ goods \d+): weight should be (?P<want>\S+) kg, form has (?P<got>.+)", "fill.field_differs"),
 ("fill.temperature_differs", r"CHECK (?P<label>c\d+ goods \d+): temperature should be (?P<want>\S+) °C, form has (?P<got>.+)", "fill.field_differs"),
 ("fill.time_differs", r"CHECK (?P<where>.+?) (?P<field>start|end) time: expected (?P<want>.+), form has (?P<got>.+)", "fill.field_differs"),
 ("fill.pages_no_split", r"CHECK document: asked for pages (?P<first>\d+)-(?P<last>\d+), but no 'Split from PDF' appeared", "fill.pages_check"),
 ("fill.pages_original_open", r"CHECK document: pages (?P<first>\d+)-(?P<last>\d+) split, but closing the original PDF tab failed - check which documents are attached", "fill.pages_check"),
 ("fill.document_not_found", r"document (?P<file>.+) not found in (?P<dirs>\[.*\])", "doc.not_attached"),
 ("fill.document_not_attached", r"!!! DOCUMENT NOT ATTACHED: Qargo did not show (?P<file>.+) within (?P<s>\d+) s \(internet\?\); attach it by hand", "fill.document_not_attached"),
 ("fill.duplicate_after_fill", r"!!! DUPLICATE: Qargo says customer reference (?P<ref>.+) is already in (?P<order>\S+) \((?P<url>\S+)\)", "fill.duplicate_after_fill"),
 ("fill.field_differs", r"CHECK (?P<field_id>[\w.\[\]]+): expected (?P<want>.+), form has (?P<got>.+)", "fill.field_differs"),
 ("fill.stop_not_removed", r"could not remove the (?P<which>start|end) stop the form shows \((?P<field_id>\S+)\); remove it yourself", "fill.start_end_stop"),
 ("fill.stop_missing", r"!!! (?P<which>START|END) STOP MISSING: no (?P<field_id>\S+) in the form", "fill.start_end_stop"),
 ("fill.stop_location_empty", r"!!! (?P<which>START|END) STOP LOCATION EMPTY \((?P<name>.*)\)", "fill.start_end_stop"),
 ("fill.stop_date", r"!!! (?P<which>START|END) STOP DATE: expected (?P<want>.+), form has (?P<got>.+)", "fill.field_differs"),
 ("fill.stop_time", r"!!! (?P<which>START|END) STOP (?P<field>START|END) TIME: expected (?P<want>.+), form has (?P<got>.+)", "fill.field_differs"),
 ("fill.location_empty", r"EMPTY location field (?P<field_id>\S+)", "fill.location_empty"),
 ("fill.duplicate", r"already in Qargo as (?P<order>\S+) \((?P<url>\S+)\)\. Not filled\. If it really is another order: --allow-duplicate (?P<key>\S+)", "fill.duplicate"),
 ("fill.differs", r"(?P<order>\S+) differs from the document in (?P<n>\d+) place\(s\): (?P<text>.*)\. If the customer changed this order: --change (?P<key>\S+)", "fill.differs"),
 ("fill.by_hand", r"TO DO BY HAND in (?P<order>\S+): (?P<text>.*)", "fill.by_hand"),
 ("fill.change_new", r"marked as a change, but Qargo has no order with customer reference (?P<value>.+): filled as a NEW order", "fill.change_new"),
 ("fill.change_check", r"CHECK after the change, still differs: (?P<text>.*)", "fill.change_check"),
 ("fill.not_changed", r"not changed in Qargo: (?P<text>.*)", "fill.not_changed"),
 ("fill.screenshot", r"screenshot: (?P<file>error_.+\.png)", "fill.screenshot"),
 ("fill.save_unsure", r"Save clicked but no order page opened - check the tab", "fill.save_unsure"),
 ("fill.qargo_asked", r"QARGO ASKED before saving: (?P<text>.+)\. Not saved: check the tab and press Save yourself", "fill.qargo_asked"),
 ("fill.save_other_order", r"an order page opened, but it does not show customer reference (?P<ref>.+)", "fill.save_other_order"),
 ("fill.browser_closed", r"TargetClosedError: (?P<detail>.*)", "fill.browser_closed"),
 ("fill.no_answer", r"NoAnswer: (?P<detail>.*)", "fill.no_answer"),
 ("fill.error", r"(?P<exc>[A-Za-z_]\w*): (?P<detail>.*)", "fill.error"),     # must stay last
]
APP = [            # notes the app itself adds to an order (text after "app: ")
 ("import.only_one_photo", r"only (?P<name>.+) of the (?P<n>\d+) photos is attached", "import.only_one_photo"),
 ("import.photo_unsure", r"not sure which of the (?P<n>\d+) photos holds this trip: (?P<name>.+) is attached", "import.photo_unsure"),
]

_C = lambda rules: [(k, re.compile(rx, re.S), tid) for k, rx, tid in rules]
_VALIDATOR, _REVIEW, _FILLER, _APP = _C(VALIDATOR), _C(REVIEW), _C(FILLER), _C(APP)
# every sentence id classify() / reason() can hand out: each needs "r.<id>" in every string table
TEXT_IDS = sorted({tid for rules in (VALIDATOR, REVIEW, FILLER, APP) for _, _, tid in rules}
                  | {"review.other", "order.invalid", "fill.check", "fill.early_stop", "import.empty", "import.no_json",
                     "import.cut_off", "import.photo_unclear", "import.customer_unknown", "import.no_photo",
                     "import.no_key", "import.bad_key", "import.no_credit", "import.busy", "import.offline",
                     "import.api_error", "import.heic", "import.photo_too_big", "import.refused", "import.read_cut_off"})


def _first(rules, text):
    for key, rx, tid in rules:
        m = rx.fullmatch(text)
        if m:
            return key, tid, {k: v for k, v in m.groupdict().items() if v is not None}
    return None


def classify(raw):
    """(stable key, text id, params) for a validator message, a review note or a filler warning; never raises"""
    raw = str(raw)
    text = raw[len("JSON: "):] if raw.startswith("JSON: ") else raw           # fill_one's prefix for validator warnings
    if text.startswith("app: "):
        return _first(_APP, text[len("app: "):]) or ("app.unclassified", "fill.check", {"text": text})
    if text.startswith("check: "):                                            # the validator's prefix for review notes
        note = text[len("check: "):]
        return _first(_REVIEW, note) or ("review.other", "review.other", {"text": note})
    hit = _first(_VALIDATOR, text)
    if hit or raw.startswith("JSON: "):
        return hit or ("val.unclassified", "order.invalid", {"text": text})
    return _first(_FILLER, text) or ("fill.unclassified", "fill.check", {"text": text})


def saves_anyway(raw):
    """is this doubt one that does not hold the order back from Save (SAVES_ANYWAY)?"""
    return classify(raw)[0] in SAVES_ANYWAY


def stop_of(where):
    """'c2 deliver' / 'start stop' / 'END' / 'consignments[1].actual_pickup_stop.date' -> {"k": "deliver", "n": 2}"""
    where = where or ""
    m = re.search(r"consignments\[\d+\]\.standalone_stops\[(\d+)\]", where) or re.match(r"c\d+ extra stop (\d+)", where)
    if m:
        return {"k": "extra", "n": int(m.group(1)) + (1 if "standalone" in where else 0)}
    m = re.search(r"consignments\[(\d+)\]\.actual_(pickup|delivery)_stop", where)
    if m:
        return {"k": "collect" if m.group(2) == "pickup" else "deliver", "n": int(m.group(1)) + 1}
    m = re.match(r"c(\d+)(?: (collect|deliver|goods))?", where)
    if m:
        return {"k": m.group(2) or "deliver", "n": int(m.group(1))}
    low = where.lower()
    if low.startswith(("start", "setup", "add start")):
        return {"k": "start"}
    if low.startswith(("end", "teardown", "add end")):
        return {"k": "end"}
    if "pdf" in low or low.startswith("document"):
        return {"k": "document"}
    return {"k": "order"}


def _plain(v):
    """a value as the messages print it (repr: 'x', "x", None) -> the value itself; nothing -> a dash"""
    v = str(v).strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
        v = v[1:-1]
    return "\u2014" if v in ("", "None") else v


def _hours(gap):
    """timedelta text ('7:15:00', '1 day, 2:00:00') -> '7:15' / '26:00' (hours:minutes)"""
    m = re.fullmatch(r"(?:(\d+) days?, )?(\d+):(\d\d):\d\d(?:\.\d+)?", str(gap).strip())
    return f"{int(m.group(1) or 0) * 24 + int(m.group(2))}:{m.group(3)}" if m else str(gap)


def reason(raw, origin="pdf", stop=None):
    """what the page shows for one raw message: {"code": text id, "p": parameters}. origin: "pdf" (our own
    parser made the order) or "photo" / "file" (somebody else did). stop: the step or stop the filler was at
    when it gave this warning (its location warnings do not name their stop). Never raises."""
    key, tid, p = classify(raw)
    if tid == "import.bad_format" and origin == "pdf":
        tid = "order.invalid"             # nobody can "ask the chatbot again" for a document our parser read
    step = p.get("step", "")
    where = p.get("where") or p.get("label") or p.get("field_id") or step or p.get("which") or stop or ""
    out = {"stop": stop_of(where)}
    field = p.get("field")
    if key == "fill.skipped":
        field = next((f for f in sorted(FIELDS, key=len, reverse=True) if step.endswith(f)), None) \
            or ("activity" if step.endswith("stop action") else "goods" if "goods" in step
                else "location" if "stop" in step or step.endswith("scroll")
                else "document" if "PDF" in step else "customer_reference" if "duplicate" in step
                else "activity" if "empty trip" in step else "location")
    elif key in ("fill.field_differs", "fill.weight_differs", "fill.temperature_differs"):
        fid = p.get("field_id") or p.get("label") or ""
        field = ("customer_reference" if "customer_reference" in fid else "customer" if fid == "customer" else
                 "ritnummer" if "ritnummer" in fid else
                 "vehicle_category" if "vehicle_category" in fid else "position" if "stop_position" in fid else "activity" if "stop_type" in fid else
                 "date" if fid.endswith(".date") else "reference" if "reference" in fid else
                 "temperature" if key == "fill.temperature_differs" else "weight")
    elif key == "fill.no_answer_stop_action":
        field = "activity"
    elif key == "fill.extra_stop_position":
        field = "position"
    elif key == "fill.stop_date":
        field = "date"
    elif key == "import.activity_dropped":
        field = "activity"
    elif key == "import.quantity_dropped":
        field = "goods"
    elif key == "import.weight_dropped":
        field = "weight"
    elif key == "import.temperature_dropped":
        field = "temperature"
    elif field in ("start", "end", "START", "END"):
        field = "time"
    if field:
        out["field"] = field
    for k in ("name", "value", "got", "want", "customer", "order", "file", "picked", "doc", "qargo", "start", "end", "text", "n", "first", "last"):
        if k in p:
            out[k] = _plain(p[k])
    if "gap" in p:
        out["gap"] = _hours(p["gap"])
    return {"code": tid, "p": out}
