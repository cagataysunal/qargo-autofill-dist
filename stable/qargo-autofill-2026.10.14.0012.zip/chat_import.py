"""Photo route: the operator gives a chatbot the photo(s) and the question in qargo_app/photo_prompt.txt and
pastes its answer back. This turns that answer into orders in the format of SCHEMA.md:

    orders = import_chat_answer(text, source_name="photo-10.jpeg", driver="Jan")
    errors, warnings = validate_orders.validate(orders, pdf_dirs)      # the validator decides, as for every source

Pure functions, standard library only. Nothing here guesses a value: what cannot be normalised safely is left
out and named in the order's "review" list, which the validator turns into warnings ("check: ...") and which
keeps the bot from pressing Save on that order. ImportProblem means nothing usable was pasted at all.
"""
import datetime, json, re

# ------------------------------------------------------------------ tenant knowledge the chatbot cannot have
CUSTOMERS = {          # exact Qargo name -> (key prefix, other spellings a document or a chatbot uses)
    "Dick Vijn Logistiek": ("ACT", ("action", "dick vijn", "dick vijn logistiek b.v.", "action route list")),
    "Cornelissen": ("CT", ("cornelissen transport", "cornelissen transport b.v.")),
    "Simon Loos": ("SL", ("simon loos b.v.", "simonloos")),
    "PostNL": ("PN", ("post nl", "postnl transport")),
    "Vredeveld": ("VRD", ("vredeveld transport",)),
    "OCT": ("OCT", ("oosterhout container terminal", "oosterhout container terminal b.v.", "octerminal")),
}
AH_CUSTOMERS = {"Cornelissen", "Simon Loos"}        # only their documents carry Albert Heijn store numbers
ACTIVITIES = {"setup": {"Couple empty trailer", "Start of day"}, "teardown": {"Uncouple empty trailer", "End of day"},
              "pickup": {"Collect", "Couple trailer", "Start of day"}, "delivery": {"Delivery", "Uncouple trailer", "End of day"}}
COUNTRIES = {"nl": "NL", "nederland": "NL", "netherlands": "NL", "the netherlands": "NL", "holland": "NL", "hollanda": "NL",
             "be": "BE", "belgie": "BE", "belgië": "BE", "belgium": "BE", "belgique": "BE", "belçika": "BE",
             "de": "DE", "duitsland": "DE", "germany": "DE", "deutschland": "DE", "almanya": "DE",
             "нидерландия": "NL", "холандия": "NL", "белгия": "BE", "германия": "DE",
             "fr": "FR", "frankrijk": "FR", "france": "FR", "lu": "LU", "luxemburg": "LU", "luxembourg": "LU"}
UNREADABLE = re.compile(r"^\s*(\?+|n/?a|unknown|unreadable|illegible|not (readable|visible|legible)|onleesbaar|onbekend|"
                        r"okunamıyor|okunmuyor|bilinmiyor|нечетливо|не се чете|неизвестно|null|none|-+)\s*$", re.I)

ALIASES = {   # fields chatbots invent -> the schema's name
    "order": {"reference": "customer_reference", "customerreference": "customer_reference", "customer_ref": "customer_reference",
              "trip": "customer_reference", "rit": "ritnummer", "ritnr": "ritnummer", "notes": "instructions",
              "remarks": "instructions", "start_stop": "setup", "end_stop": "teardown", "orders": "consignments",
              "stops": None, "checks": "review", "warnings": "review", "unreadable": "review", "file": "source",
              "photo": "source", "image": "source", "filename": "source", "file_name": "source"},
    "consignment": {"collection": "pickup", "collect": "pickup", "load": "pickup", "deliver": "delivery", "unload": "delivery",
                    "ref": "reference", "cargo": "goods", "items": "goods", "notes": "instructions"},
    "stop": {"address": "location", "time_from": "start", "from": "start", "start_time": "start", "arrival": "start",
             "time_to": "end", "to": "end", "end_time": "end", "departure": "end", "tel": "phone", "telephone": "phone",
             "phone_number": "phone", "notes": "note", "remark": "note", "remarks": "note", "ref": "reference"},
    "location": {"postal_code": "postcode", "postalcode": "postcode", "zip": "postcode", "zipcode": "postcode", "zip_code": "postcode",
                 "address": "street", "street_address": "street", "town": "city", "place": "city", "country_code": "country",
                 "store_number": "store", "search": "query"},
    "goods": {"qty": "quantity", "amount": "quantity", "count": "quantity", "unit": "description", "type": "description",
              "weight": "weight_kg", "kg": "weight_kg"},
}
FIELDS = {    # the schema (validate_orders.py:21-30)
    "order": ("key", "customer", "customer_reference", "ritnummer", "instructions", "source", "setup", "teardown",
              "consignments", "review", "pages", "service", "container"),
    "consignment": ("reference", "instructions", "pickup", "delivery", "goods"),
    "stop": ("location", "date", "start", "end", "duration", "reference", "phone", "note", "activity"),
    "location": ("name", "street", "postcode", "city", "country", "query", "store", "unverified"),
    "goods": ("quantity", "description", "weight_kg"),
}


class ImportProblem(Exception):
    """the pasted text cannot be used at all; .key is the id of a sentence for the operator (messages.py)"""
    def __init__(self, key, detail=""):
        super().__init__(f"{key}: {detail}" if detail else key); self.key = key


# ------------------------------------------------------------------ 1. find the JSON in whatever was pasted
def _looks_like_order(x):
    return isinstance(x, dict) and ("consignments" in x or "customer_reference" in x or "customer" in x)

def _orders_in(value):
    """value decoded from JSON -> list of order dicts, or None"""
    if _looks_like_order(value):
        return [value]                                           # one object instead of a list
    if isinstance(value, list) and (not value or any(_looks_like_order(v) for v in value)):
        return value
    if isinstance(value, dict):                                  # {"orders": [...]} / {"result": {...}}
        for v in value.values():
            found = _orders_in(v) if isinstance(v, (list, dict)) else None
            if found:
                return found
    return None

def _repair(s):
    s = s.translate({0x201C: '"', 0x201D: '"', 0x201E: '"', 0x00A0: " ", 0x2018: "'", 0x2019: "'", 0xFEFF: None})
    s = re.sub(r"^\s*//.*$", "", s, flags=re.M)                  # whole-line comments
    return re.sub(r",(\s*[}\]])", r"\1", s)                      # trailing commas

def extract_orders(text):
    """the list of order objects in a chatbot answer: prose around it, ``` fences, one object, a wrapper object"""
    if not (text or "").strip():
        raise ImportProblem("import.empty")
    blocks = re.findall(r"```[ \t]*[\w+-]*[ \t]*\r?\n(.*?)```", text, flags=re.S)       # closed fences first
    open_fence = re.search(r"```[ \t]*[\w+-]*[ \t]*\r?\n(?!.*```)(.*)\Z", text, flags=re.S)
    # every closed fence together (two trips in two blocks); else an unclosed fence; else the whole text
    groups = ([blocks] if blocks else []) + ([[open_fence.group(1)]] if open_fence else []) + [[text]]
    dec, found, saw_json_start = json.JSONDecoder(), [], False
    for group in groups:
        for cand in group:
            for variant in (cand, _repair(cand)):
                got, i = [], 0
                while True:
                    m = re.compile(r"[\[{]").search(variant, i)
                    if not m:
                        break
                    saw_json_start = True
                    try:
                        value, end = dec.raw_decode(variant, m.start())
                    except json.JSONDecodeError:
                        i = m.start() + 1; continue
                    orders = _orders_in(value)
                    if orders is not None:
                        got += orders
                    i = end
                if got:
                    found += got; break
        if found:
            break
    if not found:
        if re.search(r"\.\.\.|…", text) and saw_json_start:
            raise ImportProblem("import.cut_off", "the answer contains '...'")
        if saw_json_start and (text.count("{") != text.count("}") or text.count("[") != text.count("]")):
            raise ImportProblem("import.cut_off", "brackets do not close: the answer was cut off")
        if re.fullmatch(r"\s*(```\w*\s*)?\[\s*\](\s*```)?.*", text, flags=re.S):
            raise ImportProblem("import.photo_unclear")
        raise ImportProblem("import.no_json")
    return [o for o in found if isinstance(o, dict)]


# ------------------------------------------------------------------ 2. make each value the validator's type
def norm_date(v, today=None):
    """-> 'DD/MM/YYYY' or None. Accepts 2026-10-09, 9-10-2026, 09.10.2026, 9/10/26. Never swaps day and month."""
    if not isinstance(v, str):
        return None
    s = v.strip()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})(?:[T ].*)?", s)
    if m:
        y, mo, d = map(int, m.groups())
    else:
        m = re.fullmatch(r"(\d{1,2})[-/.](\d{1,2})[-/.](\d{4}|\d{2})", s)
        if not m:
            return None
        d, mo, y = map(int, m.groups())
        y += 2000 if y < 100 else 0
    try:
        datetime.date(y, mo, d)
    except ValueError:
        return f"{d:02d}/{mo:02d}/{y}"          # impossible date: let the validator say so
    return f"{d:02d}/{mo:02d}/{y}"

def norm_time(v):
    """-> 'HH:MM' or None. Accepts 7:00, 07:00:00, 07.00, 7u00, 07h00, 0700, 7:00 PM."""
    if isinstance(v, (int, float)) or not isinstance(v, str):
        return None
    s = v.strip().lower()
    m = re.fullmatch(r"(\d{1,2})\s*[:.uh]\s*(\d{2})(?::\d{2})?\s*(am|pm|uur|u|h)?", s) or re.fullmatch(r"(\d{2})(\d{2})()", s)
    if not m:
        return None
    h, mi, suffix = int(m.group(1)), int(m.group(2)), m.group(3)
    if suffix == "pm" and h < 12: h += 12
    if suffix == "am" and h == 12: h = 0
    return f"{h:02d}:{mi:02d}" if h < 24 and mi < 60 else None

def norm_postcode(v):
    return re.sub(r"\s+", "", str(v)).upper() if v not in (None, "") else None

def country_from_postcode(pc):
    return "NL" if re.fullmatch(r"\d{4}[A-Z]{2}", pc or "") else "DE" if re.fullmatch(r"\d{5}", pc or "") else None

def _text(v):
    if v is None or isinstance(v, (dict, bool)):
        return None
    if isinstance(v, list):
        v = "\n".join(str(x) for x in v if x not in (None, ""))
    s = str(v).strip()
    return None if not s or UNREADABLE.match(s) else s

def _number(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, str) and re.fullmatch(r"\s*\d+\s*", v):
        return int(v)
    return None

class _Notes:
    """what the importer did to an answer. check: a person must look (these go into the order's "review");
    quiet: only worth a line in the log, because the validator refuses the order for it anyway or nothing is lost"""
    def __init__(self):
        self.check, self.quiet = [], []

def _rename(obj, kind, where, notes):
    """apply ALIASES, then drop anything the schema does not know (named in notes so a person sees it)"""
    out = {}
    for k, v in obj.items():
        k2 = k if k in FIELDS[kind] else ALIASES[kind].get(re.sub(r"[\s-]", "_", k).lower(), None)
        if k2 in FIELDS[kind] and out.get(k2) in (None, "", []):
            out[k2] = v
        elif k2 is None and v not in (None, "", [], {}) and k.lower() not in ("stops", "confidence", "id", "type", "page", "pages"):
            notes.check.append(f"{where}: the chat program also wrote '{k}': {json.dumps(v, ensure_ascii=False)[:120]}")
    return out

def _location(L, where, customer, notes):
    if isinstance(L, str):
        notes.quiet.append(f"{where}: the address came as one line and could not be used: {L[:80]}")
        return None
    if not isinstance(L, dict):
        return None
    L = _rename(L, "location", where, notes)
    out = {"name": _text(L.get("name")), "street": _text(L.get("street")), "postcode": norm_postcode(_text(L.get("postcode"))) or "",
           "city": _text(L.get("city")) or ""}
    c = (_text(L.get("country")) or "").lower()
    out["country"] = COUNTRIES.get(c) or (c.upper() if re.fullmatch(r"[a-z]{2}", c) else None) \
        or country_from_postcode(out["postcode"]) or "NL"
    if not _text(L.get("country")) and not country_from_postcode(out["postcode"]) and out["postcode"]:
        notes.check.append(f"{where}: no country on the answer; check the country of {out['name']}")
    # same rules as parse_trips.loc(): query = street up to the first number; AH stores are searched as "Winkel NNNN"
    street = out["street"] or ""
    mq = re.match(r"^(.*?\d+)", street)
    # an answer's own query is kept (hand-made files carry queries tuned to how Qargo spells a street)
    out["query"] = _text(L.get("query")) or (mq.group(1) if mq else (street or out["name"] or "")).strip()
    ms = re.match(r"^(?:Albert Heijn\s+|AH\s+)?(\d{4})(?:\s|$)", out["name"] or "")
    if ms and customer in AH_CUSTOMERS:
        out["store"] = ms.group(1); out["query"] = f"Winkel {ms.group(1)}"
    elif L.get("store") not in (None, ""):
        notes.quiet.append(f"{where}: store number {L.get('store')} ignored (only Albert Heijn stops have one)")
    if L.get("unverified") is True:
        out["unverified"] = True
    return out

def _stop(s, kind, where, customer, notes):
    if not isinstance(s, dict):
        if s not in (None, "", [], {}):            # "pickup": "Zwaagdijk" would crash validate() (validate_orders.py:222)
            notes.quiet.append(f"{where}: the stop came as {type(s).__name__}, not as an object, and could not be used")
        return None
    s = _rename(s, "stop", where, notes)
    out = {"location": _location(s.get("location"), where, customer, notes)}
    raw = s.get("date")
    out["date"] = norm_date(raw) if raw not in (None, "") else None
    if raw not in (None, "") and out["date"] is None:
        notes.quiet.append(f"{where}: the date {raw!r} could not be understood")
    for f in ("start", "end", "duration"):
        raw = s.get(f)
        if raw in (None, "") or (isinstance(raw, str) and UNREADABLE.match(raw)):
            continue
        t = norm_time(raw)
        if t: out[f] = t
        else: notes.check.append(f"{where}: the {f} time {raw!r} could not be understood and was left empty")
    for f in ("reference", "note"):
        if _text(s.get(f)): out[f] = _text(s[f])
    ph = _text(s.get("phone"))
    if ph and kind in ("pickup", "delivery"):
        ph = re.sub(r"^[^\d+(]+", "", ph).strip()
        if re.fullmatch(r"\+?[\d ()./-]{6,20}", ph): out["phone"] = ph
        else: notes.check.append(f"{where}: the phone number {s.get('phone')!r} could not be used and was left empty")
    act = _text(s.get("activity"))
    if act:
        hit = next((a for a in ACTIVITIES[kind] if a.lower() == act.lower()), None)
        if hit: out["activity"] = hit
        else: notes.check.append(f"{where}: kind of stop {act!r} is not possible here; Qargo's normal one is used")
    return out

def _goods(g, where, notes):
    if isinstance(g, dict): g = [g]
    if not isinstance(g, list): return None
    out = []
    for i, item in enumerate(g, 1):
        if isinstance(item, str):
            m = re.fullmatch(r"\s*(\d+)\s*(.*)", item); item = {"quantity": m.group(1), "description": m.group(2)} if m else {"description": item}
        if not isinstance(item, dict): continue
        item = _rename(item, "goods", f"{where} goods {i}", notes)
        q, d, w = item.get("quantity"), _text(item.get("description")), item.get("weight_kg")
        mq = re.fullmatch(r"\s*(\d+)\s*([A-Za-z].*)", q) if isinstance(q, str) else None
        if mq: q, d = mq.group(1), d or mq.group(2).strip()
        line = {}
        if _number(q) is not None and _number(q) > 0: line["quantity"] = _number(q)
        elif q not in (None, ""): notes.check.append(f"{where} goods {i}: quantity {q!r} could not be read and was left empty")
        if d: line["description"] = d
        if _number(w) is not None and 0 < _number(w) <= 45000: line["weight_kg"] = _number(w)
        elif w not in (None, ""): notes.check.append(f"{where} goods {i}: weight {w!r} could not be used and was left empty")
        if line: out.append(line)
    return out or None

NOT_A_DRIVER = {"img", "image", "photo", "foto", "scan", "screenshot", "dsc", "pxl", "pic", "picture", "action", "rota",
                "route", "rit", "whatsapp", "document", "file", "new", "copy", "kopie", "untitled", "scanned"}

def driver_from_file(name):
    """'kalin-14-10.jpeg' -> 'Kalin': the operator names a photo after the driver it is for (the sheet itself does
    not print the driver). Letters up to the first digit or separator; None when that is not a name."""
    m = re.match(r"\s*([^\W\d_]{2,20})(?=[\s\d_.\-(]|$)", str(name or ""))
    if not m or m.group(1).lower() in NOT_A_DRIVER:
        return None
    return m.group(1)[:1].upper() + m.group(1)[1:]

def safe_key(s):
    """keys become file names (orders_<key>.json, error_<key>.png): keep them legal on Windows too"""
    return re.sub(r"[^A-Za-z0-9._-]+", "-", s).strip("-.")[:60]

def known_customer(name):
    """the customer exactly as Qargo names it, for any spelling a document or a chatbot uses; None when unknown"""
    low = (name or "").strip().lower()
    return next((c for c, (_, alts) in CUSTOMERS.items() if low == c.lower() or low in alts), None)

PHOTO_NUMBER = re.compile(r"(?:photo|image|img|foto|scan|picture|page|p|#|nr\.?|no\.?)?\s*#?(\d+)\s*(?:\.\w{3,4})?", re.I)
COPY_SUFFIX = re.compile(r" \(\d+\)$")                   # documents.free_name: 'IMG_1 (2).jpeg' is a second IMG_1.jpeg


def photo_for(raw, photos, n, total):
    """which of the operator's photos holds order n (0-based) of total. photos: their names, in the order chosen.
    -> (name, sure). The chatbot names the photo by its file name (with or without folder, extension or the
    ' (2)' a second copy gets) or by its number as attached ("photo 2", "2"). When it names none, the n-th photo
    is taken when there are as many orders as photos, else the first; both not sure, so the operator is told."""
    photos = list(photos)
    if len(photos) == 1:
        return photos[0], True
    s = (_text(raw) or "").replace("\\", "/").rsplit("/", 1)[-1].strip().lower()
    if s:
        def stem(name):
            name = name.lower()
            return COPY_SUFFIX.sub("", name.rsplit(".", 1)[0] if "." in name else name)
        hits = [p for p in photos if p.lower() == s] or [p for p in photos if stem(p) == stem(s)]
        if len(hits) == 1:
            return hits[0], True
        m = PHOTO_NUMBER.fullmatch(s)
        if m and not hits and 1 <= int(m.group(1)) <= len(photos):
            return photos[int(m.group(1)) - 1], True
    return (photos[n] if total == len(photos) else photos[0]), False


def normalise(o, n, source_name, driver=None, customer=None, log=None):
    """one order object of the answer -> an order in the schema. source_name: the file to attach; None keeps
    the chatbot's own "source" text, for photo_for() to match against the photos the operator chose.
    customer: the Qargo customer the operator chose, used when the answer's own customer is not one of
    CUSTOMERS. log: callable(text) for what nobody has to check."""
    notes = _Notes()
    o = _rename(o, "order", "order", notes)
    raw_cust = _text(o.get("customer")) or ""
    # an unknown name stays as it is: the caller asks the operator (and the bot could not pick it in Qargo anyway)
    customer = known_customer(raw_cust) or known_customer(customer) or raw_cust
    ref = o.get("customer_reference")
    ref = str(ref).strip() if isinstance(ref, (str, int)) and not isinstance(ref, bool) else None
    rit = o.get("ritnummer")
    rit = int(rit) if isinstance(rit, str) and rit.strip().isdigit() else rit if isinstance(rit, int) and not isinstance(rit, bool) else None
    prefix = CUSTOMERS.get(customer, ("NEW",))[0]
    key_id = str(rit) if customer in ("Cornelissen", "Vredeveld") and rit else ref
    out = {"key": safe_key(f"{prefix}-{key_id}") if key_id else f"{prefix}-photo-{n + 1}", "customer": customer,
           "customer_reference": ref, "ritnummer": rit,
           "instructions": "\n".join(x for x in (_text(driver), _text(o.get("instructions"))) if x) or None,
           # the chatbot does not know the file on this computer: its text only says which photo (photo_for)
           "source": source_name if source_name is not None else _text(o.get("source")),
           "setup": _stop(o.get("setup"), "setup", "start stop", customer, notes),
           "teardown": _stop(o.get("teardown"), "teardown", "end stop", customer, notes)}
    # container orders (OCT): the transport service and the container fields, as text; the validator judges them
    if _text(o.get("service")):
        out["service"] = _text(o.get("service"))
    if isinstance(o.get("container"), dict):
        out["container"] = {k: _text(v) for k, v in o["container"].items() if _text(v)}
    cons = o.get("consignments")
    if isinstance(cons, dict): cons = [cons]
    out["consignments"] = []
    for i, c in enumerate(cons if isinstance(cons, list) else [], 1):
        if not isinstance(c, dict):
            notes.check.append(f"c{i}: not understood and left out"); continue
        c = _rename(c, "consignment", f"c{i}", notes)
        c2 = {"reference": _text(c.get("reference")), "instructions": _text(c.get("instructions")),
              "pickup": _stop(c.get("pickup"), "pickup", f"c{i} collect", customer, notes),
              "delivery": _stop(c.get("delivery"), "delivery", f"c{i} deliver", customer, notes)}
        g = _goods(c.get("goods"), f"c{i}", notes)
        if g: c2["goods"] = g
        out["consignments"].append(c2)
    rv = o.get("review")
    rv = [rv] if isinstance(rv, str) else rv if isinstance(rv, list) else []
    review = [str(x).strip() for x in rv if isinstance(x, (str, int, float)) and str(x).strip()] + notes.check
    if review:
        out["review"] = list(dict.fromkeys(review))
    for q in notes.quiet if log else ():
        log(f"import {out['key']}: {q}")
    return out

def import_chat_answer(text, source_name, driver=None, customer=None, log=None):
    """-> orders ready for validate(); doubts are in each order's "review". An order whose "customer" is not in
    CUSTOMERS needs the operator's choice: call again with customer=<that name>. source_name None: each order's
    "source" is what the chatbot wrote, to be matched to a photo with photo_for().
    Raises ImportProblem when nothing usable was pasted."""
    orders, seen = [], set()
    for n, o in enumerate(extract_orders(text)):
        o2 = normalise(o, n, source_name, driver, customer, log)
        if o2["key"] in seen:                 # the same trip pasted / answered twice
            continue
        seen.add(o2["key"]); orders.append(o2)
    if not orders:
        raise ImportProblem("import.photo_unclear")
    return orders
