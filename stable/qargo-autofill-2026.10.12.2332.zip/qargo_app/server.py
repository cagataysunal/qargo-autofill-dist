"""What the page shows (Store) and the local web server the page talks to.

The server listens on 127.0.0.1 only, on a port the system picks. Every request must carry a cookie that only
the program's own browser window has, must name our own host (no DNS rebinding) and, when it changes something,
must come from our own page (no other site's form). The HTTP threads never touch the browser: they read files,
check pasted answers and put commands on the engine's queue.

  GET  /                the page (page.html with the string tables inside)
  GET  /api/state       everything the page shows, as JSON
  GET  /api/events      the same, pushed whenever it changes (Server-Sent Events), and a ping every 15 s
  GET  /api/prompt      the question for the chatbot, ?lang=
  POST /api/cmd         {"cmd": ...} for the engine; answers 202 at once
  POST /api/upload      ?name=...[&more=1][&photo=1], the file as the body
  POST /api/import      {"text", "photos", "driver", "customer"}: a chatbot's answer
  POST /api/downloads   look in the Downloads folder
  POST /api/report      write the report for support
"""
import hmac, json, threading, traceback, urllib.parse
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from . import texts

MAX_UPLOAD = 40 * 1024 * 1024
COMMANDS = {"start", "cancel", "show", "front", "raise", "open_login", "recheck", "remove", "remove_doc", "retry",
            "set_lang", "autosave", "done"}
# what an order in the list can be: "st.<status>" in the string tables
STATUSES = ("ready", "invalid", "queued", "filling", "filled", "attention", "saved", "duplicate", "failed",
            "stopped", "tab_closed")
FRESH = ("ready", "invalid")          # nothing happened to the order yet: reading the documents again may replace it
PHASES = ("starting", "login_check", "login", "offline", "ready", "running", "stopping", "review", "closing")
NOTICES = ("control_reopened", "downloads_none", "downloads_added", "downloads_unreadable", "report_downloads",
           "report_data", "report_failed")                               # "n.<code>"
PROBLEMS = ("pdf_tool_missing", "unexpected")                            # "pr.<code>": stays until it is solved
UNREAD = ("unknown_layout", "read_error", "wrong_type", "too_big")      # "u.<code>"


class Store:
    """All state the page shows. Any thread may read or update it; every update wakes the event streams.
    The page keeps nothing itself: reload it or reopen it and it is back."""
    def __init__(self, lang, version=""):
        self.cv = threading.Condition()
        self.v = 0
        self.closing = False
        self.full = {}        # order id -> {"order": the complete order (SCHEMA.md), "origin", "warnings"}; never sent to the page
        self.s = {"phase": "starting", "lang": lang, "version": version, "orders": [], "unread": [],
                  "left": {"already": 0, "dupes": 0}, "reading": False, "run": None, "notice": None,
                  "problem": None, "autosave": False, "front": "control"}

    def update(self, fn=None, **kw):
        with self.cv:
            if fn:
                fn(self.s)
            self.s.update(kw)
            self.v += 1
            self.cv.notify_all()

    def read(self, fn):
        with self.cv:
            return fn(self.s)

    def snapshot(self):
        with self.cv:
            return self.v, json.dumps(dict(self.s, v=self.v), ensure_ascii=False).encode("utf-8")

    def wait(self, seen, timeout):
        with self.cv:
            self.cv.wait_for(lambda: self.v != seen or self.closing, timeout)

    def set_order(self, oid, **kw):
        self.update(lambda s: [o.update(kw) for o in s["orders"] if o["id"] == oid])

    def order(self, oid):
        return self.read(lambda s: next((dict(o) for o in s["orders"] if o["id"] == oid), None))

    def status(self, oid):
        return (self.order(oid) or {}).get("status")

    def phase(self):
        return self.read(lambda s: s["phase"])


def page_html():
    """page.html with the string tables put inside: one request, and no sentence in the HTML file itself"""
    html = (texts.HERE / "page.html").read_text(encoding="utf-8")
    tables = json.dumps(texts.tables(), ensure_ascii=False).replace("</", "<\\/")
    return html.replace("/*STRINGS*/{}", tables).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _allowed(self, post=False):
        app = self.server.app
        if self.headers.get("Host") not in app.hosts:                       # DNS rebinding
            return False
        if post and self.headers.get("Origin") not in (None, app.origin):   # another site's form / fetch
            return False
        c = SimpleCookie(self.headers.get("Cookie", ""))
        return hmac.compare_digest(c["qa_token"].value if "qa_token" in c else "", app.token)

    def _send(self, code, body=b"", ctype="application/json; charset=utf-8"):
        body = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        app = self.server.app
        url = urllib.parse.urlsplit(self.path)
        try:
            if not self._allowed():
                return self._send(403, texts.text("en", "forbidden").encode("utf-8"), "text/plain; charset=utf-8")
            if url.path == "/":
                return self._send(200, page_html(), "text/html; charset=utf-8")
            if url.path == "/api/state":
                return self._send(200, app.store.snapshot()[1])
            if url.path == "/api/events":
                return self._events()
            if url.path == "/api/prompt":
                lang = urllib.parse.parse_qs(url.query).get("lang", ["en"])[0]
                return self._send(200, texts.photo_prompt(lang).encode("utf-8"), "text/plain; charset=utf-8")
            self._send(404, {"ok": False})
        except OSError:                          # the tab went away while we were answering
            pass
        except Exception:
            app.log("HTTP " + traceback.format_exc())

    def _events(self):
        st = self.server.app.store
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()                       # HTTP/1.0, no length: the stream ends when we close it
        seen = -1
        try:
            self.wfile.write(b"retry: 1000\n\n")
            while True:
                st.wait(seen, 15)
                v, snap = st.snapshot()
                self.wfile.write(b"event: state\ndata: " + snap + b"\n\n" if v != seen else b"event: ping\ndata: 1\n\n")
                self.wfile.flush()
                seen = v
                if st.closing:
                    return
        except OSError:                          # the tab was closed or reloaded
            pass

    def do_POST(self):
        app = self.server.app
        url = urllib.parse.urlsplit(self.path)
        try:
            if not self._allowed(post=True):
                return self._send(403, {"ok": False})
            query = urllib.parse.parse_qs(url.query)
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_UPLOAD:
                if url.path == "/api/upload":
                    app.batch.unread(query.get("name", ["document"])[0], "too_big")
                return self._send(413, {"ok": False, "code": "too_big"})
            body = self.rfile.read(n)
            if url.path == "/api/upload":
                return self._send(200, app.batch.take(query.get("name", ["document"])[0], body, more="more" in query,
                                                      as_photo="photo" in query))
            if url.path == "/api/downloads":
                return self._send(200, app.batch.from_downloads())
            if url.path == "/api/report":
                return self._send(200, app.save_report())
            msg = json.loads(body or b"{}")
            if not isinstance(msg, dict):
                return self._send(400, {"ok": False})
            if url.path == "/api/import":
                photos = msg.get("photos") if isinstance(msg.get("photos"), list) else []
                return self._send(200, app.batch.import_answer(str(msg.get("text") or ""), [str(p) for p in photos],
                                                               str(msg.get("driver") or ""), str(msg.get("customer") or "")))
            if url.path == "/api/cmd" and msg.get("cmd") in COMMANDS:
                if msg["cmd"] == "cancel":
                    app.cancel.set()             # seen by the engine at its next step, not at its next loop
                app.cmds.put(msg)
                return self._send(202, {"ok": True})
            self._send(404, {"ok": False})
        except OSError:
            pass
        except Exception:                        # never a traceback on the page: the page shows its own sentence
            app.log("HTTP " + traceback.format_exc())
            try:
                self._send(500, {"ok": False, "code": "internal"})
            except OSError:
                pass


def make_server(app):
    """bound to the loopback address only; the system chooses the port"""
    httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    httpd.daemon_threads = True
    httpd.app = app
    return httpd
