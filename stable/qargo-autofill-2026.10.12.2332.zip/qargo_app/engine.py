"""The engine: the program's main thread, and the ONLY code that ever touches the browser (Playwright's sync
API belongs to the thread that started it).

One browser window. Its first tab is the control page (page.html from our own local server); the Qargo tabs
open next to it, one per order, and the one being filled is in front, as with the command line.
Loop, about ten times a second: let Playwright see what happened in the browser -> look at the tabs ->
run the commands the page sent -> one unit of work (a look at the login, or one whole order).

    page -> engine    POST /api/cmd puts a message on a queue; "cancel" also sets an event at once, because the
                      engine may be in the middle of an order and only reads the queue between orders
    engine -> page    Store.update(); the page gets the whole state pushed after every change
"""
import queue, time, traceback
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout, Error as PWError
from . import texts
from .documents import reasons, unique

# A "Back to the list" button inside a Qargo tab. The function is defined in every page, but the button is only
# made when the engine asks for it, AFTER the bot is done with the tab, and in a closed shadow root: no selector
# of the bot can ever match it.
PILL_JS = """(() => {
  if (window.top !== window) return;
  let btn = null;
  window.__qaPill = (text) => {
    if (!btn) {
      const host = document.createElement('div'), root = host.attachShadow({mode: 'closed'});
      btn = document.createElement('button');
      btn.style.cssText = 'all:initial;position:fixed;left:16px;bottom:12px;z-index:2147483647;cursor:pointer;' +
        'font:600 20px system-ui,sans-serif;min-height:56px;padding:14px 22px;border-radius:12px;background:#12355b;' +
        'color:#fff;border:3px solid #fff;box-shadow:0 2px 12px rgba(0,0,0,.45);box-sizing:border-box';
      btn.addEventListener('click', () => window.__qaBack && window.__qaBack());
      root.appendChild(btn); document.documentElement.appendChild(host);
    }
    btn.textContent = text;
  };
})();"""


class Engine:
    def __init__(self, app, filler):
        self.app, self.st, self.q = app, app.store, filler
        self.quit = False
        self.pw = self.ctx = self.control = None
        self.ctx_closed = False
        self.exit_code = 0
        self.tabs = {}                 # order id -> its Qargo tab
        self.probe = None              # the Qargo "Orders" tab: where we look whether we are logged in, and where the operator logs in
        self.resume = False            # after the login: carry on with the run
        self.relogin = set()           # orders that were put back once because the login had run out
        self.control_lost = None
        self.next_poll = 0.0
        self.login_since = 0.0
        self.in_since = None
        self.save_watch = {}           # order id -> (address of the order page its tab went to, when we first saw it)
        self.failures = []             # times of unexpected errors in the loop

    # -- life cycle
    def run(self):
        app = self.app
        try:
            self.pw = sync_playwright().start()
            # Playwright's own Chromium has no channel name when it has a window (that is the command line's call)
            channel = app.browser if app.browser != "chromium" else ("chromium" if app.headless else None)
            args = ["--hide-crash-restore-bubble"] + ([f"--remote-debugging-port={app.debug_port}"] if app.debug_port else [])
            self.q.set_log(app.log_line)
            self.ctx = self.q.open_browser(self.pw, app.profile, channel, app.headless, args)
            self.ctx.on("close", lambda *_: setattr(self, "ctx_closed", True))
            # the page proves it is ours with a cookie only this browser has: no secret in the address bar
            self.ctx.add_cookies([{"name": "qa_token", "value": app.token, "url": app.origin,
                                   "httpOnly": True, "sameSite": "Strict"}])
            try:
                self.ctx.grant_permissions(["clipboard-read", "clipboard-write"], origin=app.origin)   # Copy / Paste buttons
            except PWError as e:
                app.log(f"clipboard permission not granted: {str(e).splitlines()[0]}")
            self.ctx.expose_binding("__qaBack", lambda source: app.cmds.put({"cmd": "front"}))   # only queues: no Playwright here
            self.ctx.add_init_script(PILL_JS)
            self.control = self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
            self.control.goto(app.origin + "/")
            self.control.wait_for_function("document.documentElement.dataset.ready === '1'", timeout=20000)
            app.log(f"control page showing in the first tab: {self.open_pages() == [self.control]}")
            app.started()
            self.check_login()
            while not self.quit:
                self.pump(100)
                if self.ctx_closed:
                    break
                try:
                    if not self.look_at_tabs():
                        break
                    self.run_commands()
                    if not self.quit:
                        self.work()
                except Exception:
                    if self.ctx_closed or not self.open_pages():      # the window went away under our hands
                        break
                    if not self.survive():
                        break
        except Exception:
            if self.ctx is None or (not self.ctx_closed and self.open_pages()):   # a bug, not "the browser went away"
                app.log("ENGINE " + traceback.format_exc())
                self.exit_code = 1
        finally:
            self.shutdown()
        return self.exit_code

    def survive(self):
        """something unexpected in the loop: write it down, tell the operator in one sentence, carry on. Five of
        them within half a minute: stop the program instead of spinning."""
        self.app.log("ENGINE " + traceback.format_exc())
        now = time.time()
        self.failures = [t for t in self.failures if now - t < 30] + [now]

        def tell(s):
            s["problem"] = "unexpected"
            for o in s["orders"]:                     # an order the error interrupted: it did not work
                if o["status"] == "filling":
                    o.update(status="failed", step=None, reasons=[{"code": "fill.error", "p": {}}])
                    if s["run"]:
                        s["run"].update(done=s["run"]["done"] + 1, current=None)
        self.st.update(tell)
        if len(self.failures) >= 5:
            self.exit_code = 1
            return False
        return True

    def pump(self, ms):
        """Let Playwright process browser events (tab closed, navigated ...). In the sync API they are only
        processed inside a Playwright call, so an idle engine must make one: this one needs no page."""
        try:
            self.ctx.wait_for_event("close", timeout=ms)
            self.ctx_closed = True
        except PWTimeout:
            pass
        except PWError:
            self.ctx_closed = True

    def open_pages(self):
        try:
            return [p for p in self.ctx.pages if not p.is_closed()]
        except Exception:
            return []

    def shutdown(self):
        self.st.closing = True
        self.st.update(phase="closing")
        self.app.log("closing")
        for close in (lambda: self.ctx and self.ctx.close(), lambda: self.pw and self.pw.stop()):
            try:
                close()
            except Exception:
                pass
        self.app.close()

    # -- tabs
    def look_at_tabs(self):
        """False = the window is gone: stop. Also: reopen a closed control tab, notice Save and closed order tabs."""
        if not self.open_pages():
            return False                   # macOS keeps the browser running without a window; Windows quits it
        phase = self.st.phase()
        if self.control.is_closed():
            if self.control_lost is None:  # wait a moment: is the whole window closing, or only this tab?
                self.control_lost = time.time()
                return True
            if time.time() - self.control_lost < 0.4:
                return True
            self.control = self.ctx.new_page()
            self.control.goto(self.app.origin + "/")
            self.st.update(notice={"code": "control_reopened", "p": {}}, front="control")
            self.app.log("control tab was closed: reopened")
        elif not self.control.url.startswith(self.app.origin):
            # Another address in our tab. While logging in that can be Qargo's e-mailed login link, pasted into
            # this tab's address bar: let it finish (work() sees the login and brings the list back).
            if not (phase in ("login", "login_check") and self.control.url.startswith("http")):
                self.control.goto(self.app.origin + "/")
        self.control_lost = None
        for oid, tab in list(self.tabs.items()):
            status = self.st.status(oid)
            if status not in ("filled", "attention"):
                continue
            if tab.is_closed():
                self.st.set_order(oid, status="tab_closed")
                del self.tabs[oid]
                self.app.log(f"{oid}: its tab was closed before it was saved")
            elif self.q.saved_re.search(tab.url):              # the operator pressed Save in Qargo - or went elsewhere
                self.look_at_saved(oid, tab)
            else:
                self.save_watch.pop(oid, None)
        return True

    def reference(self, oid):
        return str(((self.st.full.get(oid) or {}).get("order") or {}).get("customer_reference") or "")

    def look_at_saved(self, oid, tab):
        """The tab is on an order page that is not "new". It only counts as saved when that page shows THIS
        order's customer reference (the same address pattern fits any order the operator clicks through to)."""
        url, since = self.save_watch.get(oid) or (None, 0)
        if url != tab.url:
            url, since = tab.url, time.time()
            self.save_watch[oid] = (url, since)
        if self.q.shows_reference(tab, self.reference(oid)):
            self.saved(oid, tab)
        elif time.time() - since > 10 and since:               # the page has had its time to load: it is another order
            self.save_watch[oid] = (url, 0)                    # said once; a new address starts the watch again
            self.app.log(f"{oid}: tab is on {url}, which does not show customer reference {self.reference(oid)!r}: not counted as saved")
            self.doubt(oid, f"an order page opened, but it does not show customer reference {self.reference(oid)!r}")

    def doubt(self, oid, raw):
        o = self.st.order(oid) or {"reasons": []}
        self.st.set_order(oid, status="attention", reasons=unique(o["reasons"] + reasons([raw], "pdf")))

    def saved(self, oid, tab):
        """the order is in Qargo: remember it, come back to the list, close its tab (fewer tabs to get lost in)"""
        self.app.mark_done(oid, tab.url)
        self.st.set_order(oid, status="saved", reasons=[], step=None)
        self.app.log(f"{oid} saved: {tab.url}")
        self.save_watch.pop(oid, None)
        if self.st.phase() not in ("running", "stopping"):
            self.front(self.control)
        self.tabs.pop(oid, None)
        try:
            tab.close(run_before_unload=False)
        except PWError:
            pass

    def pill(self, tab):
        try:
            tab.evaluate("t => window.__qaPill && window.__qaPill(t)", texts.text(self.st.read(lambda s: s["lang"]), "pill"))
        except PWError:
            pass

    def front(self, page, name="control"):
        try:
            page.bring_to_front()
            self.st.update(front=name)
        except PWError:
            pass

    # -- commands from the page (run between units of work, on the engine thread)
    def run_commands(self):
        while True:
            try:
                c = self.app.cmds.get_nowait()
            except queue.Empty:
                return
            self.app.log(f"cmd {c}")
            getattr(self, "cmd_" + c["cmd"])(c)

    def cmd_start(self, c):
        if self.st.phase() not in ("ready", "review") or self.st.read(lambda s: s["reading"]):
            return
        self.app.cancel.clear()
        picked = []

        def queue_them(s):                          # in ONE look at the list: a row that is replaced just now is not taken
            picked.extend(o for o in s["orders"] if o["status"] == "ready")
            if picked:
                for o in picked:
                    o.update(status="queued", step=None)
                s.update(run={"total": len(picked), "done": 0, "current": None}, notice=None,
                         problem=None if s["problem"] == "unexpected" else s["problem"])     # a new start: that is over
        self.st.update(queue_them)
        if not picked:
            return
        self.resume = True
        self.check_login()                          # the session may have expired since this morning

    def cmd_cancel(self, c):
        if self.st.phase() == "running":
            self.st.update(phase="stopping")

    def cmd_show(self, c):
        oid = c.get("id")
        tab = self.tabs.get(oid)
        done = self.app.done_now()
        if (tab is None or tab.is_closed()) and oid in done and self.st.status(oid) == "saved":   # open the saved order again
            tab = self.tabs[oid] = self.ctx.new_page()
            tab.goto(done[oid])
        if tab and not tab.is_closed():
            self.pill(tab)
            self.front(tab, oid)

    def cmd_front(self, c):
        self.front(self.control)

    def cmd_raise(self, c):
        """the icon was clicked again while we run: put our window in front of the operator"""
        try:
            cdp = self.ctx.new_cdp_session(self.control)
            win = cdp.send("Browser.getWindowForTarget")
            if win.get("bounds", {}).get("windowState") == "minimized":
                cdp.send("Browser.setWindowBounds", {"windowId": win["windowId"], "bounds": {"windowState": "normal"}})
            cdp.detach()
        except Exception as e:
            self.app.log(f"raise: {type(e).__name__}: {str(e).splitlines()[0][:200]}")
        self.front(self.control)

    def cmd_open_login(self, c):
        if self.probe is None or self.probe.is_closed():
            self.check_login()
        self.front(self.probe, "login")

    def cmd_recheck(self, c):
        if self.st.phase() == "offline":
            self.check_login()

    def cmd_remove(self, c):
        self.app.batch.remove(c.get("id"))

    def cmd_remove_doc(self, c):
        self.app.batch.remove_doc(c.get("name"))

    def cmd_retry(self, c):
        oid = c.get("id")
        if self.st.status(oid) in ("failed", "stopped", "tab_closed", "attention", "filled"):
            tab = self.tabs.pop(oid, None)
            if tab and not tab.is_closed():
                tab.close(run_before_unload=False)
            self.save_watch.pop(oid, None)
            full = self.st.full.get(oid) or {"warnings": [], "origin": "pdf"}
            self.st.set_order(oid, status="ready", reasons=reasons(full["warnings"], full["origin"]), step=None, qargo=None)

    def cmd_set_lang(self, c):
        if c.get("lang") in texts.LANGS:
            self.st.update(lang=c["lang"])
            self.app.save_settings(lang=c["lang"])

    def cmd_autosave(self, c):
        self.st.update(autosave=bool(c.get("on")))

    def cmd_done(self, c):
        self.quit = True

    # -- one unit of work per loop
    def check_login(self):
        """(re)load Qargo's order list in its own tab, behind the control tab; work() watches where it ends up"""
        if self.probe is None or self.probe.is_closed():
            self.probe = self.ctx.new_page()            # a new tab comes to the front ...
            self.front(self.control)                    # ... so put the control tab back
        self.st.update(phase="login_check")
        try:
            self.probe.goto(self.q.tenant + "/orders", wait_until="domcontentloaded")
        except PWError as e:                            # no internet, or Qargo is down
            self.app.log(f"Qargo cannot be reached: {str(e).splitlines()[0][:200]}")
            self.front(self.control)
            return self.st.update(phase="offline")
        self.login_since, self.in_since = time.time(), None

    def login_now(self, phase):
        """While we wait for the operator to log in, any tab counts (a login link pasted into another tab's
        address bar); before that only our own look at Qargo does."""
        pages = [self.probe] if phase == "login_check" else \
            [p for p in self.open_pages() if p not in self.tabs.values() and not p.url.startswith(self.app.origin)]
        states = [self.q.login_state(p) for p in pages if not p.is_closed()]
        return "in" if "in" in states else "out" if "out" in states else "unknown"

    def work(self):
        phase = self.st.phase()
        if phase in ("login_check", "login"):
            now = time.time()
            if now < self.next_poll:
                return
            self.next_poll = now + 0.5
            if self.probe.is_closed():                  # the operator closed the login tab: open it again
                return self.check_login()
            state = self.login_now(phase)
            if state == "in":
                self.in_since = self.in_since or now
                if now - self.in_since >= self.q.settle:
                    has_run = self.resume and self.st.read(lambda s: any(o["status"] == "queued" for o in s["orders"]))
                    self.resume = False
                    if not self.control.is_closed() and not self.control.url.startswith(self.app.origin):
                        self.control.goto(self.app.origin + "/")
                    self.front(self.control)            # no "press Enter": we come back by ourselves
                    self.app.log("logged in to Qargo")
                    self.st.update(phase="running" if has_run else "ready")
            else:
                self.in_since = None
                if phase == "login_check" and (state == "out" or now - self.login_since > 15):
                    self.app.log("not logged in to Qargo: showing the login screen")
                    self.front(self.control)            # explain first; the page's button shows the login tab
                    self.st.update(phase="login")
        elif phase in ("running", "stopping"):
            nxt = self.st.read(lambda s: next((o["id"] for o in s["orders"] if o["status"] == "queued"), None))
            if self.app.cancel.is_set() or nxt is None:
                self.st.update(lambda s: [o.update(status="ready") for o in s["orders"] if o["status"] == "queued"],
                               phase="review")
                self.app.cancel.clear()
                self.front(self.control)                # results: back to the list
            else:
                self.fill_next(nxt)

    def fill_next(self, oid):
        full = self.st.full.get(oid)
        if full is None:                                # cannot happen; never spin on it
            return self.st.set_order(oid, status="failed", reasons=[{"code": "fill.error", "p": {}}])
        o, origin = full["order"], full["origin"]
        total, marks = self.q.steps(o), []

        def step(ctx=None, label=""):
            if self.app.cancel.is_set():
                raise self.q.Cancelled()
            # which stop the bot is at when a warning appears: its location warnings do not say
            marks.append((len(ctx["warnings"]) if ctx else 0, (ctx or {}).get("stop") or label))
            self.st.set_order(oid, step={"i": min(len(marks), total), "n": total})

        self.st.update(lambda s: s["run"].update(current=oid))
        self.st.set_order(oid, status="filling", step={"i": 0, "n": total}, reasons=[], qargo=None)
        self.st.update(front=oid)                       # the bot brings the order's tab to the front itself
        tab, status, why, extra = None, "filled", [], {}
        try:
            res = self.q.fill(self.ctx, o, self.app.batch.doc_dirs(), full["warnings"], step)
        except self.q.Cancelled:
            res, status = None, "stopped"               # the half-filled tab is closed already
            self.app.log("    => stopped by the operator")
        if res is not None:
            tab = res.tab if res.tab is not None and not res.tab.is_closed() else None
            stop_at = lambda i: next((s for n, s in reversed(marks) if n <= i), None)
            why = unique(r for i, w in enumerate(res.warnings) for r in reasons([w], origin, stop_at(i)))
            if res.status == "duplicate":
                status, why, extra = "duplicate", [], {"qargo": res.qargo}
            elif res.status == "failed":
                status, why = self.failed(oid, o, tab, bool(marks))
                if tab and status != "queued":
                    self.app.log(f"    (closing the tab of {oid})")
                if tab:
                    tab.close(run_before_unload=False)
                tab = None
            elif tab is None:
                status, why = "tab_closed", []          # closed under the bot's hands, right at the end
            elif res.warnings:
                status = "attention"                    # any doubt at all: a person looks, and nothing is saved for them
            elif self.st.read(lambda s: s["autosave"]):
                raw = self.save(oid, tab, o)
                if raw is None:
                    status = "saved"
                else:
                    self.app.log(f"    !! {raw}")
                    status, why = "attention", reasons([raw], origin)
        if tab is not None:
            self.tabs[oid] = tab
        self.st.set_order(oid, status=status, reasons=why, step=None, **extra)
        if status == "saved":
            self.saved(oid, tab)
        elif status in ("filled", "attention"):
            self.pill(tab)
        if status != "queued":
            self.st.update(lambda s: s["run"].update(done=s["run"]["done"] + 1, current=None))
        self.app.log(f"    => list: {status}")

    def failed(self, oid, o, tab, got_going):
        """ERROR from the bot. Either the login ran out (the order goes back in the queue, once, and the run
        waits for the operator), or the order did not work: one plain reason, the detail is in the log."""
        if tab is not None and oid not in self.relogin and self.q.login_state(tab) == "out":
            self.relogin.add(oid)
            self.app.log(f"    {oid}: not logged in any more; back in the queue")
            self.resume = True
            self.check_login()
            return "queued", []
        if tab is None:
            return "tab_closed", []
        why = [{"code": "fill.error", "p": {}}]
        if not got_going:                               # stopped before the first field: almost always the customer
            why.append({"code": "fill.early_stop", "p": {"customer": str(o.get("customer") or "")}})
        return "failed", why

    def save(self, oid, tab, o):
        """Press Save for an order without any doubt. None when Qargo then shows THIS order; else what to tell."""
        ref = str(o.get("customer_reference") or "")
        try:
            self.q.press_save(tab)
        except PWTimeout:
            return "Save clicked but no order page opened - check the tab"
        end = time.time() + 10
        try:
            while time.time() < end:
                if self.q.shows_reference(tab, ref):
                    return None
                tab.wait_for_timeout(250)
        except PWError:
            # The tab went away. Qargo had opened an order page for the bot's own Save: that is saved, as the
            # command line counts it; "did not work" would have the operator fill the order a second time.
            self.app.log(f"    {oid}: the tab was closed before the saved order could be read; counted as saved")
            return None
        self.save_watch[oid] = (tab.url, 0)             # look_at_saved has nothing more to say about this address
        return f"an order page opened, but it does not show customer reference {ref!r}"
