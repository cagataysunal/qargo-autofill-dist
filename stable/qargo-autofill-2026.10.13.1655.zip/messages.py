"""Message catalogue for the app's window: what the tool's own English strings mean.

The command line keeps printing those strings as they are; other code (and the tests) classify them. Here
each one gets a stable key and the id of a sentence for the operator:

    classify(raw) -> (stable_key, text_id, params)      raw = a validator message, a filler warning, a review note
    reason(raw, origin="pdf", stop=None) -> {"code": text_id, "p": {...}}      what the app's page shows

The sentences themselves are not here: they are "r.<text id>" in qargo_app/strings/<language>.json, and the page
fills in the parameters. Two parameters are names the page looks up in the same table: "stop"
({"k": "deliver", "n": 2} -> "stop.deliver") and "field" ("date" -> "field.date").

Severity: "info" (nothing to do), "check" (look before pressing Save), "stop" (this order cannot be filled).
"""
import re

SEVERITY = {
    # parser doubts (order["review"]) and the importer's notes
    "review.load_paired": "check", "review.load_not_added": "check", "review.unload_paired": "check",
    "review.remark_overprinted": "check", "review.hired_truck": "check", "review.pages_not_found": "check",
    "review.line_elsewhere": "check", "review.time_unclear": "check", "review.goods_unclear": "check",
    "review.dates_swapped": "check", "review.rit_several": "check", "review.no_reference": "check",
    "review.nothing_to_fill": "stop", "review.other": "check",
    "import.empty": "stop", "import.no_json": "stop", "import.cut_off": "stop", "import.photo_unclear": "stop",
    "import.customer_unknown": "stop", "import.no_photo": "stop", "import.bad_format": "stop",
    "import.only_first_photo": "check",
    "import.value_dropped": "check", "import.extra_field": "check", "import.consignment_dropped": "check",
    "import.check_country": "check",
    # validator
    "order.invalid": "stop", "val.missing_field": "stop", "val.date_bad": "stop", "val.date_far": "check",
    "val.time_bad": "stop", "val.crosses_midnight": "check", "val.postcode_bad": "stop", "val.no_postcode": "check",
    "val.address_guessed": "check", "val.phone_bad": "stop", "val.cargo_bad": "stop",
    "val.delivery_before_pickup": "stop", "val.delivery_no_time": "check", "val.idle_same_place": "check", "val.long_gap": "check",
    "val.trip_too_long": "check", "val.start_after_first_pickup": "check", "val.end_before_last_delivery": "check",
    "val.no_ritnummer": "check", "doc.not_attached": "check",
    # filling Qargo
    "fill.no_location": "check", "fill.location_ambiguous": "check", "fill.location_check": "check",
    "fill.location_empty": "check", "fill.field_skipped": "check", "fill.field_differs": "check",
    "fill.enforce": "check", "fill.empty_trip_on": "check", "fill.pages_check": "check",
    "fill.start_end_stop": "check", "fill.duplicate_after_fill": "check", "fill.check": "check",
    "fill.save_unsure": "check", "fill.save_other_order": "check",
    "fill.error": "stop", "fill.early_stop": "stop", "fill.browser_closed": "stop", "fill.duplicate": "stop",
    "fill.screenshot": "info",
}
STOPS = ("start", "end", "collect", "deliver", "goods", "order", "document")      # "stop.<k>" in the string tables
FIELDS = ("customer_reference", "consignments", "instructions", "ritnummer", "reference", "location", "duration",
          "activity", "customer", "document", "delivery", "country", "street", "pickup", "weight", "source",
          "phone", "query", "goods", "date", "time", "note", "name", "key")          # "field.<name>"

W = r"(?P<where>order|start stop|end stop|c\d+(?: (?:collect|deliver|goods \d+))?)(?P<loc>\.location)?"

# (stable key, regex on the whole raw text, text id)
VALIDATOR = [      # validate_orders.py
 ("val.not_a_list", r"the file must contain a list of orders", "import.bad_format"),
 ("val.not_an_object", W + r": expected an object, got (?P<type>\w+)", "import.bad_format"),
 ("val.missing_field", W + r": '(?P<field>\w+)' is missing or empty", "val.missing_field"),
 ("val.unknown_field", W + r": unknown field '(?P<name>[^']*)' \(typo\? the bot would ignore it\)", "import.bad_format"),
 ("val.date_format", W + r": date (?P<value>.+) is not DD/MM/YYYY", "val.date_bad"),
 ("val.date_far", W + r": date (?P<value>\S+) is more than 60 days from today \(day/month swapped\?\)", "val.date_far"),
 ("val.date_impossible", W + r": date (?P<value>\S+) does not exist", "val.date_bad"),
 ("val.time_format", W + r": (?P<field>start|end|duration) (?P<value>.+) is not HH:MM", "val.time_bad"),
 ("val.crosses_midnight", W + r": window (?P<start>\S+?)-(?P<end>\S+) crosses midnight; check how Qargo stored this stop", "val.crosses_midnight"),
 ("val.activity", W + r": activity (?P<value>.+) is not possible here; use one of (?P<allowed>\[.*\])", "import.bad_format"),
 ("val.phone_on_start_end", W + r": start/end stops have no phone number in Qargo; remove 'phone'", "import.bad_format"),
 ("val.phone_format", W + r": phone (?P<value>.+) does not look like a phone number", "val.phone_bad"),
 ("val.stop_text", W + r": (?P<field>reference|note|instructions) must be text", "import.bad_format"),
 ("val.postcode", W + r": postcode (?P<value>.+) is not a valid (?P<country>\w+) postcode \(write it without spaces, e\.g\. 1507CJ\)", "val.postcode_bad"),
 ("val.no_postcode", W + r": no postcode for (?P<name>.+) - the bot can only match on street/name", "val.no_postcode"),
 ("val.address_guessed", W + r": (?P<name>.+) was guessed from a one-line address; check the picked location", "val.address_guessed"),
 ("val.store_format", W + r": store (?P<value>.+) must be the 4-digit AH store number", "import.bad_format"),
 ("val.store_query", W + r": AH store (?P<store>\S+) should be searched as 'Winkel \S+', not (?P<name>.+)", "val.address_guessed"),
 ("val.idle_same_place", r"stays at (?P<name>.+) for (?P<gap>.+?) \((?P<a>.+?) \d\d:\d\d -> (?P<b>.+?) \d\d:\d\d\) with nothing in between - is this a real trip\? check with the customer", "val.idle_same_place"),
 ("val.long_gap", r"nothing happens for (?P<gap>.+?) \(.+ \d\d:\d\d -> .+ \d\d:\d\d\) - check the order", "val.long_gap"),
 ("val.duplicate_key", r"key appears twice \(orders #(?P<a>\d+) and #(?P<b>\d+)\); the bot would fill only one", "import.bad_format"),
 ("val.key_prefix", r"key should start with (?P<prefix>\S+) for (?P<customer>.+)", "import.bad_format"),
 ("val.reference_not_text", r"customer_reference must be text \(put it in quotes\)", "import.bad_format"),
 ("val.ritnummer_format", r"ritnummer (?P<value>.+) must be a whole number or null", "import.bad_format"),
 ("val.no_ritnummer", r"no ritnummer, but (?P<customer>.+) documents always have one", "val.no_ritnummer"),
 ("val.instructions_not_text", r"instructions must be text", "import.bad_format"),
 ("val.pages_format", r"pages (?P<value>.+) must be \[first, last\]: whole page numbers, first <= last", "import.bad_format"),
 ("val.review_format", r"review must be a list of texts", "import.bad_format"),
 ("val.source_missing", r"source file (?P<file>.+?) not found in (?P<dirs>.+); nothing will be attached", "doc.not_attached"),
 ("val.no_consignment", r"needs at least one consignment", "order.invalid"),
 ("val.delivery_before_pickup", r"c(?P<n>\d+): delivery \((?P<d>.*)\) is before its collection \((?P<p>.*)\)", "val.delivery_before_pickup"),
 ("val.delivery_no_time", W + r": no time, on the day of its collection \((?P<p>.*)\); check the delivery time", "val.delivery_no_time"),
 ("val.goods_not_list", W + r": goods must be a list", "import.bad_format"),
 ("val.quantity", W + r": quantity (?P<value>.+) must be a positive number", "val.cargo_bad"),
 ("val.weight", W + r": weight_kg (?P<value>.+) must be a number of kg between 0 and 45000", "val.cargo_bad"),
 ("val.empty_cargo", W + r": empty cargo line", "val.cargo_bad"),
 ("val.start_after_first_pickup", r"start stop is later than the first collection", "val.start_after_first_pickup"),
 ("val.end_before_last_delivery", r"end stop is earlier than the last delivery", "val.end_before_last_delivery"),
 ("val.trip_too_long", r"trip spans (?P<gap>.+) - wrong date somewhere\?", "val.trip_too_long"),
 ("val.crashed", r"validator crashed: (?P<detail>.*)", "import.bad_format"),      # qargo_app/documents.py: check()
]
REVIEW = [         # the text after "check: ": parse_trips.py's review notes, then chat_import.py's
 ("review.remark_overprinted", r"(?P<kind>Aankoppelen|Afkoppelen|Laden|Lossen|AH Stop|Rust|Wachten) (?P<date>\d\d/\d\d) (?P<time>\S+): a remark line is printed over by the route number: .*; check the PDF", "review.remark_overprinted"),
 ("review.load_not_added", r"load (?P<what>.+) comes after the last (?:unload|delivery): NOT a stop in the order \(only in Instructions\) - add it by hand", "review.load_not_added"),
 ("review.load_paired", r"load (?P<what>.+) has no unload (?:of its own|with that code)(?: in the PDF)?; paired with the first (?:unload|delivery) after it \((?P<to>.+)\)", "review.load_paired"),
 ("review.unload_paired", r"unload (?P<what>.+) has no load with that code; paired with the previous load (?P<to>.+)", "review.unload_paired"),
 ("review.hired_truck", r"goods are (?P<desc>.+) \('dagspoed'\): PostNL books the truck with driver for the day, not a load - check what this order should be", "review.hired_truck"),
 ("review.pages_not_found", r"could not find this order's pages in the PDF: the whole PDF is attached \(it holds other orders too\)", "review.pages_not_found"),
 ("review.rit_several", r"no 'Ritnr' in the Ritomschrijving (?P<desc>.+) and the stop remarks name (?P<n>\d+) trip numbers \((?P<numbers>.+)\): ritnummer left empty - fill it in by hand", "review.rit_several"),
 ("review.rit_none", r"no 'Ritnr' anywhere in the PDF \(Ritomschrijving (?P<desc>.+)\): ritnummer left empty - fill it in by hand", "val.no_ritnummer"),
 ("review.no_reference", r"'Klant Route nr' is empty on the document: customer reference left empty", "review.no_reference"),
 ("review.nothing_to_fill", r"the document prints no Laden or Lossen \(only: (?P<stops>.*)\): there is nothing to make a consignment from, so this rit cannot be filled", "review.nothing_to_fill"),
 # Vredeveld (parse_vredeveld); "row" is "<load name> -> <unload name>", not a stop the page can name
 ("review.vrd_line_above", r"line above the (?:rows|first load) is not in the order: (?P<line>.*)", "review.line_elsewhere"),
 ("review.vrd_under_address", r"(?P<row>.+?): (?P<line>.+) is printed under the address of (?P<name>.+); kept as that stop's note", "review.line_elsewhere"),
 ("review.vrd_left_text", r"(?P<row>.+?): (?P<line>.+) is printed where the delivery time usually is; kept in the instructions", "review.line_elsewhere"),
 ("review.vrd_several_times", r"(?P<row>.+?): several delivery times printed (?P<times>\[.*\]); the first one is used", "review.time_unclear"),
 ("review.vrd_note_time", r"(?P<row>.+?): the note (?P<note>.+) names a time, but no time window is set \(.*\)", "review.time_unclear"),
 ("review.vrd_no_goods", r"(?P<row>.+?): no goods line \(VO-number, weight\) under this row", "review.goods_unclear"),
 ("review.vrd_odd_vo", r"(?P<row>.+?): (?P<odd>\[.*\]) does not look like a VO-number; check the goods line", "review.goods_unclear"),
 ("review.vrd_weight_sum", r"(?P<row>.+?): the goods lines add up to (?P<sum>\S+) kg, the PDF prints Subtotaal (?P<printed>\S+) kg - a line was not read", "review.goods_unclear"),
 ("review.vrd_no_total", r"no 'Totaal Gewicht' line found: check that every row of the PDF is in the order", "review.goods_unclear"),
 ("review.vrd_total", r"the consignments add up to (?P<sum>\S+) kg, the PDF prints Totaal Gewicht (?P<printed>\S+) kg - a row was not read", "review.goods_unclear"),
 ("review.vrd_dates", r"(?P<row>.+?): the PDF prints the unload date (?P<d>\S+) before the load date (?P<p>\S+); ask Vredeveld which is right", "review.dates_swapped"),
 ("import.time_dropped", W + r": the (?P<field>start|end|duration) time (?P<value>.+) could not be understood and was left empty", "import.value_dropped"),
 ("import.phone_dropped", W + r": the (?P<field>phone) number (?P<value>.+) could not be used and was left empty", "import.value_dropped"),
 ("import.activity_dropped", W + r": kind of stop (?P<value>.+) is not possible here; Qargo's normal one is used", "import.value_dropped"),
 ("import.quantity_dropped", W + r": quantity (?P<value>.+) could not be read and was left empty", "import.value_dropped"),
 ("import.weight_dropped", W + r": weight (?P<value>.+) could not be used and was left empty", "import.value_dropped"),
 ("import.extra_field", W + r": the chat program also wrote '(?P<name>[^']*)': (?P<value>.*)", "import.extra_field"),
 ("import.consignment_dropped", r"c(?P<n>\d+): not understood and left out", "import.consignment_dropped"),
 ("import.check_country", W + r": no country on the answer; check the country of (?P<name>.*)", "import.check_country"),
]
FILLER = [         # ctx["warnings"] entries of qargo_fill.py, logged as "    !! <text>"
 ("fill.store_house_number", r"CHECK store (?P<store>\S+): house number differs: document '(?P<doc>.*)', Qargo '(?P<qargo>.*)'", "fill.location_check"),
 ("fill.store_street", r"CHECK store (?P<store>\S+): document street '(?P<doc>.*)', Qargo '(?P<qargo>.*)'", "fill.location_check"),
 ("fill.postcode_other_street", r"CHECK same postcode but another street: document '(?P<doc>.*)' \((?P<name>.*)\), Qargo '(?P<qargo>.*)'", "fill.location_check"),
 ("fill.postcode_differs", r"CHECK postcode differs for '(?P<street>.*)': document (?P<doc>\S+), Qargo '(?P<qargo>.*)'", "fill.location_check"),
 ("fill.location_ambiguous", r"AMBIGUOUS location '(?P<query>.*)': picked '(?P<picked>.*)', also: (?P<others>\[.*\])", "fill.location_ambiguous"),
 ("fill.no_location", r"NO LOCATION for (?P<name>.+?) \((?P<addr>.*)\); tried (?P<queries>\[.*\]); seen: (?P<seen>\[.*\])", "fill.no_location"),
 ("fill.enforce_not_found", r"(?P<label>.+): Enforce switch not found", "fill.enforce"),
 ("fill.enforce_not_on", r"(?P<label>.+): Enforce switch not on", "fill.enforce"),
 ("fill.empty_trip_on", r"(?P<label>.+): could not switch off 'Plan trip to couple empty trailer'", "fill.empty_trip_on"),
 ("fill.skipped", r"SKIPPED (?P<step>.+?): (?P<exc>\w+): (?P<detail>.*)", "fill.field_skipped"),
 ("fill.weight_differs", r"CHECK (?P<label>c\d+ goods \d+): weight should be (?P<want>\S+) kg, form has (?P<got>.+)", "fill.field_differs"),
 ("fill.pages_no_split", r"CHECK document: asked for pages (?P<first>\d+)-(?P<last>\d+), but no 'Split from PDF' appeared", "fill.pages_check"),
 ("fill.pages_original_open", r"CHECK document: pages (?P<first>\d+)-(?P<last>\d+) split, but closing the original PDF tab failed - check which documents are attached", "fill.pages_check"),
 ("fill.document_not_found", r"document (?P<file>.+) not found in (?P<dirs>\[.*\])", "doc.not_attached"),
 ("fill.duplicate_after_fill", r"!!! DUPLICATE: Qargo says customer reference (?P<ref>.+) is already in (?P<order>\S+) \((?P<url>\S+)\)", "fill.duplicate_after_fill"),
 ("fill.field_differs", r"CHECK (?P<field_id>[\w.\[\]]+): expected (?P<want>.+), form has (?P<got>.+)", "fill.field_differs"),
 ("fill.stop_missing", r"!!! (?P<which>START|END) STOP MISSING: no (?P<field_id>\S+) in the form", "fill.start_end_stop"),
 ("fill.stop_location_empty", r"!!! (?P<which>START|END) STOP LOCATION EMPTY \((?P<name>.*)\)", "fill.start_end_stop"),
 ("fill.stop_date", r"!!! (?P<which>START|END) STOP DATE: expected (?P<want>.+), form has (?P<got>.+)", "fill.start_end_stop"),
 ("fill.stop_time", r"!!! (?P<which>START|END) STOP (?P<field>START|END) TIME: expected (?P<want>.+), form has (?P<got>.+)", "fill.start_end_stop"),
 ("fill.location_empty", r"EMPTY location field (?P<field_id>\S+)", "fill.location_empty"),
 ("fill.duplicate", r"already in Qargo as (?P<order>\S+) \((?P<url>\S+)\)\. Not filled\. If it really is another order: --allow-duplicate (?P<key>\S+)", "fill.duplicate"),
 ("fill.screenshot", r"screenshot: (?P<file>error_.+\.png)", "fill.screenshot"),
 ("fill.save_unsure", r"Save clicked but no order page opened - check the tab", "fill.save_unsure"),
 ("fill.save_other_order", r"an order page opened, but it does not show customer reference (?P<ref>.+)", "fill.save_other_order"),
 ("fill.browser_closed", r"TargetClosedError: (?P<detail>.*)", "fill.browser_closed"),
 ("fill.error", r"(?P<exc>[A-Za-z_]\w*): (?P<detail>.*)", "fill.error"),     # must stay last
]
APP = [            # notes the app itself adds to an order (text after "app: ")
 ("import.only_first_photo", r"only the first of (?P<n>\d+) photos is attached", "import.only_first_photo"),
]

_C = lambda rules: [(k, re.compile(rx, re.S), tid) for k, rx, tid in rules]
_VALIDATOR, _REVIEW, _FILLER, _APP = _C(VALIDATOR), _C(REVIEW), _C(FILLER), _C(APP)
# every sentence id classify() / reason() can hand out: each needs "r.<id>" in every string table
TEXT_IDS = sorted({tid for rules in (VALIDATOR, REVIEW, FILLER, APP) for _, _, tid in rules}
                  | {"review.other", "order.invalid", "fill.check", "fill.early_stop", "import.empty", "import.no_json",
                     "import.cut_off", "import.photo_unclear", "import.customer_unknown", "import.no_photo"})


def _first(rules, text):
    for key, rx, tid in rules:
        m = rx.fullmatch(text)
        if m:
            return key, tid, {k: v for k, v in m.groupdict().items() if v is not None}
    return None


def classify(raw):
    """(stable key, text id, params) for a validator message, a review note or a filler warning; never raises"""
    raw = str(raw)
    text = raw[len("JSON: "):] if raw.startswith("JSON: ") else raw           # fill_one's prefix for validator warnings
    if text.startswith("app: "):
        return _first(_APP, text[len("app: "):]) or ("app.unclassified", "fill.check", {"text": text})
    if text.startswith("check: "):                                            # the validator's prefix for review notes
        note = text[len("check: "):]
        return _first(_REVIEW, note) or ("review.other", "review.other", {"text": note})
    hit = _first(_VALIDATOR, text)
    if hit or raw.startswith("JSON: "):
        return hit or ("val.unclassified", "order.invalid", {"text": text})
    return _first(_FILLER, text) or ("fill.unclassified", "fill.check", {"text": text})


def stop_of(where):
    """'c2 deliver' / 'start stop' / 'END' / 'consignments[1].actual_pickup_stop.date' -> {"k": "deliver", "n": 2}"""
    where = where or ""
    m = re.search(r"consignments\[(\d+)\]\.actual_(pickup|delivery)_stop", where)
    if m:
        return {"k": "collect" if m.group(2) == "pickup" else "deliver", "n": int(m.group(1)) + 1}
    m = re.match(r"c(\d+)(?: (collect|deliver|goods))?", where)
    if m:
        return {"k": m.group(2) or "deliver", "n": int(m.group(1))}
    low = where.lower()
    if low.startswith(("start", "setup", "add start")):
        return {"k": "start"}
    if low.startswith(("end", "teardown", "add end")):
        return {"k": "end"}
    if "pdf" in low or low.startswith("document"):
        return {"k": "document"}
    return {"k": "order"}


def _plain(v):
    """a value as the messages print it (repr: 'x', "x", None) -> the value itself; nothing -> a dash"""
    v = str(v).strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
        v = v[1:-1]
    return "\u2014" if v in ("", "None") else v


def _hours(gap):
    """timedelta text ('7:15:00', '1 day, 2:00:00') -> '7:15' / '26:00' (hours:minutes)"""
    m = re.fullmatch(r"(?:(\d+) days?, )?(\d+):(\d\d):\d\d(?:\.\d+)?", str(gap).strip())
    return f"{int(m.group(1) or 0) * 24 + int(m.group(2))}:{m.group(3)}" if m else str(gap)


def reason(raw, origin="pdf", stop=None):
    """what the page shows for one raw message: {"code": text id, "p": parameters}. origin: "pdf" (our own
    parser made the order) or "photo" / "file" (somebody else did). stop: the step or stop the filler was at
    when it gave this warning (its location warnings do not name their stop). Never raises."""
    key, tid, p = classify(raw)
    if tid == "import.bad_format" and origin == "pdf":
        tid = "order.invalid"             # nobody can "ask the chatbot again" for a document our parser read
    step = p.get("step", "")
    where = p.get("where") or p.get("label") or p.get("field_id") or step or p.get("which") or stop or ""
    out = {"stop": stop_of(where)}
    field = p.get("field")
    if key == "fill.skipped":
        field = next((f for f in sorted(FIELDS, key=len, reverse=True) if step.endswith(f)), None) \
            or ("goods" if "goods" in step else "location" if "stop" in step or step.endswith("scroll")
                else "document" if "PDF" in step else "customer_reference" if "duplicate" in step
                else "activity" if "empty trip" in step else "location")
    elif key in ("fill.field_differs", "fill.weight_differs"):
        fid = p.get("field_id") or p.get("label") or ""
        field = ("customer_reference" if "customer_reference" in fid else "ritnummer" if "ritnummer" in fid else
                 "date" if fid.endswith(".date") else "reference" if "reference" in fid else "weight")
    elif key == "import.activity_dropped":
        field = "activity"
    elif key == "import.quantity_dropped":
        field = "goods"
    elif key == "import.weight_dropped":
        field = "weight"
    elif field in ("start", "end", "START", "END"):
        field = "time"
    if field:
        out["field"] = field
    for k in ("name", "value", "got", "want", "customer", "order", "file", "picked", "doc", "qargo", "start", "end", "text", "n"):
        if k in p:
            out[k] = _plain(p[k])
    if "gap" in p:
        out["gap"] = _hours(p["gap"])
    return {"code": tid, "p": out}
