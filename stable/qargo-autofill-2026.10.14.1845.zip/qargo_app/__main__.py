"""python -m qargo_app                        the operator's window (the launcher starts this)
python -m qargo_app --selftest             can this installation work? exit code 0 = yes (no window, no network)
python -m qargo_app --browser-smoke NAME   does chromium / chrome / msedge start here? exit code 0 = yes (no window)
"""
import argparse, os, sys


def main():
    for name in ("stdout", "stderr"):          # pythonw.exe has neither: argparse and print() need somewhere to write
        if getattr(sys, name) is None:
            setattr(sys, name, open(os.devnull, "w", encoding="utf-8"))
    ap = argparse.ArgumentParser(prog="python -m qargo_app", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--browser-smoke", metavar="NAME")
    a = ap.parse_args()
    from . import app
    if a.selftest:
        return app.selftest()
    if a.browser_smoke:
        return app.browser_smoke(a.browser_smoke)
    return app.main()


if __name__ == "__main__":
    sys.exit(main())
