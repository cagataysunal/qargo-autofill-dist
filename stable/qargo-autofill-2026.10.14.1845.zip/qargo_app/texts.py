"""Every sentence the operator can read is in strings/<language>.json: one file per language, the same keys and
the same {placeholders} in each (tests/test_strings.py and the self-test check that). Python only looks sentences
up here for the few it needs itself (the button inside a Qargo tab, the support report); the page does the rest.
The question for the chatbot is one text file, photo_prompt.txt: it is written for the chatbot, in English.
"""
import json, re
from pathlib import Path

HERE = Path(__file__).resolve().parent
LANGS = ("en", "tr", "nl", "bg")                 # English first: the default on every machine, and the fallback
PROMPT_LANGUAGE = {"en": "English", "tr": "Turkish", "nl": "Dutch", "bg": "Bulgarian"}
PLACEHOLDER = re.compile(r"\{(\w+)\}")
_tables = None


def tables():
    """{language: {key: sentence}}, read once"""
    global _tables
    if _tables is None:
        _tables = {lang: json.loads((HERE / "strings" / f"{lang}.json").read_text(encoding="utf-8-sig"))
                   for lang in LANGS}
    return _tables


def text(lang, key, **p):
    t = tables()
    s = t.get(lang, t["en"]).get(key) or t["en"].get(key) or key
    return PLACEHOLDER.sub(lambda m: str(p.get(m.group(1), "")), s)


def reason_text(lang, reason):
    """one reason of the list ({"code", "p"}, see messages.reason) as a sentence, built the way the page builds it"""
    p = dict(reason.get("p") or {})
    if isinstance(p.get("stop"), dict):
        p["stop"] = text(lang, "stop." + p["stop"]["k"], n=p["stop"].get("n", ""))
    if "field" in p:
        p["field"] = text(lang, "field." + str(p["field"]))
    return text(lang, "r." + reason["code"], **p)


def problems():
    """what is wrong with the tables themselves: [] when every language has the same keys and placeholders"""
    out, t = [], tables()
    for lang in LANGS[1:]:
        if list(t[lang]) != list(t["en"]):
            out.append(f"{lang}: keys differ from en: {sorted(set(t[lang]) ^ set(t['en']))[:8]}")
        for key, s in t[lang].items():
            if not isinstance(s, str) or not s.strip():
                out.append(f"{lang}: {key} is empty")
            elif key != "_status" and sorted(PLACEHOLDER.findall(s)) != sorted(PLACEHOLDER.findall(t["en"].get(key, ""))):
                out.append(f"{lang}: {key} has other placeholders than en")
    return out


def _prompt_file():
    return (HERE / "photo_prompt.txt").read_text(encoding="utf-8-sig").split("===== CORRECTION =====\n")


def photo_prompt(lang="en"):
    """the question the operator gives a chatbot together with the photo; it answers with orders as JSON"""
    return _prompt_file()[0].strip().replace("{LANGUAGE}", PROMPT_LANGUAGE.get(lang, "English")) + "\n"


def correction(lines):
    """what the operator pastes into the same chat when the answer was not right: the validator's own findings"""
    return _prompt_file()[1].strip().replace("{PROBLEMS}", "\n".join(f"- {x}" for x in lines)) + "\n"
