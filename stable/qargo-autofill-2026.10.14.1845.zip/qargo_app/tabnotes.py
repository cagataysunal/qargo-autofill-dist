"""What there is to check, shown inside the order's own Qargo tab: a numbered list in a corner, and the same
number on the field each sentence is about. The operator does not have to go back to the list to read what was
wrong and then find the place again.

    notes(lang, reasons) -> what window.__qaNotes() takes: the sentences of the list, each with the places in
                            Qargo's form where it may belong (the first one that is there gets the mark)

A sentence that names no stop and no field (most of the parser's doubts about a document) is in the list of the
tab without a mark. Like the "Back to the list" button, everything is made only AFTER the bot is done with the
tab, in a closed shadow root: no selector of the bot can match it, and nothing of Qargo's own page is changed.
"""
from . import texts

# the field ids of Qargo's order form, as qargo_fill.py fills them
STOP_ID = {"collect": "consignments[{i}].actual_pickup_stop", "deliver": "consignments[{i}].actual_delivery_stop",
           "start": "setup_input[0]", "end": "teardown_input[0]"}
STOP_FIELD = {"date": ".date", "reference": ".reference_number", "note": ".note", "phone": ".phone_number"}
ORDER_ID = {"customer_reference": "customer_reference_number", "ritnummer": "filtered_custom_fields.ritnummer",
            "instructions": "instructions", "customer": "customer"}
# sentences that do not name their field
CODE_FIELD = {"fill.no_location": "location", "fill.location_ambiguous": "location", "fill.location_check": "location",
              "fill.location_empty": "location", "val.no_postcode": "location", "val.address_guessed": "location",
              "import.check_country": "location", "val.crosses_midnight": "time", "val.delivery_no_time": "time",
              "fill.enforce": "time", "val.date_far": "date", "val.no_ritnummer": "ritnummer",
              "review.rit_several": "ritnummer", "review.no_reference": "customer_reference",
              "fill.duplicate_after_fill": "customer_reference"}
LOCATION = ("location", "query", "name", "street", "country")
# something is not in the form, or is wrong there (red); everything else is "look at this" (amber)
MISSING = {"fill.no_location", "fill.location_empty", "fill.field_skipped", "fill.field_differs", "fill.start_end_stop",
           "fill.empty_trip_on", "fill.enforce", "import.value_dropped", "val.no_ritnummer", "review.rit_several",
           "review.no_reference"}


def anchor(reason):
    """[[element id, part], ...]: where in Qargo's form this sentence belongs, the most exact place first.
    part: "box" (the field itself), "time" / "duration" (that field of the stop the id is in), "weight" (the
    weight next to that quantity), "stop" (the whole stop). [] when the sentence is about the order or its document as a whole."""
    p = reason.get("p") or {}
    stop = p.get("stop") if isinstance(p.get("stop"), dict) else {}
    k, field = stop.get("k"), p.get("field") or CODE_FIELD.get(reason.get("code"))
    try:
        i = max(int(stop.get("n") or 1) - 1, 0)
    except (TypeError, ValueError):
        i = 0
    if k in STOP_ID:
        # one collection for several deliveries: Qargo's form has it once, in the first consignment
        stops = [STOP_ID[k].format(i=i)] + ([STOP_ID[k].format(i=0)] if k == "collect" and i else [])
        out = []
        for s in stops:
            if field in STOP_FIELD:
                out.append([s + STOP_FIELD[field], "box"])
            elif field in ("time", "duration"):
                out.append([s + ".location", field])
            elif field in LOCATION:
                out.append([s + ".location", "box"])
            out.append([s + ".location", "stop"])
        return out
    if k == "goods":
        return [[f"consignments[{i}].goods[0].ordered_quantity", "weight" if field == "weight" else "box"], [f"consignments[{i}].actual_delivery_stop.location", "stop"]]
    if k == "order" and field in ORDER_ID:
        return [[ORDER_ID[field], "box"]]
    return []


def notes(lang, reasons):
    return {"title": texts.text(lang, "notes_h", n=len(reasons)),
            "items": [{"text": texts.reason_text(lang, r), "bad": r.get("code") in MISSING, "at": anchor(r)} for r in reasons]}


NOTES_JS = r"""(() => {
  if (window.top !== window) return;
  const BAD = '#8f1d1d', WARN = '#8a4b00', INK = '#14202b';
  let root = null, panel = null, items = [], open = true, title = '', running = false;
  const el = (tag, css, text) => { const e = document.createElement(tag); e.style.cssText = 'all:initial;' + css;
                                   if (text != null) e.textContent = text; return e; };
  const seen = e => { const r = e && e.getBoundingClientRect(); return r && r.width > 0 && r.height > 0; };
  // the place a sentence is about: the first of its candidates that is in the form now (Qargo redraws its
  // fields, so this is looked up again every time)
  const WEIGHT = 'input[role=spinbutton][id="Total weight (kg)"], input[role=spinbutton][placeholder="100.00"]';
  const find = at => {
    for (const [id, part] of at) {
      const inp = document.getElementById(id);
      if (!inp) continue;
      const fs = inp.closest('fieldset');
      let t = inp.closest('.ant-select') || inp.closest('.ant-picker') || inp;
      if (part === 'stop') t = fs || inp.parentElement;
      else if (part === 'time') t = fs && fs.querySelector('input[placeholder="08:00"]');
      else if (part === 'duration') t = fs && fs.querySelector('[name$=".duration"]');
      else if (part === 'weight') { for (t = inp; t && !t.querySelector(WEIGHT); t = t.parentElement); t = t && t.querySelector(WEIGHT); }
      else if (inp.closest('.ant-select-auto-complete')) {
        // Qargo shows such a field as a textarea / number box NEXT to the id'd one (qargo_fill.py: field_box)
        const ff = inp.closest('.form-field'), box = ff && ff.parentElement;
        t = (box && [...box.querySelectorAll('textarea, input[role=spinbutton]')].find(seen)) || t;
      }
      for (; t && t !== document.body; t = t.parentElement) if (seen(t)) return t;     // the id'd input itself can be hidden
    }
    return null;
  };
  // what of the window a field can be seen in: the form scrolls inside Qargo's page, under its bars
  const clips = new WeakMap();
  const clip = t => {
    if (!clips.has(t)) {
      const boxes = [];
      for (let p = t.parentElement; p && p !== document.documentElement; p = p.parentElement) {
        const s = getComputedStyle(p);
        if (/auto|scroll|hidden|clip/.test(s.overflowX + s.overflowY)) boxes.push(p);
      }
      clips.set(t, boxes);
    }
    const c = {l: 0, t: 0, r: innerWidth, b: innerHeight};
    for (const p of clips.get(t)) { const r = p.getBoundingClientRect();
      c.l = Math.max(c.l, r.left); c.t = Math.max(c.t, r.top); c.r = Math.min(c.r, r.right); c.b = Math.min(c.b, r.bottom); }
    // Qargo's bar with Cancel and Save lies over the end of the form: a mark stops above it
    const tr = t.getBoundingClientRect();
    for (let e = document.elementFromPoint((Math.max(tr.left, c.l) + Math.min(tr.right, c.r)) / 2, c.b - 4); e && e !== document.body; e = e.parentElement) {
      if (e.contains(t)) break;
      if (/fixed|sticky/.test(getComputedStyle(e).position)) { c.b = Math.min(c.b, e.getBoundingClientRect().top); break; }
    }
    return c;
  };
  const badge = (n, bad) => el('span', 'display:inline-block;min-width:26px;height:26px;border-radius:13px;text-align:center;' +
    'font:700 16px/26px system-ui,sans-serif;color:#fff;background:' + (bad ? BAD : WARN) + ';box-sizing:border-box;padding:0 6px', n);
  const draw = () => {
    panel.replaceChildren();
    panel.style.display = items.length ? 'block' : 'none';
    const head = el('div', 'display:flex;gap:10px;align-items:center;cursor:pointer;padding:10px 14px;' +
      'font:700 18px system-ui,sans-serif;color:#fff;background:' + (items.some(i => i.bad) ? BAD : WARN));
    head.append(el('span', 'font:inherit;color:inherit;flex:1', '! ' + title), el('span', 'font:inherit;color:inherit', open ? '▾' : '▴'));
    head.addEventListener('click', () => { open = !open; draw(); });
    panel.append(head);
    if (!open) return;
    const list = el('div', 'display:block;max-height:38vh;overflow:auto');
    items.forEach((it, i) => {
      const row = el('div', 'display:flex;gap:10px;align-items:flex-start;padding:10px 14px;border-top:1px solid #d8d3c8;' +
        (it.at.length ? 'cursor:pointer' : ''));
      row.append(badge(i + 1, it.bad), el('span', 'font:17px/1.4 system-ui,sans-serif;color:' + INK + ';flex:1', it.text));
      if (it.at.length) {
        row.append(el('span', 'font:700 20px system-ui,sans-serif;color:' + (it.bad ? BAD : WARN), '➜'));
        row.addEventListener('click', () => {
          const t = find(it.at);
          if (!t) return;
          t.scrollIntoView({block: 'center'});      // at once: a smooth scroll does not always get there in Qargo's page
          // never under this list: when the field ends up behind it, the form moves on until the field is above it
          const r = t.getBoundingClientRect(), p = panel.getBoundingClientRect(), c = clip(t);
          const up = r.left < p.right && r.bottom > p.top ? Math.min(r.bottom + 16 - p.top, r.top - c.t - 24) : 0;
          const box = clips.get(t).find(b => b.scrollHeight > b.clientHeight + 1) || document.scrollingElement;
          if (up > 0 && box) box.scrollBy(0, up);
          const now = t.getBoundingClientRect();           // the end of the form: it cannot move on, so the list makes room
          if (now.left < p.right && now.bottom > p.top && now.top < p.bottom) { open = false; draw(); }
          it.mark.animate([{boxShadow: '0 0 0 0 rgba(143,29,29,.7)'}, {boxShadow: '0 0 0 18px rgba(143,29,29,0)'}], {duration: 700, iterations: 3});
        });
      }
      list.append(row);
    });
    panel.append(list);
  };
  // the marks follow their fields: the form scrolls, grows and is redrawn under them
  const tick = () => {
    if (!items.length) { running = false; return; }
    const taken = new Map();
    for (const it of items) {
      if (!it.mark) continue;
      const t = find(it.at), r = t && t.getBoundingClientRect(), c = t && clip(t);
      const l = r && Math.max(r.left - 5, c.l), top = r && Math.max(r.top - 5, c.t);
      const w = r && Math.min(r.right + 5, c.r) - l, h = r && Math.min(r.bottom + 5, c.b) - top;
      if (!r || w < 12 || h < 12) { it.mark.style.display = 'none'; if (tipOf === it) hideTip(); continue; }
      const k = taken.get(t) || 0;
      taken.set(t, k + 1);
      it.mark.style.display = 'block';
      it.mark.style.left = l + 'px'; it.mark.style.top = top + 'px'; it.mark.style.width = w + 'px'; it.mark.style.height = h + 'px';
      // the number sits on the top left corner: not shown while that corner is scrolled away
      it.mark.firstChild.style.display = r.top - 5 >= c.t && r.left - 5 >= c.l ? 'inline-block' : 'none';
      it.mark.firstChild.style.left = (-13 + k * 30) + 'px';
    }
    requestAnimationFrame(tick);
  };
  // the sentence itself, next to its field, while the pointer is on the number
  let tip = null, tipOf = null;
  const hideTip = () => { tipOf = null; if (tip) tip.style.display = 'none'; };
  const showTip = (it, b) => {
    const r = b.getBoundingClientRect();
    tipOf = it; tip.textContent = it.text;
    tip.style.borderColor = it.bad ? BAD : WARN; tip.style.display = 'block';
    tip.style.left = Math.max(8, Math.min(r.left, innerWidth - 400)) + 'px';
    tip.style.top = r.top > innerHeight / 2 ? '' : (r.bottom + 6) + 'px';
    tip.style.bottom = r.top > innerHeight / 2 ? (innerHeight - r.top + 6) + 'px' : '';
  };
  window.__qaNotes = (data) => {
    if (!root) {
      const host = document.createElement('div');
      root = host.attachShadow({mode: 'closed'});
      panel = el('div', 'position:fixed;left:16px;bottom:80px;z-index:2147483647;width:400px;max-width:calc(100vw - 32px);' +
        'background:#fff;border:3px solid #fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 14px rgba(0,0,0,.45);box-sizing:border-box');
      tip = el('div', 'position:fixed;display:none;z-index:2147483647;pointer-events:none;width:380px;max-width:calc(100vw - 16px);' +
        'padding:10px 14px;background:#fff;border:3px solid;border-radius:10px;box-shadow:0 2px 14px rgba(0,0,0,.45);box-sizing:border-box;' +
        'font:17px/1.4 system-ui,sans-serif;color:' + INK);
      root.append(panel, tip);
      document.documentElement.appendChild(host);
    }
    for (const it of items) if (it.mark) it.mark.remove();
    hideTip();
    title = data.title;
    items = data.items.map((it, i) => {
      if (!it.at.length) return {...it, mark: null};
      const mark = el('div', 'position:fixed;display:none;z-index:2147483646;pointer-events:none;box-sizing:border-box;border-radius:8px;' +
        'border:3px solid ' + (it.bad ? BAD : WARN));
      const b = badge(i + 1, it.bad), me = {...it, mark};
      b.style.position = 'absolute'; b.style.top = '-15px'; b.style.border = '2px solid #fff';
      b.style.pointerEvents = 'auto'; b.style.cursor = 'help';
      b.addEventListener('mouseenter', () => showTip(me, b));
      b.addEventListener('mouseleave', hideTip);
      mark.append(b);
      root.append(mark);
      return me;
    });
    draw();
    // for the self-test, which cannot look into the closed shadow root: sentences / of them with a place in the form
    document.documentElement.dataset.qaNotes = items.length + '/' + items.filter(it => it.at.length && find(it.at)).length;
    if (items.length && !running) { running = true; requestAnimationFrame(tick); }
  };
})();"""
