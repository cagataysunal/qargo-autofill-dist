#!/usr/bin/env python3
"""One command for the whole day: read the trip PDFs, fill Qargo, check and save.

  python3 run.py                        # new trip PDFs in ~/Downloads -> one Qargo tab per order; you check and Save
  python3 run.py --no-check             # the bot presses Save itself (orders with any warning stay open for you)
  python3 run.py documents/2026-10-10   # (re)run PDFs / folders you name, e.g. a day again
  python3 run.py --parse-only           # only write the orders file, don't open Qargo
  python3 run.py --no-create-locations  # leave addresses Qargo does not have empty (by default they get a new record)
  python3 run.py --only CT-3992179      # --only / --skip / --customer work as in qargo_fill.py
  python3 run.py --change PN-B-009196-0016   # the customer changed this order: edit the one in Qargo

Steps:
 0. housekeeping.py: without paths, the trip PDFs in ~/Downloads move to documents/<today>/ and only those are read.
    Other PDFs of the last 3 days stay in Downloads and are listed as NOT READ.
    Documents folders and run output older than 14 days (--keep-days) go to the Trash.
 1. parse_trips.py reads every PDF it recognises (Cornelissen, Simon Loos, PostNL, Vredeveld, OCT, RD Container Transport); others are listed
    as skipped. A Dick Vijn day hire (Transport_order_D....pdf) makes no order: it is listed with its D-number.
 2. Orders already saved by the bot (done.json) and duplicate PDFs ("x.pdf" and "x (1).pdf") are left out.
    Orders already in Qargo (saved by hand, elsewhere...) are caught by Qargo's own duplicate warning on the
    Customer Reference: the bot then stops that order ("DUPLICATE (Or-...)"), fills nothing, and says whether the
    order in Qargo is what the document says.
    A change (a PostNL Routemutatie, or --change KEY) is never left out: the bot edits the order Qargo has.
 3. The orders go to orders_<date>_<time>.json and are checked by validate_orders.py; orders with errors are not filled.
 4. qargo_fill.py fills them. Without --no-check nothing is saved until you press Save in each tab.
"""
import argparse, datetime, json, subprocess, sys
from dataclasses import dataclass, field
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from parse_trips import parse_paths, print_no_order
from validate_orders import validate, report
from paths import data_dir, documents_dir, done_file, downloads_dir
import housekeeping

def fill_python():
    """the Python for qargo_fill.py: the project's .venv (it has Playwright) when there is one. `python3 run.py`
    starts with the Mac's own Python, which has no Playwright (RD-74582, 21 Oct 2026: ModuleNotFoundError)."""
    for venv in (HERE / ".venv" / "bin" / "python", HERE / ".venv" / "Scripts" / "python.exe"):
        if venv.exists():
            return str(venv)
    return sys.executable

@dataclass
class Plan:
    """what prepare() found; orders is empty when there is nothing to fill"""
    orders: list = field(default_factory=list)      # new orders: not in done.json, each key once
    out: Path = None                                # the orders file (None: no PDFs were read)
    pdf_dirs: list = field(default_factory=list)    # where the source documents are, for qargo_fill.py
    errors: list = field(default_factory=list)      # validator: (key, message); these orders are not filled
    warnings: list = field(default_factory=list)
    skipped: list = field(default_factory=list)     # PDFs that were not read, with the reason
    already: list = field(default_factory=list)     # keys left out because done.json has them
    dupes: list = field(default_factory=list)       # "key (file)" left out: the same order from a second PDF
    moved: list = field(default_factory=list)       # PDFs moved out of Downloads by this call
    unknown: list = field(default_factory=list)     # names of recent PDFs left in Downloads: no layout the parser knows
    no_order: list = field(default_factory=list)    # documents the parser knows that make no order (Dick Vijn day hires)

def shown(path):
    """a folder as the messages name it: from the code folder when it is inside it (documents/2026-10-10)"""
    return path.relative_to(HERE) if path.is_relative_to(HERE) else path

def prepare(paths=(), *, keep_days=housekeeping.KEEP_DAYS, uncouple_as_note=False, change=()):
    """Steps 0-3 of the docstring: tidy, collect or take `paths`, parse, leave out what is done, write the
    orders file, validate - and print what was found. Returns a Plan."""
    paths, moved, unknown = list(paths), [], []
    housekeeping.tidy(keep_days)
    if not paths:
        moved = housekeeping.collect()
        unknown = [p.name for p in housekeeping.left_behind()]
        today = documents_dir() / datetime.date.today().isoformat()
        if not moved:
            print(f"No new trip PDFs in ~/Downloads. To run a day again: python3 run.py {shown(today)}")
            if unknown:
                print(f"!! NOT READ, left in ~/Downloads (not a trip layout the bot knows; if it is a trip, enter it by hand): {unknown}")
            return Plan(unknown=unknown)
        print(f"{len(moved)} trip PDF(s) moved from Downloads to {shown(today)}/")
        paths = [str(p) for p in moved]
    else:
        # a path that is not there from where you stand is looked up in this folder: "documents/2026-10-12" works
        # from anywhere. One that does not exist at all stops the run instead of being "not read".
        found = [p if Path(p).expanduser().exists() else str(HERE / p) for p in paths]
        missing = [p for p, f in zip(paths, found) if not Path(f).expanduser().exists()]
        if missing:
            sys.exit(f"!! not found: {missing} (looked here and in {HERE})")
        paths = found
    no_order = []
    orders, skipped = parse_paths(paths, uncouple_as_note, no_order=no_order)
    done_path = done_file()
    done = json.loads(done_path.read_text(encoding="utf-8-sig")) if done_path.exists() else {}
    keep, seen, already, dupes = [], set(), [], []
    for o in orders:
        if o["key"] in change:          # the planner knows the customer changed this order
            o["change"] = True
        if o["key"] in done and not o.get("change"):
            already.append(o["key"])
        elif o["key"] in seen:
            dupes.append(f"{o['key']} ({o['source']})")
        else:
            seen.add(o["key"]); keep.append(o)

    out = data_dir() / f"orders_{datetime.datetime.now():%Y-%m-%d_%H%M}.json"
    out.write_text(json.dumps(keep, indent=1, ensure_ascii=False), encoding="utf-8")
    pdf_dirs = [Path(p).expanduser() for p in paths if Path(p).expanduser().is_dir()] + \
               [Path(p).expanduser().parent for p in paths if Path(p).expanduser().is_file()] + \
               [documents_dir(), downloads_dir()]
    pdf_dirs = list(dict.fromkeys(pdf_dirs))
    errors, warnings = validate(keep, pdf_dirs)

    print(f"\n{len(keep)} new order(s) -> {out.name}")
    for o in keep:
        n = len(o["consignments"])
        first = (o.get("setup") or o["consignments"][0]["pickup"])
        print(f"  {o['key']:20} {o['customer']:12} {o['customer_reference']:24} {n:2} consignment(s)  "
              f"{first['date']} {first.get('start') or first.get('end') or ''}"
              + ("  CHANGE: edits the order in Qargo" if o.get("change") else ""))
    if already:
        print(f"already in Qargo (done.json), left out: {already}")
    if dupes:
        print(f"duplicate PDFs, left out: {dupes}")
    print_no_order(no_order)
    if skipped:
        print(f"!! NOT READ (unknown layout or unreadable; enter by hand): {skipped}")
    if unknown:
        print(f"!! NOT READ, left in ~/Downloads (not a trip layout the bot knows; if it is a trip, enter it by hand): {unknown}")
    report(errors, warnings)
    bad = sorted({k for k, _ in errors})
    if bad:
        print(f"!! {len(bad)} order(s) have errors and will NOT be filled: {bad}")
    return Plan(keep, out, pdf_dirs, errors, warnings, skipped, already, dupes, moved, unknown, no_order)

def arguments():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("paths", nargs="*",
                    help="PDF files or folders (default: the trip PDFs in ~/Downloads, moved to documents/<today>/)")
    ap.add_argument("--keep-days", type=int, default=housekeeping.KEEP_DAYS,
                    help="move documents and run output older than this many days to the Trash (default 14)")
    ap.add_argument("--no-check", action="store_true",
                    help="let the bot press Save (only for orders without warnings; the rest stay open for you)")
    ap.add_argument("--parse-only", action="store_true", help="write the orders file and stop")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--skip", nargs="*")
    ap.add_argument("--customer")
    ap.add_argument("--create-locations", action=argparse.BooleanOptionalAction, default=True,
                    help="an address Qargo has nothing like gets a new location record; check those orders yourself "
                         "(default; --no-create-locations leaves the stop empty)")
    ap.add_argument("--allow-duplicate", nargs="*", metavar="KEY",
                    help="fill these even though Qargo already has an order with the same customer reference")
    ap.add_argument("--change", nargs="*", default=[], metavar="KEY",
                    help="these orders change one Qargo already has: edit it instead of making a new one "
                         "(a PostNL Routemutatie is a change by itself)")
    ap.add_argument("--uncouple-as-note", action="store_true",
                    help="Cornelissen: put Afkoppelen in the Instructions instead of an end stop")
    return ap

def fill_command(a, plan):
    """the qargo_fill.py command line for these options and this plan"""
    cmd = [fill_python(), str(HERE / "qargo_fill.py"), str(plan.out)]
    for d in plan.pdf_dirs:
        cmd += ["--pdf-dir", str(d)]
    if a.no_check:
        cmd.append("--save")
    if a.only:
        cmd += ["--only", *a.only]
    if a.skip:
        cmd += ["--skip", *a.skip]
    if a.customer:
        cmd += ["--customer", a.customer]
    if a.allow_duplicate:
        cmd += ["--allow-duplicate", *a.allow_duplicate]
    if a.create_locations:
        cmd.append("--create-locations")
    if plan.skipped or plan.unknown:
        cmd += ["--not-read", *map(str, plan.skipped), *plan.unknown]
    return cmd

def main():
    a = arguments().parse_args()
    plan = prepare(a.paths, keep_days=a.keep_days, uncouple_as_note=a.uncouple_as_note, change=a.change)
    if a.parse_only or not plan.orders:
        return
    cmd = fill_command(a, plan)
    print("\n" + ("Filling and saving orders without warnings..." if a.no_check
                  else "Filling Qargo: check each tab and press Save there."))
    sys.exit(subprocess.call(cmd))

if __name__ == "__main__":
    main()
