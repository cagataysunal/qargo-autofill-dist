#!/usr/bin/env python3
"""Fill Qargo "Create order" forms from orders.json (made by parse_trips.py).

Each order is filled in its own browser tab and left open for review. Nothing is
saved unless you pass --save.

  python3 qargo_fill.py orders.json                 # all orders, review + Save yourself
  python3 qargo_fill.py orders.json --only CT-3991420 SL-7173602
  python3 qargo_fill.py orders.json --customer Cornelissen
  python3 qargo_fill.py orders.json --save          # also press Save (after you trust it)

  python3 qargo_fill.py orders.json --change PN-B-009196-0016   # the customer changed this order: edit it in Qargo

First run: a Chromium window opens; log in to Qargo there, then press Enter in the
terminal. The login is kept in ./.qargo-profile for next time.
"""
import argparse, json, os, re, sys, time, datetime, difflib, unicodedata
from pathlib import Path
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout
sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate_orders import validate, find_source
import paths

# QARGO_TENANT_URL is for tests only: it points the bot at a local stand-in instead of Qargo
TENANT_URL = (os.environ.get("QARGO_TENANT_URL") or "https://app.qargo.com/denis-express").rstrip("/")
LOG_LINES = []
# For a program that drives the filling itself (the app's window) instead of main():
LOG_SINK = None     # callable(line): gets every log line after it is printed
STEP_HOOK = None    # callable(ctx, label): called before each step of an order; may raise Cancelled

class Cancelled(BaseException):
    """raised from STEP_HOOK to stop the order being filled. A BaseException on purpose: soft() and the
    per-order `except Exception` must let it through"""

def log(msg):
    line = f"{datetime.datetime.now():%H:%M:%S} {msg}"
    print(line, flush=True)
    LOG_LINES.append(line)
    if LOG_SINK:
        LOG_SINK(line)

def norm(s):
    # accents folded: the document prints "Australiehavenweg", Qargo has "Australiëhavenweg"
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().upper()
    s = re.sub(r"\b(NL|BE|DE)-", "", s)
    s = re.sub(r"\bPROF\b\.?", "PROFESSOR", s)
    return re.sub(r"[^A-Z0-9]", "", s)

# ------------------------------------------------------------------ helpers
def by_id(page, el_id):
    # .first: shared stops (start/end) are rendered once per consignment row with the same id
    return page.locator(f'[id="{el_id}"]').first

def field_box(scope, el_id):
    """the block around a form field (Qargo renders the visible textarea/number input next to the id'd combobox)"""
    return scope.locator(f'[id="{el_id}"]').locator("xpath=ancestor::div[contains(concat(' ', normalize-space(@class), ' '), ' form-field ')][1]/..")

def field_textarea(scope, el_id):
    return field_box(scope, el_id).locator("textarea").first

def fill_field(scope, el_id, value):
    """Fill a Qargo form field. Some fields show a separate textarea / number input next to the
    id'd (hidden-ish) combobox, e.g. Ritnummer -> input#Ritnummer[role=spinbutton]."""
    visible = field_box(scope, el_id).locator("textarea, input[role=spinbutton]")
    target = visible.first if visible.count() else scope.locator(f'[id="{el_id}"]')
    target.fill(str(value), timeout=8000)

def visible_dropdown_options(page):
    return page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option")

def choose_static(page, input_id, text):
    sel = by_id(page, input_id).locator("xpath=ancestor::div[contains(@class,'ant-select')][1]")
    sel.click()
    opt = visible_dropdown_options(page).filter(has_text=re.compile(r"^\s*" + re.escape(text) + r"\s*$"))
    opt.first.click()
    page.wait_for_timeout(250)

def menu_item(page, text):
    item = page.locator(".ant-dropdown:not(.ant-dropdown-hidden) .ant-dropdown-menu-item").filter(
        has_text=re.compile(r"^\s*" + re.escape(text) + r"\s*$"))
    item.first.wait_for(state="visible", timeout=5000)
    item.first.click()
    page.wait_for_timeout(300)

def read_options(page, input_id):
    """[{name, address, recent, idx}] for the location dropdown of input_id"""
    return page.evaluate("""(id) => {
        const lb = document.getElementById(id + '_list');
        if (!lb) return [];
        return [...lb.querySelectorAll('[role=option]')].map((o, idx) => {
            const ell = [...o.querySelectorAll('.ellipsis')].map(e => e.getAttribute('title') || e.textContent);
            return {idx, id: o.id, name: ell[0] || o.textContent, address: ell[1] || '',
                    recent: !!o.querySelector('svg[aria-label=time]'), text: o.textContent};
        });
    }""", input_id)

def hint_tokens(name):
    toks = re.findall(r"[A-Za-z&@]{3,}|\d{3,}", name or "")
    stop = {"ALBERT", "HEIJN", "THE", "NETHERLANDS", "LOGISTICS", "DEPOT", "B.V", "TRANSPORT"}
    return [t.upper() for t in toks if t.upper() not in stop]

# Where Qargo has several records for one address, use this one: the start of its display name
# (only the display name: the record's own name can be renamed, e.g. DCZ's went from "Hoofdtocht 1" to
# the DC name on 9 Oct, which made the old "... (Hoofdtocht 1)" entry miss and pick "AH Winkel 1").
PREFERRED = {
    "5015BZ": "Albert Heijn Distribution Centre Tilburg",          # DCT Pegasusweg 1
    "1507CJ": "Albert Heijn Distributiecentrum Zaandam (DCZ)",     # DCZ and DCM (also "AH Winkel 1" there)
    "1551NC": "RETOURENCENTRUM ZAANDAM",                           # Kleine Steng 10 (also K&N MCZ)
    "3606AS": "Retourencentrum Maarsen Simon Loos",                # Industrieweg 24 (also K&N MCM)
    "2645EG": "Albert Heijn Distributiecentrum Pijnacker (DCP)",   # Laan van Ruyven 1 (renamed from "AH Winkel 75")
}
# Same, by the name on the document, whatever postcode it carries: a Cornelissen coupling place has no
# postcode and borrows one from a stop on the same street, e.g. "DCP Laan van Ruyven 1" got K&N MCP's 2645EE.
PREFERRED_BY_NAME = [
    (re.compile(r"^(DCP\b|Albert Heijn DC (Delfgauw|Pijnacker)\b)", re.I), "Albert Heijn Distributiecentrum Pijnacker (DCP)"),
]

def country_of(address):
    m = re.search(r"\b([A-Z]{2})-", address or "")
    return m.group(1) if m else None

def wait_options(page, input_id, timeout=6.0):
    """the dropdown's options, once they stop changing (or timeout). Called when Qargo's answer is in (SearchAnswer):
    the list is drawn from it a moment later, so 0.2 s unchanged is enough, and 0.5 s of "no results" is Qargo's
    answer. (Before the answer was waited for, 1 s and 2 s of polling stood in for it: 21 Oct, ~1 s per stop.)"""
    deadline, last, same = time.time() + timeout, None, 0
    opts = []
    while time.time() < deadline:
        page.wait_for_timeout(100)
        opts = read_options(page, input_id)
        sig = tuple(o["id"] + o["name"] for o in opts)
        same = same + 1 if sig == last else 0
        last = sig
        if opts and same >= 2:
            break
        if not opts and same >= 5:
            break
    return opts

class NoAnswer(Exception):
    """Qargo did not answer a search (slow or broken internet): an empty list then says nothing about Qargo"""

class SearchAnswer:
    """Listens for Qargo's answer to the location search for `text`. While the question is on its way the list
    already reads "No results found" (no spinner), so an empty list only counts once the answer is in. Measured
    20 Oct on the live form: the answer takes 1.4 s, with 2 s of network delay 4.2 s, and wait_options gives up
    on an empty list after 2 s: Pegasusweg 1 (DCT) then came out NO LOCATION and went into missing_locations.json."""
    OP = "LocationMasterDataSelectFieldQuery"
    STEP = None         # a question Qargo asks first, before the one whose answer fills the list

    def __init__(self, page, text):
        self.page, self.text, self.sent, self.answers, self.failed, self.asked = page, text.strip(), 0, [], 0, False
        self.read = 0           # answers whose body is in too ("response" comes with the headers)
        self._ev = (("request", self._request), ("response", self._response), ("requestfinished", self._finished),
                    ("requestfailed", self._failed))
        for ev, fn in self._ev:
            page.on(ev, fn)

    def _mine(self, req):
        """"answer" (the question whose answer fills the list), "step" (the one Qargo asks before it) or None"""
        if req.method != "POST" or "graphql" not in req.url:
            return None
        try:
            body = req.post_data_json
            if body["operationName"] == self.OP and self._asks(body["variables"]):
                return "answer"
            if self.STEP and body["operationName"] == self.STEP and self._asks_step(body["variables"]):
                return "step"
        except Exception:
            pass
        return None

    def _asks(self, variables):
        """is this the question for self.text?"""
        return variables["args"]["search_string"].strip() == self.text

    def _asks_step(self, variables):
        return f"%{self.text}%" in json.dumps(variables, ensure_ascii=False)

    def _request(self, req):
        if self._mine(req):
            self.sent += 1
            self.asked = True

    def _response(self, resp):
        kind = self._mine(resp.request)
        if kind == "answer" and resp.ok:
            self.answers.append(resp)
        elif kind == "step" and resp.ok:
            self.sent -= 1                  # answered: Qargo asks the question of the list now
        elif kind:
            self.failed += 1

    def _finished(self, req):
        self.read += self._mine(req) == "answer"

    def _failed(self, req):
        self.failed += bool(self._mine(req))

    def wait(self, answer_s=20.0, cached_s=None):
        """until Qargo has answered. cached_s: True already when nothing was asked within that time (a search
        Qargo knows is not asked again: the list is already right). Raises NoAnswer when every question failed or
        no answer came within answer_s"""
        t0 = time.time()
        while not (self.answers and self.read):
            if cached_s is not None and not self.asked and time.time() - t0 >= cached_s:
                return
            if self.sent and self.failed >= self.sent:
                raise NoAnswer(f"Qargo's search for {self.text!r} failed")
            if time.time() - t0 >= answer_s:
                raise NoAnswer(f"no answer from Qargo to the search for {self.text!r} within {answer_s:.0f} s")
            self.page.wait_for_timeout(50)

    def close(self):
        for ev, fn in self._ev:
            self.page.remove_listener(ev, fn)

class StopActionAnswer(SearchAnswer):
    """Qargo's answer to the Stop action list of an extra stop: its internal stop actions of type Other / Cleaning
    whose name holds the typed text (live form, 20 Oct 2026: {"name": {"_ilike": "%Gas%"}})"""
    OP = "StopTypeMasterDataSelectFieldQuery"

    def _asks(self, variables):
        return variables["where"]["_and"][0]["name"]["_ilike"].strip("%").strip() == self.text

class ExtraStopLocationAnswer(SearchAnswer):
    """the Location field of an extra stop ("Add stop") asks in two steps (live form, 20 Oct 2026): the locations
    of Qargo's stop types ({"name": {"_ilike": "%text%"}} ...), and only after that answer all other locations
    (search_string). With 2 s of network delay the list is in after 4.5 s; offline only the first is asked"""
    OP = "StopTypeLocationMasterDataSelectFieldOtherLocationsQuery"
    STEP = "StopTypeLocationMasterDataSelectFieldLocationsOfStopTypeQuery"

# What Qargo asks its server after a choice in the form, to fill in what it knows (live form, 21 Oct 2026). After the
# customer: PrefillQuery, and for a customer with a default collect location (Simon Loos -> DCZ, set 21 Oct) that
# location and the stop's prefill, then PrefillQuery once more: 0.5 s, 1.2 s on a fresh form. A choice the bot makes
# before the last answer is undone: "Multiple collections and deliveries" went back to "None", the four added
# consignments with it. After a stop's location: PrefillQuery and the stop's prefill at once, answered in 0.2-0.3 s.
CUSTOMER_PREFILL = ("PrefillQuery", "PickupDeliveryFieldsetPrefillQuery", "LocationMasterDataSelectFieldEnrichedQuery")
STOP_PREFILL = ("PrefillQuery", "PickupDeliveryFieldsetPrefillQuery")

class QargoAnswers:
    """Listens for Qargo's answers to the questions it asks after a choice (ops: their operation names). Made before
    the click; wait() returns once every question is answered and no new one came for quiet_s (each answer can bring
    the next question, ~0.03 s later). Only questions seen going out count: on a slow line the PrefillQuery Qargo
    asks while the customer's name is typed is still on its way at the click, and Qargo then cancels it (21 Oct,
    2 s network delay: taken for a failed answer, the order was stopped)"""
    def __init__(self, page, ops):
        self.page, self.ops, self.done, self.failed, self.last = page, ops, 0, 0, time.time()
        self.asked = set()          # the operation names Qargo asked
        self.open = set()           # questions on their way
        self._ev = (("request", self._request), ("requestfinished", self._done), ("requestfailed", self._failed))
        for ev, fn in self._ev:
            page.on(ev, fn)

    def _mine(self, req):
        """the question's operation name when it is one of ours, else None"""
        if req.method != "POST" or "graphql" not in req.url:
            return None
        try:
            op = req.post_data_json["operationName"]
            return op if op in self.ops else None
        except Exception:
            return None

    def _request(self, req):
        op = self._mine(req)
        if op:
            self.last = time.time()
            self.asked.add(op)
            self.open.add(req)

    def _done(self, req):
        if req in self.open:
            self.open.discard(req)
            self.done, self.last = self.done + 1, time.time()

    def _failed(self, req):
        if req in self.open:
            self.open.discard(req)
            self.last = time.time()
            # net::ERR_ABORTED: Qargo took the question back itself (a newer one replaces it): no failed answer
            self.failed += "ERR_ABORTED" not in str(getattr(req, "failure", "") or "")

    def wait(self, what, ask_s=2.0, quiet_s=0.3, answer_s=30.0, busy=None):
        """True once answered, False when Qargo asked nothing within ask_s. busy(): what the page itself shows while
        Qargo is still at it; not done before that is over too. Raises NoAnswer when every question failed or not
        all were answered within answer_s (slow or broken internet)"""
        t0 = time.time()
        try:
            while True:
                now = time.time()
                answered = self.asked and not self.open and now - self.last >= quiet_s
                if (answered or not self.asked and now - t0 >= ask_s) and not (busy and busy()):
                    if self.failed and not self.done:
                        raise NoAnswer(f"Qargo's answer to {what} failed (internet?)")
                    return bool(self.asked)
                if now - t0 >= answer_s:
                    raise NoAnswer(f"no answer from Qargo to {what} within {answer_s:.0f} s (internet?)")
                self.page.wait_for_timeout(25)
        finally:
            for ev, fn in self._ev:
                self.page.remove_listener(ev, fn)

def select_box(page, input_id):
    return by_id(page, input_id).locator("xpath=ancestor::div[contains(concat(' ', @class, ' '), ' ant-select ')][1]")

def clear_choice(page, input_id):
    """empty a location field Qargo filled in by itself (a customer's default) or an Edit order form holds: its
    chosen place covers the search box (the click waited 8 s and the stop was skipped), and a search that finds
    nothing must leave the field empty, not with that place in it. Raises when it stays"""
    have = selected_location(page, input_id)
    box = select_box(page, input_id)
    follow = QargoAnswers(page, STOP_PREFILL)
    box.scroll_into_view_if_needed(timeout=5000)
    box.hover()
    box.locator(".ant-select-clear").first.click(timeout=5000)
    try:
        follow.wait(f"emptying {input_id}", ask_s=0.5, quiet_s=0.1)
    except NoAnswer:
        pass                                    # the field is what counts, read below
    if selected_location(page, input_id):
        raise RuntimeError(f"Qargo's own choice {have!r} in {input_id} could not be cleared")

def search_location(page, inp, input_id, text, tries=2):
    """type `text` into the location field and return the options Qargo lists for it. Raises NoAnswer when
    Qargo did not answer, also not after typing it once more (a late answer to the first question counts too)"""
    answer = (ExtraStopLocationAnswer if ".standalone_stops[" in input_id else SearchAnswer)(page, text)
    try:
        for attempt in range(1, tries + 1):
            inp.click()
            inp.fill("")
            inp.press_sequentially(text, delay=10)
            try:
                answer.wait(cached_s=2.5 if attempt == 1 else None)
                break
            except NoAnswer:
                if attempt == tries:
                    raise
                answer.sent = answer.failed = 0          # the next question is the one to wait for
                page.wait_for_timeout(2000)
    finally:
        answer.close()
    return wait_options(page, input_id)

def street_parts(s):
    """street name and house number, comparable across spellings:
    "'t Spil 37" / "Het Spil 37" -> ("het spil", "37"); "Burg. D. Kooimanweg 16, NL-..." -> ("burgemeester kooimanweg", "16")"""
    s = unicodedata.normalize("NFKD", (s or "").replace("ß", "ss")).encode("ascii", "ignore").decode().lower().split(",")[0]
    m = re.search(r"\d+", s)
    s = re.sub(r"^\s*\d+\w*\s+(?=[a-z])", "", s)              # the number written first: "269 Chaussee de Tongres"
    s = re.sub(r"(^|\s)'t\s", r"\1het ", " " + s)
    s = re.sub(r"\bburg\b\.?", "burgemeester", s)
    s = re.sub(r"\bprof\b\.?", "professor", s)               # 558010: "Prof. ..." on the PDF, "Professor ..." in Qargo
    s = re.sub(r"\b[a-z]\.\s*", " ", s)                       # initials: "D."
    name = re.sub(r"[^a-z]+", " ", re.sub(r"\d.*$", "", s))     # the name: everything before the number
    return re.sub(r"\s+", " ", name).strip(), (m.group(0) if m else None)

def street_similarity(a, b):
    a, b = a.replace(" ", ""), b.replace(" ", "")
    return difflib.SequenceMatcher(None, a, b).ratio() if a and b else 0.0

def one_letter_apart(a, b):
    """b is a with one letter dropped or doubled ("minckelerstraat" / "minckelersstraat"): a typo, not another street.
    A substitution ("beukenlaan" / "berkenlaan") is not: those are two places."""
    if abs(len(a) - len(b)) != 1:
        return False
    longer, shorter = (a, b) if len(a) > len(b) else (b, a)
    return any(longer[:i] + longer[i + 1:] == shorter for i in range(len(longer)))

def same_street_and_number(doc, qargo):
    """the same address line once case, accents, spaces, punctuation and the abbreviations above are set aside.
    Nothing looser: "Beukenlaan 5" and "Berkenlaan 5" are 90% alike and two places, and so are numbers 90 and 95."""
    (d_name, d_nr), (q_name, q_nr) = street_parts(doc), street_parts(qargo)
    return bool(d_name) and d_name.replace(" ", "") == q_name.replace(" ", "") and d_nr == q_nr

def postcode_gap(pc, address):
    """how a record on the document's street and number differs in postcode: "none" (the record has no postcode),
    "letters" (Dutch 1234 AB: same digits, other letters - the same few streets) or "other" (another postcode)"""
    tail = re.sub(r"^.*,", "", address or "")
    digits = re.findall(r"\d+", tail)
    if not digits:
        return "none"
    if re.fullmatch(r"\d{4}[A-Z]{2}", pc) and country_of(address) in (None, "NL") and digits[0] == pc[:4]:
        return "letters"
    return "other"

def own_record(loc):
    """the exact name of the Qargo record this place has (PREFERRED, PREFERRED_BY_NAME, location_overrides.json),
    or None"""
    overrides_file = paths.overrides_file()      # optional {"<query>|<postcode>": "<exact Qargo name>"}
    overrides = json.loads(overrides_file.read_text(encoding="utf-8-sig")) if overrides_file.exists() else {}
    by_name = next((n for rx, n in PREFERRED_BY_NAME if rx.search(loc.get("name") or "")), None)
    return overrides.get(f"{loc['query']}|{loc.get('postcode')}") or by_name or PREFERRED.get(norm(loc.get("postcode")))

def pick_candidates(opts, loc):
    """return (candidates, note) for one result list; note = None or (level, text): level "check" is a warning
    (a person must look; --save won't save), "note" only goes in the log (same place, written differently)"""
    pc = norm(loc.get("postcode"))
    street_n = norm(loc.get("street"))
    store = loc.get("store")
    want_name = own_record(loc)
    # never use a fuel station or a record in another country
    usable = [o for o in opts
              if ("SHELL" not in o["name"].upper() or "SHELL" in (loc.get("name") or "").upper())
              and (country_of(o["address"]) in (None, loc.get("country", "NL")))]
    if want_name:
        c = [o for o in usable if o["name"].strip().startswith(want_name)]
        if c:
            return c, None
        # not in these results: try the next search, and in the end say NO LOCATION. Never pick another
        # record for a place that has its own (renamed? deleted?) - that is how "AH Winkel 1" got picked.
        return [], None
    if store:
        mine = [o for o in usable if re.search(rf"\b(Winkel|Albert Heijn|AH)\s+{store}\b", o["name"], re.I)]
        same_street = [o for o in mine if street_n and street_n in norm(o["address"])]
        if same_street:
            return same_street, None
        if mine:
            # no exact match: the record on the most similar street ("Het Spil 37" = "'t Spil 37"), not simply
            # the unloading-address record (SL-7176261 got "AH Winkel 2261 unloading adress" / Lijnbaan that way)
            doc_name, doc_nr = street_parts(loc.get("street"))
            scored = sorted(mine, key=lambda o: street_similarity(doc_name, street_parts(o["address"])[0]), reverse=True)
            best = scored[0]
            q_name, q_nr = street_parts(best["address"])
            if street_similarity(doc_name, q_name) >= 0.8:
                if doc_nr and q_nr and doc_nr != q_nr:
                    return [best], ("check", f"store {store}: house number differs: document '{loc.get('street')}', "
                                             f"Qargo '{best['address']}'")
                what = "Qargo record has no house number" if doc_nr and not q_nr else "street written differently"
                return [best], ("note", f"store {store}: {what}: document '{loc.get('street')}', Qargo '{best['address']}'")
            unloading = [o for o in mine if "unloading" in o["name"].lower()]
            c = unloading or mine
            return c, ("check", f"store {store}: document street '{loc.get('street')}', Qargo '{c[0]['address']}'")
    if pc:
        c = [o for o in usable if pc in norm(o["address"]) or pc in norm(o["name"])]
        if c:
            # the postcode alone is never proof: many places share one, in any country, so only a record on the
            # document's street and house number is picked. Anything else is another place: leave the field
            # empty for a person, never "close enough".
            #   VRD-220670 'GAMMA Gouda, Elburgplein 7, 2803PX' got 'GAMMA Elburg / Westerlengte 2, NL-2803 PX Gouda'
            #   Or-0000126 'Chaussée De Tongres 269, 4000' got 'Action / Rue Joseph Demoulin 15, BE-4000 Liège'
            #   Or-0000126 'Route de Herbesthal 95, 4700' got 'Rue de Herbesthal 90, BE-4700 Baelen'
            good = [o for o in c if same_street_and_number(loc.get("street"), o["address"])]
            if good:
                return good, None
            # ACT-5381522ORS: the answer read 'J.P. Minckelerstraat 136', Qargo has 'J.P. Minckelersstraat 136' on the
            # same postcode and number: one letter dropped is a typo (on the document or in the reading), so it is
            # the place. Only a dropped or doubled letter: 'Beukenlaan' / 'Berkenlaan' stay two streets.
            d_name, d_nr = street_parts(loc.get("street"))
            near = [o for o in c if d_name and d_nr and street_parts(o["address"])[1] == d_nr
                    and one_letter_apart(d_name.replace(" ", ""), street_parts(o["address"])[0].replace(" ", ""))]
            if near:
                return near, ("note", f"street written with one letter more or less: document '{loc.get('street')}', "
                                      f"Qargo '{near[0]['address']}'")
    # the document's street and number, but not its postcode. The same street and number exist in many towns
    # (VRD-220697 'GAMMA Epe, De Meent 19, 8161ZN Epe' got 'AH Winkel 8778 / De Meent 19, NL-1218 CB Hilversumse
    # Meent'), so the town has to be the document's, unless only the letters of a Dutch postcode differ.
    # The number has to be the document's ("De Meent 19" is inside "De Meent 190") and the town a whole word
    # ("Epe" is inside "Diepenveen").
    doc_nr = street_parts(loc.get("street"))[1]
    same_nr = lambda o: not doc_nr or street_parts(o["address"])[1] in (None, doc_nr)
    c = [o for o in usable if street_n and street_n in norm(o["address"] + o["name"]) and same_nr(o)]
    city = norm(loc.get("city"))
    towns = lambda o: {norm(w) for w in re.split(r"[^\w'-]+", re.sub(r"^.*,", "", o["address"]))} | \
                      {norm(re.sub(r"^\s*[A-Z]{2}(-\S+(\s[A-Z]{2})?)?\s+", "", re.sub(r"^.*,", "", o["address"])))}
    in_town = [o for o in c if city and city in towns(o)]
    if not pc:
        return in_town, None
    gap = lambda o: postcode_gap(pc, o["address"])
    same = [o for o in c if gap(o) == "letters"] + [o for o in in_town if gap(o) == "none"]
    doubt = same or [o for o in in_town if gap(o) == "other"]
    if doubt:
        text = f"postcode differs for '{loc['street']}': document {loc.get('postcode')}, Qargo '{doubt[0]['address']}'"
        return doubt, ("note" if same else "check", text)
    return [], None

def missing_key(loc):
    return "|".join((norm(loc.get("street")) or norm(loc.get("name")), norm(loc.get("postcode")), loc.get("country", "NL")))

def load_missing():
    """places an earlier order did not find in Qargo: {key: {name, since, order}} (missing_locations.json)"""
    f = paths.missing_locations_file()
    try:
        return json.loads(f.read_text(encoding="utf-8-sig")) if f.exists() else {}
    except ValueError:
        return {}

def remember_missing(loc, ctx, missing):
    """missing=True: Qargo has no record for this place; False: it has one now"""
    known, key = load_missing(), missing_key(loc)
    if missing == (key in known):
        return
    if missing:
        known[key] = {"name": loc.get("name"), "since": time.strftime("%Y-%m-%d"), "order": ctx.get("order")}
    else:
        del known[key]
    paths.missing_locations_file().write_text(json.dumps(known, indent=1, ensure_ascii=False), encoding="utf-8")

def pick(page, option_id):
    """click a location option (through JS: the list can open above the field, outside the visible area) and wait
    for what Qargo then asks about the stop, so a date or time typed next is not undone by its answer. The place is
    in the field at once; without an answer the bot goes on, as it did after its fixed 0.3 s"""
    follow = QargoAnswers(page, STOP_PREFILL)
    page.evaluate("id => document.getElementById(id).click()", option_id)
    try:
        follow.wait("the chosen location", ask_s=0.5, quiet_s=0.05, answer_s=10.0)
    except NoAnswer:
        pass

def choose_location(page, inp, input_id, loc, ctx):
    """Search a Qargo location and pick the matching record. Tries the store number, then the
    street, then the name. Returns what was chosen, or None."""
    queries = [loc["query"]]
    mq = re.match(r"^(.*?\d+)", loc.get("street") or "")
    street_q = mq.group(1) if mq else loc.get("street")
    street_q = re.sub(r"\bProf\.?(?=\s)", "Professor", street_q or "") or street_q   # Qargo spells it out
    # last: the name without store numbers ("ACTION 2014 Temse" -> "ACTION Temse"; Qargo has "Action Temse").
    # Still only picked on a postcode / street match, so a name search can't pick another place.
    bare = "" if loc.get("store") else re.sub(r"\s+", " ", re.sub(r"\b\d+\b", " ", loc.get("name") or "")).strip()
    # very last: the postcode, written as Qargo indexes it ("1046 BP"). The street search misses a record whose
    # street is spelt differently (PN-B-008663-0085: "Australiehavenweg 100" vs Qargo's "Australiëhavenweg 100").
    pc = norm(loc.get("postcode"))
    pc_q = f"{pc[:4]} {pc[4:]}" if re.fullmatch(r"\d{4}[A-Z]{2}", pc) else pc
    for q in (street_q, loc.get("name"), bare, pc_q):
        if q and q not in queries:
            queries.append(q)
    # an earlier order already found out that Qargo has no record here: one search (somebody may have made the
    # record since), not all of them again
    known = load_missing().get(missing_key(loc))
    if known:
        queries = [pc_q or queries[0]]
    if selected_location(page, input_id):           # a place already in the field: never left there by a failed search
        clear_choice(page, input_id)
    seen, doubts, tried, unanswered = [], [], [], []
    for q in queries:
        if q in tried:
            continue
        tried.append(q)
        try:
            opts = search_location(page, inp, input_id, q)
        except NoAnswer as e:
            # an unanswered search says nothing about Qargo: never "missing", never a new record for it
            unanswered.append(str(e))
            continue
        if q == street_q and not opts:
            # nothing at all on the street: the name searches will not find the place either. Only the postcode
            # is still worth a search (the accent case above)
            queries[:] = [x for x in queries if x == pc_q or x in tried]
        seen += [o["name"] + " / " + o["address"] for o in opts][:4]
        cands, note = pick_candidates(opts, loc)
        if not cands:
            continue
        if note and note[0] == "check":
            # any doubt (another house number, street or postcode): never fill it. A wrong place in the field
            # gets saved by someone who misses a one-digit difference; an empty field cannot be.
            doubts.append(note[1])
            continue
        if note:
            ctx.setdefault("notes", []).append(note[1])
        hints = hint_tokens(loc.get("name"))
        def score(o):
            t = norm(o["name"] + " " + o["address"])
            return (sum(1 for h in hints if norm(h) in t), o["recent"])
        cands.sort(key=score, reverse=True)
        best = cands[0]
        if len(cands) > 1 and score(cands[0]) == score(cands[1]) and cands[0]["name"] != cands[1]["name"]:
            # several records fit equally: which one is a person's choice, not a guess to be saved unread
            doubts.append(f"several records fit '{q}': {[c['name'] for c in cands[:4]]}")
            continue
        pick(page, best["id"])
        remember_missing(loc, ctx, False)
        return f"{best['name']} / {best['address']}"
    if unanswered:
        # the internet, not Qargo: the place may well be there. Leave the stop empty for a person, and keep
        # missing_locations.json and Qargo's records as they are
        ctx["warnings"].append(f"NO ANSWER FROM QARGO for {loc.get('name')!r} ({loc.get('street')}, {loc.get('postcode')} "
                               f"{loc.get('city')}): {unanswered[0]} (internet?); location left empty, pick it by hand"
                               + f"; tried {tried}; seen: {seen[:6]}"
                               + (f"; not filled: {list(dict.fromkeys(doubts))}" if doubts else ""))
        inp.fill("")
        page.keyboard.press("Escape")
        return None
    own = own_record(loc)
    if own:
        # the place has its own record and the search did not show it (renamed? deleted?): a person looks
        doubts.append(f"Qargo's own record for this place, {own!r}, is not in the search results")
    # a new record only where Qargo has nothing that may be this place. A record that may be it (the same store on
    # another house number, the same street and number in the same town on another postcode, several that fit,
    # its own record) is a person's call: a second record for one building would split it in two
    if not doubts and can_create(loc, ctx):
        made = create_location(page, inp, input_id, loc, ctx)
        if made:
            remember_missing(loc, ctx, False)
            return made
    if not doubts:                                   # a record that is only doubted is not a missing one
        remember_missing(loc, ctx, True)
    ctx["warnings"].append(f"NO LOCATION for {loc.get('name')!r} ({loc.get('street')}, {loc.get('postcode')} "
                           f"{loc.get('city')}); tried {tried}; seen: {seen[:6]}"
                           + (f"; not filled: {list(dict.fromkeys(doubts))}" if doubts else "")
                           + (f"; already missing on {known['since']} ({known['order']}), searched once" if known else ""))
    inp.fill("")
    page.keyboard.press("Escape")
    return None

# ---- --create-locations: an address Qargo does not have gets a new location record ("Add location manually")
COUNTRY_NAMES = {"NL": "Netherlands", "BE": "Belgium", "DE": "Germany"}
CREATED = {}        # (street, postcode) -> name, for this run: never create the same address twice
DRAWER_READ_JS = """d => { const g = id => { const e = d.querySelector('[id="' + id + '"]'); return e ? e.value : '' };
    const c = d.querySelector('[id="country"]'), b = c && c.closest('.ant-select'), i = b && b.querySelector('.ant-select-selection-item');
    return {name: g('name'), address: g('address'), postcode: g('postal_code'), city: g('city'),
            country: i ? i.textContent.trim() : '', lat: g('latitude'), lon: g('longitude')} }"""

def can_create(loc, ctx):
    """only a full, printed address: never a guessed one-line address, or an address without postcode or house
    number. An AH store is made too (SL-7182377: Albert Heijn 1165 and 1238 were missing), named as Qargo names
    its stores (record_name)"""
    return bool(ctx.get("create_locations") and not loc.get("unverified")
                and loc.get("postcode") and loc.get("city") and street_parts(loc.get("street"))[1]
                and loc.get("country", "NL") in COUNTRY_NAMES)

def record_name(loc):
    """the name a new record gets: the document's, but "AH Winkel <nr>" for an AH store, so the next order's
    "Winkel <nr>" search finds it like Qargo's other store records"""
    return f"AH Winkel {loc['store']}" if loc.get("store") else loc["name"]

def selected_location(page, input_id):
    return page.evaluate("""id => { const i = document.getElementById(id), s = i && i.closest('.ant-select'),
        x = s && s.querySelector('.ant-select-selection-item'); return x ? (x.getAttribute('title') || x.textContent || '').trim() : '' }""", input_id)

def drawer_address(loc):
    """what goes in the dialog's address fields: the document's street (without what follows a comma), the
    postcode as Qargo writes it ("1462 VT") and the city"""
    pc = norm(loc["postcode"])
    pc = f"{pc[:4]} {pc[4:]}" if re.fullmatch(r"\d{4}[A-Z]{2}", pc) else loc["postcode"].strip()
    return {"address": loc["street"].split(",")[0].strip(), "postal_code": pc, "city": loc["city"].strip()}

def same_address(loc, got):
    """does the dialog still hold the document's address? street name, house number, postcode and country"""
    return (same_street_and_number(loc.get("street"), got["address"]) and norm(got["postcode"]) == norm(loc["postcode"])
            and got["country"] == COUNTRY_NAMES[loc.get("country", "NL")])

def drawer_coordinates(page, drawer, timeout=8.0):
    """Qargo looks the coordinates up itself once the address is filled in and the cursor leaves it (16 Oct: within
    0.3 s). While typing it already shows a guess for half an address, so wait until they stop changing"""
    deadline, last, same, got = time.time() + timeout, None, 0, {}
    while time.time() < deadline:
        page.wait_for_timeout(300)
        got = drawer.evaluate(DRAWER_READ_JS)
        now = (got["lat"], got["lon"])
        same = same + 1 if now == last and all(now) else 0
        last = now
        if same >= 3:
            break
    return got

def cancel_drawer(page, drawer):
    """Cancel the "Add location manually" dialog and wait until it has slid away (it covers the form meanwhile)"""
    try:
        if drawer.count() and drawer.is_visible():
            page.keyboard.press("Escape")            # the Google result list
            drawer.locator('button:has-text("Cancel")').last.click(timeout=5000)
        drawer.wait_for(state="hidden", timeout=8000)
    except Exception:
        pass
    page.wait_for_timeout(800)

def create_location(page, inp, input_id, loc, ctx):
    """Qargo has no record at this address: make one. The document's address goes straight into the dialog's
    address fields (not through its Google search, which saved nothing it could not match exactly) and Qargo looks
    the coordinates up itself; without coordinates nothing is saved. Returns what was created, or None (then the
    caller reports NO LOCATION)."""
    key = (norm(loc["street"]), norm(loc["postcode"]))
    label = f"{loc['name']!r} ({loc['street']}, {loc['postcode']} {loc['city']})"
    if key in CREATED:
        ctx["warnings"].append(f"location {label} was created earlier in this run as {CREATED[key]!r} but the search "
                               f"does not show it yet: pick it by hand")
        return None
    drawer = page.locator(".ant-drawer-open").filter(has_text="Add location manually").last
    try:
        for attempt in (1, 2):                       # the "Create new location" line comes with the search result
            try:
                if attempt == 2:                     # the first time the caller's last search is still open
                    page.keyboard.press("Escape")
                    search_location(page, inp, input_id, loc["query"])
                page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden)").get_by_text(
                    "Create new location").first.click(timeout=5000)
                drawer.wait_for(state="visible", timeout=8000)
                break
            except PWTimeout:
                if attempt == 2:
                    raise
        page.wait_for_timeout(1000)                  # the dialog slides in
        country = COUNTRY_NAMES[loc.get("country", "NL")]
        c = drawer.locator('[id="country"]')         # empty in a new dialog
        c.click(); c.press_sequentially(country, delay=15)
        page.locator(".ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option").filter(
            has_text=re.compile(r"^\s*" + re.escape(country) + r"\s*$")).first.click(timeout=5000)
        for field, value in drawer_address(loc).items():
            drawer.locator(f'[id="{field}"]').fill(value, timeout=5000)
        drawer.locator('[id="name"]').fill(record_name(loc), timeout=5000)
        drawer.locator(".ant-drawer-title").first.click()   # out of the fields: Qargo looks up the coordinates
        got = drawer_coordinates(page, drawer)
        if not (got.get("lat") and got.get("lon")) or not same_address(loc, got):
            why = (f"the dialog holds {got.get('address')}, {got.get('postcode')} {got.get('city')}, {got.get('country')}"
                   if got.get("lat") and got.get("lon") else "Qargo found no coordinates for the address")
            cancel_drawer(page, drawer)
            ctx["warnings"].append(f"location {label} NOT created: {why}. Create it by hand")
            return None
        drawer.locator('button:has-text("Save")').last.click(timeout=5000)
        drawer.wait_for(state="hidden", timeout=15000)
        page.wait_for_timeout(800)
    except Exception as e:
        cancel_drawer(page, drawer)
        ctx["warnings"].append(f"location {label} NOT created ({type(e).__name__}: {str(e).splitlines()[0][:120]}). "
                               f"Create it by hand")
        return None
    CREATED[key] = record_name(loc)
    made = f"{record_name(loc)} / {got['address']}, {got['postcode']} {got['city']}"
    ctx["warnings"].append(f"CREATED location {made} ({got['lat']}, {got['lon']}) - new in Qargo, check it")
    page.wait_for_timeout(1500)
    if not selected_location(page, input_id):        # Qargo did not put the new record in the stop: pick it
        for _ in range(3):
            try:
                cands, _note = pick_candidates(search_location(page, inp, input_id, loc["query"]), loc)
            except NoAnswer:
                cands = []
            if cands:
                pick(page, cands[0]["id"])
                break
            page.wait_for_timeout(2000)
    return f"CREATED {made}"

SWITCH_LABELS_JS = """fs => [...fs.querySelectorAll('button[role=switch]')].map(sw => {
    // name each switch after the nearest label around it: 'enforce', 'empty' (Empty trip) or '?'
    let n = sw;
    for (let i = 0; i < 6 && n.parentElement; i++) {
        n = n.parentElement;
        const t = n.textContent || '';
        const enf = /Enforce/.test(t), emp = /Empty trip/i.test(t);
        if (enf && !emp) return 'enforce';
        if (emp && !enf) return 'empty';
        if (enf && emp) return '?';
    }
    return '?';
})"""

def switch(fs, name):
    """the switch in this stop card labelled `name` ('enforce' / 'empty'), or None"""
    names = fs.evaluate(SWITCH_LABELS_JS)
    return fs.locator("button[role=switch]").nth(names.index(name)) if name in names else None

TIME_IDS_JS = """fs => [...fs.querySelectorAll('input[placeholder="08:00"]')].map(i => i.id)"""

def redrawn(fs, wait_s=1.5):
    """until Qargo has redrawn the stop's time fields after its start time: their ids are the stop's own then, no
    longer __invalid_timewindow_time_* (live form, 21 Oct 2026: ~0.1 s after the Tab)"""
    deadline = time.time() + wait_s
    while time.time() < deadline and any(i.startswith("__invalid_timewindow") for i in fs.evaluate(TIME_IDS_JS)):
        fs.page.wait_for_timeout(25)

def times_kept(tins, want, hold_s=0.4):
    """have the time fields held their values for hold_s? want: [(index, value)]; False as soon as one changed"""
    since = time.time()
    while True:
        tins.page.wait_for_timeout(100)
        if any(tins.nth(i).input_value() != v for i, v in want):
            return False
        if time.time() - since >= hold_s:
            return True

def set_time_fields(fs, start, end, ctx, label):
    # Qargo's time picker (Oct 2026): entering the start time redraws both time fields (their ids go from
    # __invalid_timewindow_time_* to the stop's own), and an end time typed during that redraw is dropped.
    # So the end time waits for that redraw, both are then watched for 0.4 s, and what was lost is typed again.
    # (Until 21 Oct each time was watched 0.4 s on its own: 0.5 s more per stop)
    tins = fs.locator('input[placeholder="08:00"]')
    want = [(i, v) for i, v in ((0, start), (1, end)) if v]
    for _ in range(3):
        lost = [(i, v) for i, v in want if tins.nth(i).input_value() != v]
        if not lost:
            break
        for i, value in lost:
            tins.nth(i).fill(value); tins.nth(i).press("Tab")
            if i == 0:
                redrawn(fs)
        if times_kept(tins, want):
            break
    if start or end:
        # NOT .first: an "Uncouple trailer" stop also has the "Empty trip" switch before Enforce
        sw = switch(fs, "enforce")
        if sw is None:
            ctx["warnings"].append(f"{label}: Enforce switch not found")
            return
        if sw.get_attribute("aria-checked") != "true":
            sw.click()
        if sw.get_attribute("aria-checked") != "true":
            ctx["warnings"].append(f"{label}: Enforce switch not on")
    for i, key, value in ((0, "start", start), (1, "end", end)):
        if value and tins.nth(i).input_value() != value:
            ctx["warnings"].append(f"CHECK {label} {key} time: expected {value!r}, form has {tins.nth(i).input_value()!r}")

def fill_stop(page, prefix, st, ctx, label, is_setup_like=False, parts=None):
    """fill one stop card. parts: only these of "location", "date", "time", "reference", "note" (a change: what
    differs from the order in Qargo; an empty reference / note then empties the field), None = everything"""
    ctx["stop"] = label         # the location warnings (NO LOCATION, AMBIGUOUS, CHECK store ...) do not name their stop
    loc_id = f"{prefix}.location"
    inp = by_id(page, loc_id)
    fs = inp.locator("xpath=ancestor::fieldset[1]")          # this stop's card
    soft(ctx, f"{label} scroll", lambda: inp.scroll_into_view_if_needed(timeout=5000))
    if st.get("activity") and (parts is None or "activity" in parts):
        def act():
            fs.locator(".ant-select").first.click(timeout=5000)
            visible_dropdown_options(page).filter(
                has_text=re.compile(r"^\s*" + re.escape(st["activity"]) + r"\s*$")).first.click(timeout=5000)
            page.wait_for_timeout(300)
        soft(ctx, f"{label} activity", act)
    def location():
        ctx["chosen"].append(f"{label}: {choose_location(page, inp, loc_id, st['location'], ctx)}")
    if parts is None or "location" in parts:
        soft(ctx, f"{label} location", location)
    def date():
        d = fs.locator(f'[id="{prefix}.date"]').first
        d.fill(st["date"], timeout=5000); d.press("Escape")
    if parts is None or "date" in parts:
        soft(ctx, f"{label} date", date)
    if parts is None or "time" in parts:
        soft(ctx, f"{label} time", lambda: set_time_fields(fs, st.get("start"), st.get("end"), ctx, label))
    if parts is not None:
        for part, fid in (("reference", "reference_number"), ("note", "note")):
            if part in parts:
                soft(ctx, f"{label} {part}", lambda fid=fid, part=part: fill_field(fs, f"{prefix}.{fid}", st.get(part) or ""))
        page.keyboard.press("Escape")
        return
    if st.get("duration"):
        def duration():
            dur = fs.locator('[name$=".duration"] input').first
            dur.click(timeout=5000); dur.fill(st["duration"], timeout=5000)
            page.keyboard.press("Enter"); page.keyboard.press("Escape")
        soft(ctx, f"{label} duration", duration)
    if st.get("reference"):
        soft(ctx, f"{label} reference", lambda: fill_field(fs, f"{prefix}.reference_number", st["reference"]))
    if st.get("phone") and not is_setup_like and not prefix.startswith(("setup_input", "teardown_input")):
        def phone():
            pid = f"{prefix}.phone_number"
            if not page.locator(f'[id="{pid}"]').count():
                fs.locator("xpath=ancestor::div[contains(concat(' ', normalize-space(@class), ' '), ' ant-card ')][1]") \
                  .locator('button:has-text("Add information")').first.click(timeout=5000)
                menu_item(page, "Phone number")
            by_id(page, pid).wait_for(state="attached", timeout=5000)
            fill_field(page, pid, st["phone"])
        soft(ctx, f"{label} phone", phone)
    if st.get("note"):
        soft(ctx, f"{label} note", lambda: fill_field(fs, f"{prefix}.note", st["note"]))
    def no_empty_trip():
        # never "Plan trip to couple empty trailer" (shows up on Uncouple trailer stops)
        sw = switch(fs, "empty")
        if sw is not None and sw.get_attribute("aria-checked") == "true":
            sw.click()
            page.wait_for_timeout(200)
            if sw.get_attribute("aria-checked") == "true":
                ctx["warnings"].append(f"{label}: could not switch off 'Plan trip to couple empty trailer'")
    soft(ctx, f"{label} empty trip off", no_empty_trip)
    page.keyboard.press("Escape")

def remove_form_stop(page, prefix, which, ctx):
    """press the trash icon of the start/end stop card Qargo's Container import/export form shows (Export: start
    stop 'Pickup empty container', Import: end stop 'Drop empty container') when the order has no such stop"""
    fs = by_id(page, f"{prefix}.location").locator("xpath=ancestor::fieldset[1]")
    fs.locator("button.ant-btn-default").first.click(timeout=5000)          # the only plain icon button in the card
    page.wait_for_timeout(800)
    if by_id(page, f"{prefix}.location").count():
        ctx["warnings"].append(f"could not remove the {which} stop the form shows ({prefix}); remove it yourself")

def soft(ctx, label, fn):
    """run one step; on failure log it and carry on with the rest of the order"""
    if STEP_HOOK:
        STEP_HOOK(ctx, label)
    try:
        fn()
    except Exception as e:
        ctx["warnings"].append(f"SKIPPED {label}: {type(e).__name__}: {str(e).splitlines()[0][:160]}")

WEIGHT_INPUT_JS = """q => {
    // Qargo renders two inputs with id "Total weight (kg)": a hidden autocomplete search box and the
    // real number field (role=spinbutton). Walk up from this item's Quantity to the smallest box that
    // holds a weight number field, and mark that field.
    const SEL = 'input[role=spinbutton][id="Total weight (kg)"], input[role=spinbutton][placeholder="100.00"]';
    let n = q;
    while (n && !n.querySelector(SEL)) n = n.parentElement;
    if (!n || n.querySelectorAll('[id$=".ordered_quantity"]').length !== 1) return null;
    const el = n.querySelector(SEL);
    el.setAttribute('data-qa-weight', '1');
    return el.id || '(no id)';
}"""

def fill_weight(page, base, kg, ctx, label):
    """Total weight (kg) of one cargo item (the number field in the same cargo card as its Quantity)."""
    val = f"{kg:g}" if isinstance(kg, float) else str(kg)
    page.evaluate("() => document.querySelectorAll('[data-qa-weight]').forEach(e => e.removeAttribute('data-qa-weight'))")
    found = by_id(page, f"{base}.ordered_quantity").evaluate(WEIGHT_INPUT_JS)
    if not found:
        raise RuntimeError("Total weight field not found in this cargo item")
    inp = page.locator("[data-qa-weight]").first
    inp.scroll_into_view_if_needed(timeout=5000)
    inp.click(timeout=5000)
    inp.fill(val, timeout=5000)
    inp.press("Tab")
    page.wait_for_timeout(200)
    got = re.sub(r"[^\d.,]", "", inp.input_value() or "")
    if not got or abs(float(got.replace(",", "")) - float(kg)) > 0.5:
        ctx["warnings"].append(f"CHECK {label}: weight should be {val} kg, form has {inp.input_value()!r}")

# Qargo's cargo item offers Quantity, ADR, Goods description, Requested temperature, piece dimensions and Total weight
# (the Create order form surveyed 14 Oct 2026). The temperature field, read off the live Transport form on 15 Oct 2026:
# a number field <input role="spinbutton" step="1" id="Requested temperature" class="ant-input-number-input"> with no
# name, placeholder or aria-label, its id printed once (unlike the weight's), in a .form-field whose label comes before
# it; next to it, in the same .autocomplete-number box, the form's hidden search box
# id="consignments[i].goods[g].ordered_transport_temperature_value" (role=combobox), which echoes the typed value.
# Decimals (-18.5) are kept. The input is found as the weight is: from this item's Quantity up to the smallest box that
# holds a number field called temperature - by its id, name, placeholder or aria-label, else by the text of the field
# block around it (the largest box that holds no other input) - and no further than one cargo item (one Quantity).
# Returns the input, or null.
TEMPERATURE_PICK_JS = """q => {
    const SEL = 'input[role=spinbutton], input[type=number]';
    const own = e => /temperat/i.test([e.id, e.name, e.placeholder, e.getAttribute('aria-label')].join(' '));
    const block = e => {
        let b = e, up = e.parentElement;
        while (up && up.querySelectorAll('input:not([type=hidden]), textarea').length === 1) { b = up; up = up.parentElement; }
        return b;
    };
    const says = e => own(e) || /temperat/i.test(block(e).textContent || '');
    const pick = n => { const all = [...n.querySelectorAll(SEL)]; return all.find(own) || all.find(says) || null; };
    let n = q;
    while (n && !pick(n)) n = n.parentElement;
    return n && n.querySelectorAll('[id$=".ordered_quantity"]').length === 1 ? pick(n) : null;
}"""
TEMPERATURE_INPUT_JS = "q => { const el = (" + TEMPERATURE_PICK_JS + ")(q); if (!el) return null; " \
                       "el.setAttribute('data-qa-temperature', '1'); return el.id || '(no id)'; }"

def _degrees(s):
    """the number a temperature field shows ('-18', '-18,5 °C'), its sign kept; None when there is none"""
    m = re.search(r"[-−+]?\d+(?:[.,]\d+)?", str(s or ""))
    return float(m.group().replace("−", "-").replace(",", ".")) if m else None

def fill_temperature(page, base, deg, ctx, label):
    """Requested temperature (°C) of one cargo item (the number field in the same cargo card as its Quantity)."""
    val = f"{deg:g}"
    page.evaluate("() => document.querySelectorAll('[data-qa-temperature]').forEach(e => e.removeAttribute('data-qa-temperature'))")
    found = by_id(page, f"{base}.ordered_quantity").evaluate(TEMPERATURE_INPUT_JS)
    if not found:
        raise RuntimeError("Requested temperature field not found in this cargo item")
    inp = page.locator("[data-qa-temperature]").first
    inp.scroll_into_view_if_needed(timeout=5000)
    inp.click(timeout=5000)
    inp.fill(val, timeout=5000)
    inp.press("Tab")
    page.wait_for_timeout(200)
    got = _degrees(inp.input_value())
    if got is None or abs(got - float(deg)) > 0.05:
        ctx["warnings"].append(f"CHECK {label}: temperature should be {val} °C, form has {inp.input_value()!r}")

def add_order_info(page, item):
    page.locator('button:has-text("Add information")').first.click(timeout=5000)
    menu_item(page, item)

def put_order_field(page, field_id, item, value):
    """an order field Qargo shows only once it is added ("Add information" -> item): add it when the form does not
    show it yet, then fill it. An empty value only empties a field that is there"""
    if not by_id(page, field_id).count():
        if value in (None, ""):
            return
        add_order_info(page, item)
    by_id(page, field_id).wait_for(state="attached", timeout=5000)
    fill_field(page, field_id, "" if value is None else value)

def put_consignment_field(page, i, field, item, value):
    """the same for consignment i ("Add consignment information" -> item)"""
    fid = f"consignments[{i}].{field}"
    if not by_id(page, fid).count():
        if value in (None, ""):
            return
        page.locator('button:has-text("Add consignment information")').nth(i).click()
        menu_item(page, item)
    by_id(page, fid).wait_for(state="attached", timeout=5000)
    fill_field(page, fid, "" if value is None else value)

# Qargo looks the Customer Reference up as soon as the field's value changes: one search request (any customer,
# exact match, not cancelled, created in the last 3 months), answered in ~0.1 s. When the field loses focus it
# shows the answer: "Possible duplicate detected in order: <link Or-...>".
# Qargo shows the same warning under a stop's Reference number when another order has that stop reference
# (RD 73724: 'portbase'); only the warning that belongs to the Customer Reference field counts: the nearest box
# around the link that holds an input must hold #customer_reference_number.
DUPLICATE_JS = r"""() => {
    for (const a of document.querySelectorAll('a[href*="/orders/"]')) {
        if (!/\/orders\/[0-9a-f-]{36}/.test(a.getAttribute('href') || '')) continue;
        if (!/duplica|dubbel/i.test((a.parentElement && a.parentElement.textContent) || '')) continue;
        let box = a.parentElement;
        while (box && !box.querySelector('input, textarea')) box = box.parentElement;
        if (box && box.querySelector('#customer_reference_number'))
            return {order: a.textContent.trim(), url: a.href};
    }
    return null;
}"""

class DuplicateOrder(Exception):
    """Qargo already has an order with this customer reference (found: {"order": "Or-...", "url": ...})"""
    def __init__(self, msg, found=None):
        super().__init__(msg)
        self.found = found

def qargo_duplicate(page, wait_s=0.0):
    """{'order': 'Or-0000059', 'url': ...} when Qargo shows its duplicate warning (polls up to wait_s), else None"""
    deadline = time.time() + wait_s
    while True:
        hit = page.evaluate(DUPLICATE_JS)
        if hit or time.time() >= deadline:
            return hit
        page.wait_for_timeout(100)

class ReferenceLookup:
    """Listens for the answers to Qargo's own lookup of customer reference `ref`, so that "no duplicate" is
    known the moment Qargo knows it, without waiting to see whether a warning still appears."""
    def __init__(self, page, ref):
        self.page, self.ref, self.sent, self.answers = page, ref, 0, []
        page.on("request", self._request); page.on("response", self._response); page.on("requestfailed", self._failed)

    def _mine(self, req):
        if req.method != "POST" or "graphql" not in req.url:
            return False
        try:
            terms = req.post_data_json["variables"]["query"]["filter"]["bool"]["filter"][0]["terms"]
            return terms["customer_reference_number"] == [self.ref]
        except Exception:
            return False

    def _request(self, req):
        self.sent += self._mine(req)

    def _response(self, resp):
        if self._mine(resp.request):
            self.answers.append(resp)

    def _failed(self, req):
        if self._mine(req):
            self.answers.append(None)

    def hits(self, wait_s=5.0, answer_s=30.0):
        """row ids of the orders Qargo found once every lookup is answered; None when no lookup was seen within
        wait_s or an answer could not be read (then only the warning on the page can tell). Raises NoAnswer when
        a lookup was sent but failed or got no answer within answer_s (slow or broken internet): "not in Qargo"
        is then not known, and an order filled anyway can become a second one"""
        t0 = time.time()
        try:
            while not self.sent or len(self.answers) < self.sent:
                if time.time() - t0 >= (answer_s if self.sent else wait_s):
                    if self.sent:
                        raise NoAnswer(f"no answer from Qargo within {answer_s:.0f} s to its check whether customer "
                                       f"reference {self.ref!r} is already in Qargo (internet?)")
                    return None
                self.page.wait_for_timeout(25)
        finally:
            for ev, fn in (("request", self._request), ("response", self._response), ("requestfailed", self._failed)):
                self.page.remove_listener(ev, fn)
        if any(a is None or not a.ok for a in self.answers):
            raise NoAnswer(f"Qargo's check whether customer reference {self.ref!r} is already in Qargo failed (internet?)")
        try:
            return [h["row_id"] for a in self.answers for h in a.json()["data"]["Search"]["hits"]]
        except Exception:
            return None

# the documents Qargo shows: a PDF as a "PDF n" tab, a photo as the picture itself (<img alt="preview"> in
# "Order confirmation from customer", no tab: live form, 21 Oct 2026). Counting only the tabs, every photo order
# waited the full 60 s and was reported "DOCUMENT NOT ATTACHED" while the photo was there
DOCS_SHOWN_JS = r"""() => [...document.querySelectorAll('[role=tab]')].filter(t => /^\s*PDF \d+\s*$/.test(t.textContent)).length
    + document.querySelectorAll('.file-preview img[alt=preview]').length"""

def attach_document(page, pdf, ctx, wait_s=60):
    """attach the PDF or photo and wait until Qargo shows it. The upload goes over the internet: 2.9 s on 20 Oct,
    5.8 s with a slow line, where the bot used to wait 2.5 s and go on (and --save could save the order before the
    document was in). Not shown within wait_s: a warning, so --save leaves the order alone"""
    before = page.evaluate(DOCS_SHOWN_JS)
    page.locator('input[type=file][name=file]').first.set_input_files(str(pdf))
    deadline = time.time() + wait_s
    while page.evaluate(DOCS_SHOWN_JS) <= before:
        if time.time() >= deadline:
            ctx["warnings"].append(f"!!! DOCUMENT NOT ATTACHED: Qargo did not show {pdf.name} within {wait_s} s "
                                   f"(internet?); attach it by hand")
            return
        page.wait_for_timeout(250)

def select_pages(page, first, last, ctx):
    """The PDF holds other orders too: keep only this order's pages (Qargo "Select page range" -> a new
    "Split from PDF 1" document tab next to the original "PDF 1"), then close the original."""
    link = page.get_by_text("Select page range", exact=True).first
    link.wait_for(timeout=20000)
    # Qargo scans the attached PDF and shows "Loading suggestions" top right while it does; the document panel
    # sticks to the top of a scrolled form, so that notice lies over the link (the first scan of a PDF is slow:
    # the first order of every multi-order PDF timed out here). Wait for it, then close any notice still there.
    try:
        page.get_by_text("Loading suggestions", exact=True).first.wait_for(state="hidden", timeout=30000)
    except PWTimeout:
        pass
    for x in page.locator('.ant-notification-notice-close').all():
        try:
            x.click(timeout=2000)
        except Exception:
            pass
    try:
        link.click(timeout=8000)
    except PWTimeout:
        link.dispatch_event("click")         # still covered: the click event itself, not a mouse click at its spot
    # Qargo puts Start's number into End when End gets focus, so a plain fill makes 1 + "2" = "12" (and the
    # split fails or takes the wrong pages): empty each box first, type, and read it back
    for fid, want in (("__documentScanRangeStart", first), ("__documentScanRangeEnd", last)):
        box = page.locator(f'[id="{fid}"]')
        box.click(timeout=5000)
        box.press("ControlOrMeta+a"); box.press("Backspace")
        box.press_sequentially(str(want))
        if box.input_value() != str(want):
            raise ValueError(f"page {'start' if fid.endswith('Start') else 'end'} box shows "
                             f"{box.input_value()!r}, not {want}")
    page.get_by_role("button", name="Apply").first.click()
    split = page.locator('[role=tab]').filter(has_text=re.compile(r"^\s*Split from PDF"))
    try:
        split.first.wait_for(timeout=60000)     # Qargo's answer: 10 s was once not enough (21 Oct, a busy server)
    except PWTimeout:
        ctx["warnings"].append(f"CHECK document: asked for pages {first}-{last}, but no 'Split from PDF' appeared")
        return
    # close the original whole PDF ("PDF 1"), so only this order's pages are saved with it
    original = page.locator('.ant-tabs-tab').filter(
        has=page.locator('[role=tab]', has_text=re.compile(r"^\s*PDF \d+\s*$")))
    for _ in range(original.count()):
        original.first.locator('.ant-tabs-tab-remove').click(timeout=5000)
        page.wait_for_timeout(800)
    if original.count() or not split.count():
        ctx["warnings"].append(f"CHECK document: pages {first}-{last} split, but closing the original PDF tab failed "
                               f"- check which documents are attached")
        return
    ctx.setdefault("notes", []).append(f"document: only pages {first}-{last} of the PDF (original closed)")

def scac_option_for(liner, names):
    """which of the SCAC options ('MAEU - Maersk Line', ...) to pick for the printed shipping line: the only option,
    or else the only one whose name is the printed name (capitals and spaces aside: 'Maersk Line' -> MAEU, not
    MAEI 'Maersk Line Ltd'). None when that is not exactly one."""
    if len(names) == 1:
        return 0
    same = lambda s: " ".join(s.split()).casefold()
    hits = [i for i, n in enumerate(names) if same(n.split(" - ", 1)[-1]) == same(liner)]
    return hits[0] if len(hits) == 1 else None

def choose_ocean_liner(page, liner, ctx):
    """the 'Ocean liner SCAC' pick list, searched with the first word of the shipping line as printed ('Yang Ming
    Netherlands BV' -> 'YMLU - Yang Ming Marine Transport Corp.'). Picked only when exactly one code fits, or when
    exactly one code's name is the printed name (scac_option_for); otherwise the field stays empty and the printed
    name (in 'Ocean liner name') is all Qargo gets."""
    fid = "filtered_extra_fields.container__ocean_liner_scac"
    word = next((w for w in re.findall(r"[A-Za-z][A-Za-z-]{2,}", liner)), liner.strip())
    f = by_id(page, fid)
    f.click(); f.fill(""); f.press_sequentially(word, delay=15)
    # Qargo searches as you type; 0.7 s was not always enough (RD 73724: 'Cosco' -> only COSU, read as 0 codes).
    # Wait until the list has options and stays the same for 0.6 s, at most 5 s
    opts = visible_dropdown_options(page)
    names, since, deadline = None, time.time(), time.time() + 5
    while time.time() < deadline:
        page.wait_for_timeout(150)
        now = [t.strip() for t in opts.all_inner_texts()]
        if now != names:
            names, since = now, time.time()
        elif names and time.time() - since >= 0.6:
            break
    pick = scac_option_for(liner, names or [])
    if pick is not None:
        opts.nth(pick).click()
        page.wait_for_timeout(250)
        ctx.setdefault("notes", []).append(f"ocean liner SCAC: {names[pick]} (for {liner!r})")
        return
    page.keyboard.press("Escape")
    f.fill("")
    ctx["warnings"].append(f"CHECK ocean liner: {liner!r} fits {len(names)} SCAC codes {names}; pick the Ocean liner "
                           f"SCAC in Qargo")

def leave_form(page, url):
    """go to url, also from a form with something typed in it: Qargo then asks "leave this page?" (beforeunload)
    and the bot says yes - for this one move only"""
    accept = lambda d: d.accept()
    page.on("dialog", accept)
    try:
        page.goto(url)
    finally:
        page.remove_listener("dialog", accept)

def new_form(page, service):
    """an empty Create order form with this transport service chosen"""
    leave_form(page, f"{TENANT_URL}/orders/new")
    page.get_by_text("Transport", exact=True).first.wait_for(timeout=20000)
    page.get_by_text(service, exact=True).first.click()

def fill_consignment(page, i, c, ctx, pickup=True):
    """consignment i of the form, all of it (pickup=False: "Multiple deliveries", the collection is consignment 1's)"""
    if pickup:
        fill_stop(page, f"consignments[{i}].actual_pickup_stop", c["pickup"], ctx, f"c{i+1} collect")
    fill_stop(page, f"consignments[{i}].actual_delivery_stop", c["delivery"], ctx, f"c{i+1} deliver")
    def ddate():
        # Qargo copies the collection date into the delivery date; set it again explicitly
        d = by_id(page, f"consignments[{i}].actual_delivery_stop.date")
        if d.input_value() != c["delivery"]["date"]:
            d.fill(c["delivery"]["date"]); d.press("Escape")
    soft(ctx, f"c{i+1} delivery date", ddate)
    if c.get("reference"):
        soft(ctx, f"c{i+1} consignment reference", lambda: put_consignment_field(
            page, i, "consignment_reference_number", "Consignment reference", c["reference"]))
    if c.get("instructions"):
        soft(ctx, f"c{i+1} instructions", lambda: put_consignment_field(page, i, "instructions", "Instructions", c["instructions"]))
    for g_i, g in enumerate(c.get("goods") or []):
        def goods(g_i=g_i, g=g):
            if g_i > 0:
                page.locator('button:has-text("Add cargo item")').nth(i).click()
                by_id(page, f"consignments[{i}].goods[{g_i}].ordered_quantity").wait_for(state="attached", timeout=5000)
            if g.get("quantity") is not None:
                field_box(page, f"consignments[{i}].goods[{g_i}].ordered_quantity").locator(
                    "input[role=spinbutton]").first.fill(str(g["quantity"]))
            if g.get("description"):
                fill_field(page, f"consignments[{i}].goods[{g_i}].description", g["description"])

        soft(ctx, f"c{i+1} goods {g_i+1}", goods)
        if g.get("weight_kg") is not None:
            soft(ctx, f"c{i+1} goods {g_i+1} weight",
                 lambda g_i=g_i, g=g: fill_weight(page, f"consignments[{i}].goods[{g_i}]", g["weight_kg"], ctx,
                                                  f"c{i+1} goods {g_i+1}"))
        if g.get("temperature_c") is not None:
            soft(ctx, f"c{i+1} goods {g_i+1} temperature",
                 lambda g_i=g_i, g=g: fill_temperature(page, f"consignments[{i}].goods[{g_i}]", g["temperature_c"], ctx,
                                                       f"c{i+1} goods {g_i+1}"))
    page.keyboard.press("Escape")

def fill_day_stops(page, o, ctx, kinds=("setup", "teardown")):
    """the start and end stop of the order (setup / teardown), adding their cards when the form has none"""
    box = o.get("container") or {}
    # setup / teardown (shared by all consignments). Filled after the consignments: filling a
    # collection (the shared DC pickup in "Multiple deliveries") can reset an already filled start stop.
    row0 = page.locator('.row-no-wrap:has(> .col-evenly [id="consignments[0].actual_pickup_stop.location"])').first
    # a Container import/export order already shows the start stop (Export) or the end stop (Import): no button to
    # press; and when the order has no such stop, the form's one goes (its location is required, so it cannot stay)
    if o.get("service") == "Container import/export" and box.get("scenario") and set(kinds) == {"setup", "teardown"}:
        for key, prefix, which in (("setup", "setup_input[0]", "start"), ("teardown", "teardown_input[0]", "end")):
            if not o.get(key) and by_id(page, f"{prefix}.location").count():
                soft(ctx, f"remove {which} stop", lambda prefix=prefix, which=which: remove_form_stop(page, prefix, which, ctx))
    if "setup" in kinds and o.get("setup") and not by_id(page, "setup_input[0].location").count():
        def setup():
            row0.locator(":scope > .col").first.locator("button").click()
            by_id(page, "setup_input[0].location").wait_for(state="attached", timeout=5000)
        soft(ctx, "add start stop", setup)
    if "setup" in kinds and o.get("setup"):
        if by_id(page, "setup_input[0].location").count():
            fill_stop(page, "setup_input[0]", o["setup"], ctx, "start")
    if "teardown" in kinds and o.get("teardown") and not by_id(page, "teardown_input[0].location").count():
        def teardown():
            row0.locator(":scope > .col").last.locator("button").click()
            by_id(page, "teardown_input[0].location").wait_for(state="attached", timeout=5000)
        soft(ctx, "add end stop", teardown)
    if "teardown" in kinds and o.get("teardown"):
        if by_id(page, "teardown_input[0].location").count():
            fill_stop(page, "teardown_input[0]", o["teardown"], ctx, "end")

def fill_extra_stop(page, i, k, st, ctx, parts=None):
    """extra stop k of consignment i: the container form's "Add stop" card (Stops: Position, Stop action, Location,
    date, times, reference, note; live form 20 Oct 2026). parts: as in fill_stop, plus "position" / "activity".
    The Stop action is one of Qargo's internal stop actions: filled only when Qargo has one of that name"""
    prefix, label = f"consignments[{i}].standalone_stops[{k}]", f"c{i+1} extra stop {k+1}"
    if not by_id(page, f"{prefix}.location").count():
        def add():
            # one dashed "Add stop" bar per consignment, under its stop cards
            page.locator("button.ant-btn-dashed").filter(has_text=re.compile(r"^\s*Add stop\s*$")).nth(i).click(timeout=5000)
            by_id(page, f"{prefix}.location").wait_for(state="attached", timeout=5000)
        soft(ctx, f"{label} add", add)
        if not by_id(page, f"{prefix}.location").count():
            return
    if parts is None or "position" in parts:
        def position():
            by_id(page, f"{prefix}.stop_position").locator("xpath=ancestor::div[contains(@class,'ant-select')][1]").click()
            visible_dropdown_options(page).first.wait_for(state="visible", timeout=5000)     # drawn by the page itself
            offered = [t.strip() for t in visible_dropdown_options(page).all_inner_texts()]
            if st["position"] not in offered:
                page.keyboard.press("Escape")
                ctx["warnings"].append(f"!!! {label}: Qargo does not offer the position {st['position']!r}; options: {offered}")
                return
            visible_dropdown_options(page).filter(has_text=re.compile(r"^\s*" + re.escape(st["position"]) + r"\s*$")).first.click()
            page.wait_for_timeout(250)
        soft(ctx, f"{label} position", position)
    if parts is None or "activity" in parts:
        def stop_action():
            sid = f"{prefix}.stop_type"
            inp, have = by_id(page, sid), selected_location(page, sid)
            # Qargo chooses a Stop action by itself when it has only one of type Other (live form, 20 Oct 2026:
            # "Gasmeten" on every new extra stop), and its label then covers the search box: the click timed out.
            # Kept only when it is this stop's own action; any other stop must not carry it
            if st.get("activity") and _txt(have) == _txt(st["activity"]):
                return
            box = inp.locator("xpath=ancestor::div[contains(concat(' ', @class, ' '), ' ant-select ')][1]")
            if have:
                box.hover()
                box.locator(".ant-select-clear").first.click(timeout=5000)
                page.wait_for_timeout(300)
                if selected_location(page, sid):
                    raise RuntimeError(f"Qargo chose the stop action {have!r} by itself and it could not be cleared: "
                                       f"remove it by hand")
            if not st.get("activity"):
                return
            answer = StopActionAnswer(page, st["activity"])
            try:
                box.click(); inp.fill("")
                inp.press_sequentially(st["activity"], delay=10)
                answer.wait(cached_s=2.5)
            except NoAnswer as e:
                # not an answer that Qargo has no such action: say so, never treat it as one
                ctx["warnings"].append(f"NO ANSWER FROM QARGO for the stop action {st['activity']!r} of {label}: {e} "
                                       f"(internet?); Stop action left empty, pick it by hand if Qargo has it")
                inp.fill(""); page.keyboard.press("Escape")
                return
            finally:
                answer.close()
            opt = visible_dropdown_options(page).filter(has_text=re.compile(r"^\s*" + re.escape(st["activity"]) + r"\s*$"))
            deadline = time.time() + 2               # the answer is in: the list draws it a moment later
            while not opt.count() and time.time() < deadline:
                page.wait_for_timeout(100)
            if opt.count():
                opt.first.click()
                page.wait_for_timeout(250)
            else:
                ctx["notes"].append(f"{label}: Qargo has no stop action {st['activity']!r} (Locations > Internal stop "
                                    f"actions, type Other): Stop action left empty; the stop's note says it")
                inp.fill(""); page.keyboard.press("Escape")
        soft(ctx, f"{label} stop action", stop_action)
    rest = {key: v for key, v in st.items() if key not in ("position", "activity")}
    fill_stop(page, prefix, rest, ctx, label, is_setup_like=True,
              parts=None if parts is None else set(parts) - {"position", "activity"})

def fill_extra_stops(page, o, ctx):
    """every consignment's extra stops. After the start / end stop: a Position can name them ("After Drop empty container")"""
    for i, c in enumerate(o["consignments"]):
        for k, st in enumerate(c.get("stops") or []):
            fill_extra_stop(page, i, k, st, ctx)

# Qargo scans every new document ("Loading suggestions" top right, 2-16 s) and then chooses the customer again from
# it. For a customer with defaults that undoes the form (live form, 21 Oct 2026, Simon Loos): "Multiple ..." back to
# "None", every consignment but the first gone, DCZ back in the collect stop. The notice goes once Qargo has done that.
# Attached at the end, as until 21 Oct, that happened to the filled form. A customer without defaults has nothing to
# put back (Cornelissen, PostNL: no prefill after the scan, the form as it was), and its document still goes in at
# the end: with a document in it every step of the form is slower. Edit order does not choose the customer again
# (Or-0000274: nothing changed)
SCAN_OPS = ("DocumentScannerQuery", "DocumentSplitMutation") + CUSTOMER_PREFILL
SCANNING_JS = "() => [...document.querySelectorAll('.ant-notification-notice')].some(n => /Loading suggestions/.test(n.innerText))"

def document_first(page, o, pdf, ctx):
    """for a customer with defaults: attach the document and choose its page range, then wait until Qargo's scans
    of it are done, before the stops are filled (attached at the end, as until 21 Oct, the scan undid the filled
    form). Raises NoAnswer when the scan is not done within 60 s"""
    scan = QargoAnswers(page, SCAN_OPS)
    soft(ctx, "attach PDF", lambda: attach_document(page, pdf, ctx))
    if o.get("pages"):
        soft(ctx, "PDF page range %d-%d" % tuple(o["pages"]), lambda: select_pages(page, *o["pages"], ctx))
    scan.wait("its scan of the document", ask_s=5.0, answer_s=60.0, busy=lambda: page.evaluate(SCANNING_JS))

CHOSEN_LOCATIONS_JS = """() => [...document.querySelectorAll('[id$=".location"]')]
    .filter(i => { const s = i.closest('.ant-select'); return s && s.querySelector('.ant-select-selection-item'); })
    .map(i => i.id)"""

def fill_order(page, o, pdf_dir, ctx):
    page.set_default_timeout(8000)
    # the transport service: Transport, or a container service (OCT) - the form's fields depend on it
    service = o.get("service") or "Transport"
    new_form(page, service)
    box = o.get("container") or {}
    # customer (required - stop if this fails)
    cust = by_id(page, "customer")
    cust.wait_for(timeout=10000)
    cust.click(); cust.press_sequentially(o["customer"], delay=20)
    opt = page.locator('[id="customer_list"] [role=option]').filter(has_text=re.compile("^" + re.escape(o["customer"])))
    opt.first.wait_for(timeout=20000)                           # Qargo searches its customers over the internet
    prefill = QargoAnswers(page, CUSTOMER_PREFILL)
    opt.first.click()
    # what Qargo fills in for this customer must be in before anything is chosen, or its answer undoes the choice
    prefill.wait(f"the choice of customer {o['customer']!r}")
    # a customer with defaults: Qargo put a place in a stop by itself and asked about it (Simon Loos, DCZ)
    defaults = bool(prefill.asked - {"PrefillQuery"}) or bool(page.evaluate(CHOSEN_LOCATIONS_JS))
    # the customer reference
    lookup = ReferenceLookup(page, o["customer_reference"])
    soft(ctx, "customer reference", lambda: by_id(page, "customer_reference_number").fill(o["customer_reference"]))
    # already in Qargo? Stop before filling anything else. Leaving the field makes Qargo show its warning
    soft(ctx, "duplicate check", lambda: by_id(page, "customer_reference_number").press("Tab"))
    hits = lookup.hits() if o["customer_reference"] else []
    # nothing found: no warning will come. Found, or no answer seen: give the warning its time
    dup = qargo_duplicate(page, wait_s=0 if hits == [] else 5)
    if hits and not dup:
        dup = {"order": hits[0], "url": f"{TENANT_URL}/orders/{hits[0]}"}
    if dup and not ctx.get("allow_duplicate"):
        raise DuplicateOrder(f"already in Qargo as {dup['order']} ({dup['url']})", dup)
    if dup:
        ctx["notes"].append(f"Qargo: same customer reference as {dup['order']} - filled anyway (--allow-duplicate)")
    # the source document: for a customer with defaults first, and its scan waited for, because the scan undoes the
    # form; for any other customer at the end (an attached document makes every step of the form slower: +40%)
    pdf = find_source(o["source"], pdf_dir)
    if pdf and defaults:
        document_first(page, o, pdf, ctx)
    if service == "Container import/export" and box.get("scenario"):
        soft(ctx, "import/export", lambda: choose_static(page, "container_scenario", box["scenario"]))
    if o.get("vehicle_category"):          # the select's input is simply id="Vehicle category"
        soft(ctx, "vehicle category", lambda: choose_static(page, "Vehicle category", o["vehicle_category"]))
    by_id(page, "consignments[0].actual_pickup_stop.location").wait_for(state="attached", timeout=10000)
    n = len(o["consignments"])
    # same collection (place, date, time) for every consignment -> one collection, several deliveries
    pk = lambda c: (c["pickup"]["location"].get("query"), c["pickup"]["location"].get("postcode"),
                    c["pickup"]["date"], c["pickup"].get("start"), c["pickup"].get("end"))
    shared_pickup = n > 1 and len({pk(c) for c in o["consignments"]}) == 1
    ctx["shared_pickup"] = shared_pickup
    if n > 1:
        choose_static(page, "__multipleConsignmentKey",
                      "Multiple deliveries" if shared_pickup else "Multiple collections and deliveries")
        for i in range(1, n):
            page.locator('button:has-text("Add consignment")').filter(has_not_text="information").last.click()
            by_id(page, f"consignments[{i}].actual_delivery_stop.location").wait_for(state="attached", timeout=5000)
    # the container (container services only): number, shipping line, seal
    if box.get("number"):
        soft(ctx, "container number", lambda: fill_field(page, "container_number", box["number"]))
    if box.get("liner"):
        soft(ctx, "ocean liner name", lambda: fill_field(page, "filtered_extra_fields.container__ocean_liner_name", box["liner"]))
        soft(ctx, "ocean liner SCAC", lambda: choose_ocean_liner(page, box["liner"], ctx))
    if box.get("seal"):
        soft(ctx, "seal number", lambda: fill_field(page, "filtered_extra_fields.container__seal_number", box["seal"]))
    if o.get("ritnummer"):
        soft(ctx, "ritnummer", lambda: put_order_field(page, "filtered_custom_fields.ritnummer", "Ritnummer", o["ritnummer"]))
    if o.get("instructions"):
        soft(ctx, "order instructions", lambda: put_order_field(page, "instructions", "Instructions", o["instructions"]))
    page.keyboard.press("Escape")
    # a place Qargo put in a stop by itself (a customer's default collect location) is not the document's: the
    # stops start empty, so a stop the bot cannot fill stays empty. Not possible: the order is not filled
    for fid in page.evaluate(CHOSEN_LOCATIONS_JS):
        clear_choice(page, fid)
    # consignments
    for i, c in enumerate(o["consignments"]):
        fill_consignment(page, i, c, ctx, pickup=not (shared_pickup and i > 0))
    fill_day_stops(page, o, ctx)
    fill_extra_stops(page, o, ctx)
    # source document
    if pdf and not defaults:
        soft(ctx, "attach PDF", lambda: attach_document(page, pdf, ctx))
        if o.get("pages"):
            soft(ctx, "PDF page range %d-%d" % tuple(o["pages"]), lambda: select_pages(page, *o["pages"], ctx))
    elif not pdf:
        ctx["warnings"].append(f"document {o['source']} not found in {[str(d) for d in pdf_dir]}")
    verify(page, o, ctx)

# ------------------------------------------------------------------ a change to an order Qargo already has
# An order with "change": true (a PostNL Routemutatie, or --change KEY) is not made again: the bot opens the order
# Qargo has with that customer reference in Edit order (/orders/<id>/edit: the Create order form with the order's
# values in it, under the same field ids), compares it with the document and changes only what differs. Nothing
# differs: "UNCHANGED", and the order is left alone.
SAVED_RE = re.compile(r"/orders/(?!new)[0-9a-f-]{36}/?(?:[?#].*)?$")      # an order's own page (not new, not /edit)
ORDER_ID_RE = re.compile(r"/orders/([0-9a-f-]{36})")

# ------------------------------------------------------------------ Save
# Qargo's Save can first ask "Are you sure you want to submit this form?" with the warnings of its own fields
# (live form, 20 Oct 2026, RD-74325 / Or-0000301: a duplicate reference and two dates in the past). The bot
# answers Save only to what it knows the reason for; anything else is Cancel, and the order stays in its tab.
CONFIRM_TITLE = "Are you sure you want to submit this form?"

class SaveRefused(Exception):
    """Qargo asked before saving, about something the bot leaves to a person: the dialog is Cancelled, the form
    is still in its tab, nothing is saved"""

def qargo_questions(text):
    """the warnings the "Are you sure" dialog lists: [(field, message)]"""
    out = []
    for line in str(text).split("generated a warning:", 1)[-1].splitlines():
        line = " ".join(line.split())
        if line and line not in ("Cancel", "Save"):
            field, _, msg = line.partition(": ")
            out.append((field, msg))
    return out

def unanswered(questions, allow_duplicate=False, own_order=None):
    """the questions the bot does not answer Save to, as texts. Answered: a date in the past (the date the
    document prints; the validator warns when it is more than 60 days off), and a duplicate customer reference
    the planner allowed (--allow-duplicate) or that is the very order being changed"""
    left = []
    for field, msg in questions:
        if msg == "The selected date is in the past.":
            continue
        m = re.fullmatch(r"Possible duplicate detected in order: (Or-\d+)", msg)
        if field == "Customer Reference" and m and (allow_duplicate or m.group(1) == own_order):
            continue
        left.append(f"{field}: {msg}")
    return left

def press_save(tab, *, allow_duplicate=False, own_order=None, timeout_s=60):
    """Qargo's Save, until the saved order's page opens. Returns what Qargo asked and the bot answered with Save
    ([] when it asked nothing). Raises SaveRefused (dialog Cancelled), or PWTimeout when no order page opened
    within timeout_s (a slow line: the save can take a while)"""
    tab.locator('button:has-text("Save")').last.click()
    modal = tab.locator(".ant-modal:visible").filter(has_text=CONFIRM_TITLE)
    answered = None
    for _ in range(int(timeout_s * 4)):          # at least timeout_s: each round waits 0.25 s
        if SAVED_RE.search(tab.url):
            return answered or []
        if answered is None and modal.count():
            questions = qargo_questions(modal.first.inner_text())
            left = unanswered(questions, allow_duplicate, own_order) if questions else ["(no warning listed)"]
            if left:
                modal.first.locator("button").filter(has_text=re.compile(r"^\s*Cancel\s*$")).first.click()
                for _ in range(20):              # the dialog closes with an animation: the form is the operator's again
                    if not modal.count():
                        break
                    tab.wait_for_timeout(250)
                raise SaveRefused("; ".join(left))
            modal.first.locator("button").filter(has_text=re.compile(r"^\s*Save\s*$")).first.click()
            answered = [f"{f}: {m}" for f, m in questions]
        tab.wait_for_timeout(250)
    raise PWTimeout(f"no order page within {timeout_s} s after Save")

class NotChanged(Exception):
    """a change the bot does not make (several orders with the reference, the edit form did not load...): nothing
    in Qargo was touched"""

READ_FORM_JS = r"""() => {
    // a field's value as fill_field() writes it: the textarea / number input next to the id'd element, else the element
    const val = id => {
        const e = document.getElementById(id);
        if (!e) return null;
        const f = e.closest('.form-field'), box = f && f.parentElement;
        const vis = box && box.querySelector('textarea, input[role=spinbutton]');
        return (vis || e).value;
    };
    const stop = p => {
        const inp = document.getElementById(p + '.location');
        if (!inp) return null;
        const fs = inp.closest('fieldset'), sel = inp.closest('.ant-select');
        const item = sel && sel.querySelector('.ant-select-selection-item');
        const date = document.getElementById(p + '.date');
        // the card's first select is its activity (Start of day, Collect ...), as fill_stop() picks it
        const first = fs && fs.querySelector('.ant-select'), act = first && first !== sel && first.querySelector('.ant-select-selection-item');
        return {location: item ? (item.innerText || item.getAttribute('title') || '').trim() : '',
                activity: act ? (act.getAttribute('title') || act.innerText || '').trim() : null,
                date: date ? date.value : null,
                times: fs ? [...fs.querySelectorAll('input[placeholder="08:00"]')].map(i => i.value) : [],
                reference: val(p + '.reference_number'), note: val(p + '.note')};
    };
    const WEIGHT = 'input[role=spinbutton][id="Total weight (kg)"], input[role=spinbutton][placeholder="100.00"]';
    const weight = q => {          // as WEIGHT_INPUT_JS finds it: the weight field in the cargo card of this Quantity
        let n = q;
        while (n && !n.querySelector(WEIGHT)) n = n.parentElement;
        if (!n || n.querySelectorAll('[id$=".ordered_quantity"]').length !== 1) return null;
        return n.querySelector(WEIGHT).value;
    };
    const temperature = q => {     // as TEMPERATURE_INPUT_JS finds it: the Requested temperature field of this cargo card
        const el = (__TEMPERATURE_PICK__)(q);
        return el ? el.value : null;
    };
    const chosen = id => {         // the option a select shows (null: no such field)
        const e = document.getElementById(id), s = e && e.closest('.ant-select'), it = s && s.querySelector('.ant-select-selection-item');
        return e ? (it ? (it.getAttribute('title') || it.innerText || '').trim() : '') : null;
    };
    const cons = [];
    for (let i = 0; document.getElementById(`consignments[${i}].actual_delivery_stop.location`); i++) {
        const c = `consignments[${i}]`, goods = [];
        for (let g = 0; document.getElementById(`${c}.goods[${g}].ordered_quantity`); g++) {
            const q = document.getElementById(`${c}.goods[${g}].ordered_quantity`);
            goods.push({quantity: val(`${c}.goods[${g}].ordered_quantity`), description: val(`${c}.goods[${g}].description`),
                        weight: weight(q), temperature: temperature(q)});
        }
        // the extra stops ("Add stop"): their card's first select is the Position, the Stop action is the activity
        const extra = [];
        for (let s = 0; document.getElementById(`${c}.standalone_stops[${s}].location`); s++) {
            const p = `${c}.standalone_stops[${s}]`;
            extra.push(Object.assign(stop(p), {position: chosen(p + '.stop_position'), activity: chosen(p + '.stop_type')}));
        }
        cons.push({reference: val(`${c}.consignment_reference_number`), instructions: val(`${c}.instructions`),
                   pickup: stop(`${c}.actual_pickup_stop`), delivery: stop(`${c}.actual_delivery_stop`), goods, stops: extra});
    }
    const cust = document.getElementById('customer'), cs = cust && cust.closest('.ant-select');
    const ci = cs && cs.querySelector('.ant-select-selection-item');
    return {customer: ci ? (ci.getAttribute('title') || ci.innerText || '').trim() : null,
            customer_reference: val('customer_reference_number'), instructions: val('instructions'),
            ritnummer: val('filtered_custom_fields.ritnummer'),
            // the container fields (container services only; scenario null: the form has no Import/export)
            container: {scenario: chosen('container_scenario'), number: val('container_number'),
                        liner: val('filtered_extra_fields.container__ocean_liner_name'),
                        seal: val('filtered_extra_fields.container__seal_number')},
            setup: stop('setup_input[0]'), teardown: stop('teardown_input[0]'), consignments: cons};
}""".replace("__TEMPERATURE_PICK__", TEMPERATURE_PICK_JS)

def _txt(s):
    return " ".join(str(s if s is not None else "").split())

def _lines(s):
    """the lines of a text, in any order: a route sheet that prints its "Wachten" before the "Pauze" this time is
    the same route (Or-0000169: only those two lines had swapped places)"""
    return sorted(_txt(l) for l in str(s or "").splitlines() if l.strip())

def _num(s):
    try:
        return float(re.sub(r"[^\d.]", "", str(s).replace(",", ""))) if _txt(s) else None
    except ValueError:
        return None

def place_text(loc):
    return f"{loc.get('name')} ({', '.join(x for x in (loc.get('street'), ' '.join(filter(None, (loc.get('postcode'), loc.get('city'))))) if x)})"

def same_place(loc, shown):
    """does the location the form shows ("Depot Oevel\nNijverheidsstraat 8, BE-2260 Westerlo") stand for the
    document's place? Postcode and house number (the names are written differently: "DEPOT AMSTERDAM ZUIDOOST" is
    "PostNL depot Amsterdam-Zuidoost" in Qargo); without a postcode the street and number, or the name"""
    lines = [l.strip() for l in (shown or "").splitlines() if l.strip()]
    if not lines:
        return False
    addr = lines[-1]
    pc, nr = norm(loc.get("postcode")), street_parts(loc.get("street"))[1]
    if pc:
        tail = norm(addr.rsplit(",", 1)[-1]) if "," in addr else norm(addr)
        if tail.startswith(pc) and (nr is None or street_parts(addr)[1] == nr):
            return True
        # the picker takes a record on the document's street and number whose Dutch postcode differs only in the
        # letters (pick_candidates, a note): the same place here too, or the order it filled never matches
        # (Or-0000221: document 'Stationsplein 17, 4561GD Hulst', Qargo 'AH Winkel 8524 / ..., NL-4561 GC Hulst')
        return same_street_and_number(loc.get("street"), addr) and postcode_gap(pc, addr) == "letters"
    return same_street_and_number(loc.get("street"), addr) or norm(loc.get("name")) == norm(lines[0])

def stop_changes(want, have):
    """[(part, what Qargo has, what the document says)] for one stop; part: activity / location / date / time /
    reference / note. Like the times, a reference, note or activity counts only when the document has one: what only
    Qargo has (a gate code the planner typed in) is not the customer's change and stays (see kept_in_qargo)"""
    out = []
    if want.get("activity") and have.get("activity") is not None and _txt(want["activity"]) != _txt(have["activity"]):
        out.append(("activity", _txt(have["activity"]) or "empty", want["activity"]))
    if not same_place(want["location"], have["location"]):
        out.append(("location", (have["location"] or "").splitlines()[0] if have["location"] else "empty",
                    place_text(want["location"])))
    if have["date"] != want["date"]:
        out.append(("date", have["date"], want["date"]))
    times = (have.get("times") or []) + ["", ""]
    if (want.get("start") and times[0] != want["start"]) or (want.get("end") and times[1] != want["end"]):
        out.append(("time", f"{times[0]}-{times[1]}", f"{want.get('start') or ''}-{want.get('end') or ''}"))
    for part in ("reference", "note"):
        if want.get(part) and _txt(want[part]) != _txt(have.get(part)):
            out.append((part, _txt(have.get(part)) or "empty", _txt(want[part])))
    return out

def kept_in_qargo(want, have, label):
    """what Qargo's stop has and the document does not (left as it is): lines for the log"""
    return [f"{label} {part}: {_txt(have.get(part))!r} is only in Qargo, kept" for part in ("reference", "note")
            if not want.get(part) and _txt(have.get(part))]

def match_consignments(want, have):
    """(pairs [(document index, form index or None)], form indexes nobody matched). By consignment reference when
    every consignment on both sides has its own; else by position"""
    w_refs, h_refs = [_txt(c.get("reference")) for c in want], [_txt(c.get("reference")) for c in have]
    if all(w_refs) and all(h_refs) and len(set(w_refs)) == len(w_refs) and len(set(h_refs)) == len(h_refs):
        pairs = [(i, h_refs.index(r) if r in h_refs else None) for i, r in enumerate(w_refs)]
    else:
        pairs = [(i, i if i < len(have) else None) for i in range(len(want))]
    used = {h for _, h in pairs if h is not None}
    return pairs, [h for h in range(len(have)) if h not in used]

# the container fields the Edit order form lets you change: (form id, orders.json key, name in the log)
CONTAINER_FIELDS = (("container_number", "number", "container number"),
                    ("filtered_extra_fields.container__ocean_liner_name", "liner", "ocean liner name"),
                    ("filtered_extra_fields.container__seal_number", "seal", "seal number"))

def locked(o, have):
    """[(part, what Qargo has, what the document says)] that Qargo's Edit order cannot change: the transport
    service and Import/export are greyed out there (live form, 20 Oct 2026), so is the customer. A container order
    shows Import/export; another service does not"""
    box, got = o.get("container") or {}, (have.get("container") or {}).get("scenario")
    if "container" not in have:
        return []                                # a form read without the container fields: nothing to say
    container = (o.get("service") or "Transport") == "Container import/export"
    if container != (got is not None):
        return [("transport service", "Container import/export" if got is not None else "not Container import/export",
                 o.get("service") or "Transport")]
    if container and box.get("scenario") and _txt(box["scenario"]) != _txt(got):
        return [("import/export", _txt(got) or "empty", box["scenario"])]
    return []

def compare(o, have):
    """the document's order against the Edit order form (READ_FORM_JS). Returns the plan of the change:
    {"order": [(part, old, new)], "day": {"setup": [...], "teardown": [...]}, "pairs": [(i, h, {...})],
     "new": [document indexes Qargo does not have], "gone": [form indexes the document no longer has],
     "by_hand": [texts: what the bot cannot do], "locked": [(part, old, new) Edit order cannot change]}"""
    plan = {"order": [], "day": {}, "pairs": [], "new": [], "gone": [], "by_hand": [], "kept": [],
            "locked": locked(o, have)}
    box, hbox = o.get("container") or {}, have.get("container") or {}
    for _fid, key, part in CONTAINER_FIELDS:
        # like a stop's note: only what the document has counts (a seal number the planner typed in stays)
        if box.get(key) and key in hbox and norm(box[key]) != norm(hbox[key]):
            plan["order"].append((part, _txt(hbox[key]) or "empty", box[key]))
    if _lines(o.get("instructions")) != _lines(have.get("instructions")):
        plan["order"].append(("instructions", _txt(have.get("instructions")) or "empty", _txt(o.get("instructions")) or "empty"))
    if o.get("ritnummer") and str(o["ritnummer"]) != _txt(have.get("ritnummer")):
        plan["order"].append(("ritnummer", _txt(have.get("ritnummer")) or "empty", str(o["ritnummer"])))
    for key, label in (("setup", "start stop"), ("teardown", "end stop")):
        want, got = o.get(key), have.get(key)
        if want and got:
            ch = stop_changes(want, got)
            plan["kept"] += kept_in_qargo(want, got, label)
            if ch:
                plan["day"][key] = ch
        elif want:
            plan["day"][key] = [("stop", "none", place_text(want["location"]))]
        elif got:
            plan["by_hand"].append(f"the {label} {(got['location'] or '').splitlines()[0] if got['location'] else ''} "
                                   f"is in Qargo but not on the document: remove it in Qargo")
    hc = have.get("consignments") or []
    pairs, gone = match_consignments(o["consignments"], hc)
    for i, h in pairs:
        if h is None:
            plan["new"].append(i)
            continue
        c, g = o["consignments"][i], hc[h]
        d = {}
        # "Multiple deliveries": only the first consignment has a collection card; the others share it
        pk_have = g["pickup"] if g["pickup"] is not None else (hc[0]["pickup"] if hc else None)
        if pk_have is not None:
            d["pickup"] = stop_changes(c["pickup"], pk_have)
            if d["pickup"] and g["pickup"] is None:
                plan["by_hand"].append(f"c{i+1}: the collection changed, but in Qargo it is shared with consignment 1: "
                                       f"change it there")
                d["pickup"] = []
        d["delivery"] = stop_changes(c["delivery"], g["delivery"])
        for side, stop_have, name in (("pickup", g["pickup"], "collect"), ("delivery", g["delivery"], "deliver")):
            if stop_have is not None:
                plan["kept"] += kept_in_qargo(c[side], stop_have, f"c{i+1} {name}")
        if _txt(c.get("reference")) != _txt(g.get("reference")):
            d["reference"] = (_txt(g.get("reference")) or "empty", _txt(c.get("reference")) or "empty")
        if c.get("instructions") and _txt(c.get("instructions")) != _txt(g.get("instructions")):
            d["instructions"] = (_txt(g.get("instructions")) or "empty", _txt(c.get("instructions")))
        goods = []
        wg, hg = c.get("goods") or [], g.get("goods") or []
        for k, x in enumerate(wg):
            y = hg[k] if k < len(hg) else None
            if y is None:
                goods.append((k, "cargo item", "none", f"{x.get('quantity') or ''} {x.get('description') or ''}".strip()))
                continue
            if x.get("quantity") is not None and _num(y["quantity"]) != float(x["quantity"]):
                goods.append((k, "quantity", _txt(y["quantity"]) or "empty", str(x["quantity"])))
            if x.get("description") and _txt(x["description"]) != _txt(y["description"]):
                goods.append((k, "description", _txt(y["description"]) or "empty", x["description"]))
            if x.get("weight_kg") is not None and (y.get("weight") is None or _num(y["weight"]) != float(x["weight_kg"])):
                goods.append((k, "weight", _txt(y.get("weight")) or "empty", f"{x['weight_kg']:g}"))
            if x.get("temperature_c") is not None and (y.get("temperature") is None
                                                       or _degrees(y["temperature"]) != float(x["temperature_c"])):
                goods.append((k, "temperature", _txt(y.get("temperature")) or "empty", f"{x['temperature_c']:g}"))
        for k in range(len(wg), len(hg)):
            plan["by_hand"].append(f"c{i+1}: cargo item {k+1} ({_txt(hg[k]['quantity'])} {_txt(hg[k]['description'])}) "
                                   f"is in Qargo but not on the document: remove it in Qargo")
        if goods:
            d["goods"] = goods
        extra = []
        ws, hs = c.get("stops") or [], g.get("stops") or []
        for k, x in enumerate(ws):
            y = hs[k] if k < len(hs) else None
            if y is None:
                extra.append((k, [("stop", "none", place_text(x["location"]))]))
                continue
            # the Stop action is filled only when Qargo has one of that name: an empty one is no change
            ch = stop_changes(x if _txt(y.get("activity")) else {key: v for key, v in x.items() if key != "activity"}, y)
            if x.get("position") and _txt(x["position"]) != _txt(y.get("position")):
                ch.insert(0, ("position", _txt(y.get("position")) or "empty", x["position"]))
            plan["kept"] += kept_in_qargo(x, y, f"c{i+1} extra stop {k+1}")
            if ch:
                extra.append((k, ch))
        for k in range(len(ws), len(hs)):
            plan["by_hand"].append(f"c{i+1}: extra stop {k+1} ({(hs[k]['location'] or '').splitlines()[0] if hs[k]['location'] else ''}) "
                                   f"is in Qargo but not on the document: remove it in Qargo")
        if extra:
            d["stops"] = extra
        if any(d.values()):
            plan["pairs"].append((i, h, d))
    for h in gone:
        g = hc[h]
        what = " ".join(filter(None, [_txt(g.get("reference")),
                                      (g["delivery"]["location"] or "").splitlines()[0] if g["delivery"]["location"] else ""]))
        plan["gone"].append(h)
        plan["by_hand"].append(f"consignment {h+1} ({what}) is in Qargo but no longer on the document: remove it "
                               f"(trash icon of Consignment {h+1}) or cancel it on the order page")
    return plan

def describe(o, plan):
    """the plan as lines for the log: 'c3 (NIWG_OEV_59) collect time: 02:48-03:02 -> 02:46-03:00'"""
    out = [f"order {part}: {old!r} -> {new!r} (Edit order cannot change this)" for part, old, new in plan.get("locked", [])]
    out += [f"order {part}: {old!r} -> {new!r}" for part, old, new in plan["order"]]
    for key, label in (("setup", "start"), ("teardown", "end")):
        out += [f"{label} {part}: {old} -> {new}" for part, old, new in plan["day"].get(key, [])]
    for i, h, d in plan["pairs"]:
        c = o["consignments"][i]
        tag = f"c{i+1}" + (f" ({c['reference']})" if c.get("reference") else "") + (f" [Qargo consignment {h+1}]" if h != i else "")
        for side, label in (("pickup", "collect"), ("delivery", "deliver")):
            out += [f"{tag} {label} {part}: {old} -> {new}" for part, old, new in d.get(side, [])]
        if d.get("reference"):
            out.append(f"{tag} consignment reference: {d['reference'][0]} -> {d['reference'][1]}")
        if d.get("instructions"):
            out.append(f"{tag} instructions: {d['instructions'][0]!r} -> {d['instructions'][1]!r}")
        out += [f"{tag} goods {k+1} {part}: {old} -> {new}" for k, part, old, new in d.get("goods", [])]
        out += [f"{tag} extra stop {k+1} {part}: {old} -> {new}" for k, ch in d.get("stops", []) for part, old, new in ch]
    for i in plan["new"]:
        c = o["consignments"][i]
        out.append(f"c{i+1} ({c.get('reference') or ''}) new: {c['pickup']['location']['name']} -> "
                   f"{c['delivery']['location']['name']}")
    return out + plan["by_hand"]

def read_form(page):
    return page.evaluate(READ_FORM_JS)

def find_in_qargo(page, o, ctx):
    """the orders Qargo has with this order's customer reference ([{"order": "Or-0000170" or its row id, "url"}]),
    by Qargo's own duplicate check: the reference typed into an empty Create order form"""
    new_form(page, o.get("service") or "Transport")
    ref = o["customer_reference"]
    lookup = ReferenceLookup(page, ref)
    by_id(page, "customer_reference_number").wait_for(timeout=10000)
    by_id(page, "customer_reference_number").fill(ref)
    by_id(page, "customer_reference_number").press("Tab")
    hits = lookup.hits()
    dup = qargo_duplicate(page, wait_s=0 if hits == [] else 5)
    # one order can come back from several lookups (Qargo searches again as the field changes)
    found = [{"order": h, "url": f"{TENANT_URL}/orders/{h}"} for h in dict.fromkeys(hits or [])]
    if dup:
        m = ORDER_ID_RE.search(dup["url"])
        same = [f for f in found if m and f["url"].endswith(m.group(1))]
        if same:
            same[0]["order"] = dup["order"]
        else:
            found.insert(0, {"order": dup["order"], "url": f"{TENANT_URL}/orders/{m.group(1)}" if m else dup["url"]})
    return found

CUSTOMER_SHOWN_JS = """() => { const e = document.getElementById('customer'), s = e && e.closest('.ant-select');
    return !!(s && s.querySelector('.ant-select-selection-item')); }"""

def open_edit(page, found, ref):
    """Edit order of `found`, once its values are in the form"""
    leave_form(page, f"{found['url']}/edit")
    by_id(page, "consignments[0].actual_delivery_stop.location").wait_for(state="attached", timeout=20000)
    deadline = time.time() + 15
    while by_id(page, "customer_reference_number").input_value() != ref:
        if time.time() > deadline:
            raise NotChanged(f"the Edit order form of {found['order']} did not show customer reference {ref!r}")
        page.wait_for_timeout(200)
    # the customer comes in after the reference (live form, 20 Oct 2026: read too early it was empty, and the order
    # passed for another customer's): an empty customer is no answer, never "not this customer's"
    deadline = time.time() + 20
    while not page.evaluate(CUSTOMER_SHOWN_JS):
        if time.time() > deadline:
            raise NotChanged(f"the Edit order form of {found['order']} did not show its customer within 20 s (internet?)")
        page.wait_for_timeout(250)
    # the stops' locations come in last: wait until every location field shows its place (or 10 s)
    deadline = time.time() + 10
    while time.time() < deadline and page.evaluate("""() => [...document.querySelectorAll('[id$=".location"]')]
            .some(i => !i.closest('.ant-select').querySelector('.ant-select-selection-item'))"""):
        page.wait_for_timeout(250)
    page.wait_for_timeout(500)

def same_customer(o, have):
    """is the order in the form the order's customer's? (the reference lookup is over all customers)"""
    return norm(have.get("customer")).startswith(norm(o["customer"])) if have.get("customer") else False

def differences(page, o, found):
    """what differs between the document and the order Qargo has (opens its Edit order form): lines, [] = nothing,
    None when that order is another customer's"""
    open_edit(page, found, o["customer_reference"])
    have = read_form(page)
    return describe(o, compare(o, have)) if same_customer(o, have) else None

def apply_change(page, o, plan, ctx):
    """make the form what the document says, field by field, only where the plan says it differs"""
    if plan["order"]:
        for part, _old, new in plan["order"]:
            if part == "instructions":
                soft(ctx, "order instructions", lambda: put_order_field(page, "instructions", "Instructions", o.get("instructions")))
            elif part == "ritnummer":
                soft(ctx, "ritnummer", lambda: put_order_field(page, "filtered_custom_fields.ritnummer", "Ritnummer", o["ritnummer"]))
            for fid, key, name in CONTAINER_FIELDS:
                if part == name:
                    soft(ctx, name, lambda fid=fid, key=key: fill_field(page, fid, o["container"][key]))
        page.keyboard.press("Escape")
    for i, h, d in plan["pairs"]:
        c, label = o["consignments"][i], f"c{i+1}"
        for side, card, name in (("pickup", "actual_pickup_stop", "collect"), ("delivery", "actual_delivery_stop", "deliver")):
            parts = {p for p, _, _ in d.get(side, [])}
            if parts:
                fill_stop(page, f"consignments[{h}].{card}", c[side], ctx, f"{label} {name}", parts=parts)
        if d.get("pickup"):
            def ddate(h=h, c=c):
                # Qargo copies a changed collection date into the delivery date: set the delivery date again
                dd = by_id(page, f"consignments[{h}].actual_delivery_stop.date")
                if dd.input_value() != c["delivery"]["date"]:
                    dd.fill(c["delivery"]["date"]); dd.press("Escape")
            soft(ctx, f"{label} delivery date", ddate)
        if d.get("reference"):
            soft(ctx, f"{label} consignment reference", lambda h=h, c=c: put_consignment_field(
                page, h, "consignment_reference_number", "Consignment reference", c.get("reference")))
        if d.get("instructions"):
            soft(ctx, f"{label} instructions",
                 lambda h=h, c=c: put_consignment_field(page, h, "instructions", "Instructions", c["instructions"]))
        for k, part, _old, _new in d.get("goods", []):
            g, base = c["goods"][k], f"consignments[{h}].goods[{k}]"
            if part == "cargo item":
                def add(k=k, g=g, h=h, base=base):
                    page.locator('button:has-text("Add cargo item")').nth(h).click()
                    by_id(page, f"{base}.ordered_quantity").wait_for(state="attached", timeout=5000)
                    if g.get("quantity") is not None:
                        field_box(page, f"{base}.ordered_quantity").locator("input[role=spinbutton]").first.fill(str(g["quantity"]))
                    if g.get("description"):
                        fill_field(page, f"{base}.description", g["description"])
                soft(ctx, f"{label} goods {k+1}", add)
                if g.get("weight_kg") is not None:
                    soft(ctx, f"{label} goods {k+1} weight", lambda g=g, base=base, k=k: fill_weight(page, base, g["weight_kg"], ctx, f"{label} goods {k+1}"))
                if g.get("temperature_c") is not None:
                    soft(ctx, f"{label} goods {k+1} temperature", lambda g=g, base=base, k=k: fill_temperature(page, base, g["temperature_c"], ctx, f"{label} goods {k+1}"))
            elif part == "quantity":
                soft(ctx, f"{label} goods {k+1}", lambda g=g, base=base: field_box(page, f"{base}.ordered_quantity").locator(
                    "input[role=spinbutton]").first.fill(str(g["quantity"])))
            elif part == "description":
                soft(ctx, f"{label} goods {k+1}", lambda g=g, base=base: fill_field(page, f"{base}.description", g["description"]))
            elif part == "weight":
                soft(ctx, f"{label} goods {k+1} weight", lambda g=g, base=base, k=k: fill_weight(page, base, g["weight_kg"], ctx, f"{label} goods {k+1}"))
            elif part == "temperature":
                soft(ctx, f"{label} goods {k+1} temperature", lambda g=g, base=base, k=k: fill_temperature(page, base, g["temperature_c"], ctx, f"{label} goods {k+1}"))
        page.keyboard.press("Escape")
    n_form = len(read_form(page)["consignments"])
    for n, i in enumerate(plan["new"]):
        h = n_form + n
        def add_consignment(h=h):
            button = page.locator('button:has-text("Add consignment")').filter(has_not_text="information")
            if not button.count():
                raise NotChanged("no Add consignment button")
            button.last.click()
            by_id(page, f"consignments[{h}].actual_delivery_stop.location").wait_for(state="attached", timeout=5000)
        try:
            add_consignment()
        except Exception:
            c = o["consignments"][i]
            ctx["by_hand"].append(f"c{i+1} ({c.get('reference') or ''}) is new on the document, but the bot could not "
                                  f"add a consignment to this order: add it in Qargo")
            continue
        fill_consignment(page, h, o["consignments"][i], ctx,
                         pickup=bool(by_id(page, f"consignments[{h}].actual_pickup_stop.location").count()))
        for k, st in enumerate(o["consignments"][i].get("stops") or []):
            fill_extra_stop(page, h, k, st, ctx)
    page.keyboard.press("Escape")
    # the start / end stop last, as on a new order: filling a collection can reset them
    for key, label, prefix in (("setup", "start", "setup_input[0]"), ("teardown", "end", "teardown_input[0]")):
        ch = plan["day"].get(key)
        if not ch:
            continue
        if ch[0][0] == "stop":
            fill_day_stops(page, o, ctx, kinds=(key,))
        else:
            fill_stop(page, prefix, o[key], ctx, label, parts={p for p, _, _ in ch})
    # the extra stops after those, as on a new order
    for i, h, d in plan["pairs"]:
        for k, ch in d.get("stops", []):
            st = o["consignments"][i]["stops"][k]
            fill_extra_stop(page, h, k, st, ctx, parts=None if ch[0][0] == "stop" else {p for p, _, _ in ch})

def change_order(page, o, pdf_dir, ctx):
    """the order with "change": edit the order Qargo has with its customer reference. Returns the status:
    "UNCHANGED (Or-...)" (Qargo already has it as the document says), "EDITED (Or-...)" (the form holds the change,
    not saved yet), or "FILLED" (Qargo has no such order: made as a new one). Raises NotChanged."""
    page.set_default_timeout(8000)
    ref = o["customer_reference"]
    found = find_in_qargo(page, o, ctx)
    if not found:
        ctx["warnings"].append(f"marked as a change, but Qargo has no order with customer reference {ref!r}: "
                               f"filled as a NEW order")
        fill_order(page, o, pdf_dir, ctx)
        return "FILLED"
    # the lookup is over all customers: only an order of this order's customer is the one to change
    mine, others = [], []
    for f in found:
        open_edit(page, f, ref)
        have = read_form(page)
        (mine if same_customer(o, have) else others).append((f, have))
    if not mine:
        raise NotChanged(f"Qargo's order with customer reference {ref!r} ({', '.join(f['order'] for f, _ in others)}) "
                         f"is not {o['customer']}'s: {', '.join(repr(h.get('customer')) for _, h in others)}")
    if len(mine) > 1:
        raise NotChanged(f"Qargo has {len(mine)} orders of {o['customer']} with customer reference {ref!r} "
                         f"({', '.join(f['order'] for f, _ in mine)}): change the right one by hand")
    (one, have), = mine
    ctx["qargo"] = one
    if page.url.rstrip("/") != f"{one['url']}/edit":
        open_edit(page, one, ref)
    plan = compare(o, read_form(page))
    if plan["locked"]:
        # the rest of the change would make a mix of the two (Import stops with an Export's activities): touch nothing
        part, old, new = plan["locked"][0]
        raise NotChanged(f"{one['order']} is {part} {old} in Qargo, the document says {new}, and Qargo's Edit order "
                         f"cannot change that. The order as the document says is a new order (--allow-duplicate "
                         f"{o['key']}, or Create similar order on {one['order']}); what happens to {one['order']} "
                         f"(cancel it, or keep it for the trip that was driven) is for a person to decide")
    lines = describe(o, plan)
    if not lines:
        ctx["notes"].append(f"{one['order']} already is what {o['source']} says: nothing changed")
        return f"UNCHANGED ({one['order']})"
    for line in lines:
        ctx["notes"].append(f"change in {one['order']}: {line}")
    ctx["notes"] += [f"{one['order']}: {line}" for line in plan["kept"]]
    ctx["by_hand"] = list(plan["by_hand"])
    apply_change(page, o, plan, ctx)
    # the change document goes with the order, next to the one it came with. Qargo's "Select page range" only
    # splits the order's first PDF, so this one is attached whole
    pdf = find_source(o["source"], pdf_dir)
    if pdf:
        soft(ctx, "attach PDF", lambda: attach_document(page, pdf, ctx))
        if o.get("pages"):
            ctx["notes"].append(f"document: the whole {o['source']} is attached; this order is pages "
                                f"{o['pages'][0]}-{o['pages'][1]}")
    else:
        ctx["warnings"].append(f"document {o['source']} not found in {[str(d) for d in pdf_dir]}")
    # read the form back: whatever still differs (apart from what is left to a person) is a warning
    after = describe(o, compare(o, read_form(page)))
    for line in after:
        if line not in plan["by_hand"]:
            ctx["warnings"].append(f"CHECK after the change, still differs: {line}")
    empty = page.evaluate("""() => [...document.querySelectorAll('[id$=".location"]')]
        .filter(i => !i.closest('.ant-select').querySelector('.ant-select-selection-item'))
        .map(i => i.id)""")
    for e in empty:
        ctx["warnings"].append(f"EMPTY location field {e}")
    return f"EDITED ({one['order']})"

STOP_READBACK_JS = """prefix => {
    const inp = document.getElementById(prefix + '.location');
    if (!inp) return null;
    const fs = inp.closest('fieldset');
    const item = inp.closest('.ant-select') && inp.closest('.ant-select').querySelector('.ant-select-selection-item');
    const date = fs && fs.querySelector('[id="' + prefix + '.date"]');
    return {location: item ? (item.getAttribute('title') || item.textContent || '').trim() : '',
            date: date ? date.value : null,
            times: fs ? [...fs.querySelectorAll('input[placeholder="08:00"]')].map(i => i.value) : []};
}"""

def verify(page, o, ctx):
    """read the form back and compare with what should be there"""
    dup = qargo_duplicate(page)
    if dup and not ctx.get("allow_duplicate"):
        ctx["warnings"].append(f"!!! DUPLICATE: Qargo says customer reference {o['customer_reference']!r} "
                               f"is already in {dup['order']} ({dup['url']})")
    # Qargo's scan of the document chooses the customer again (document_first)
    got = selected_location(page, "customer")
    if not same_customer(o, {"customer": got}):
        ctx["warnings"].append(f"CHECK customer: expected {o['customer']!r}, form has {got!r}")
    def val(i):
        loc = by_id(page, i)
        return loc.input_value() if loc.count() else None
    checks = [("customer_reference_number", o["customer_reference"])]
    if o.get("ritnummer"):
        checks.append(("filtered_custom_fields.ritnummer", str(o["ritnummer"])))
    box = o.get("container") or {}
    for fid, key in (("container_number", "number"), ("filtered_extra_fields.container__ocean_liner_name", "liner"),
                     ("filtered_extra_fields.container__seal_number", "seal")):
        if box.get(key):
            checks.append((fid, box[key]))
    if o.get("vehicle_category"):
        got = selected_location(page, "Vehicle category")
        if got != o["vehicle_category"]:
            ctx["warnings"].append(f"CHECK vehicle_category: expected {o['vehicle_category']!r}, form has {got!r}")
    for i, c in enumerate(o["consignments"]):
        if not (ctx.get("shared_pickup") and i > 0):
            checks.append((f"consignments[{i}].actual_pickup_stop.date", c["pickup"]["date"]))
        checks.append((f"consignments[{i}].actual_delivery_stop.date", c["delivery"]["date"]))
        if c.get("reference"):
            checks.append((f"consignments[{i}].consignment_reference_number", c["reference"]))
    for fid, want in checks:
        got = val(fid)
        if got != want:
            ctx["warnings"].append(f"CHECK {fid}: expected {want!r}, form has {got!r}")
    # collection / delivery times (a time typed while Qargo redrew the picker was dropped without a word)
    for i, c in enumerate(o["consignments"]):
        for kind, name, st in (("pickup", "collect", c["pickup"]), ("delivery", "deliver", c["delivery"])):
            if kind == "pickup" and ctx.get("shared_pickup") and i > 0:
                continue
            got = page.evaluate(STOP_READBACK_JS, f"consignments[{i}].actual_{kind}_stop")
            for j, key in enumerate(("start", "end")):
                have = (got["times"][j:j+1] or [""])[0] if got else ""
                if st.get(key) and have != st[key]:
                    ctx["warnings"].append(f"CHECK c{i+1} {name} {key} time: expected {st[key]!r}, form has {have!r}")
    # start / end stop: location, date and times (these came out empty before; say so loudly)
    for k, label, s in (("setup_input[0]", "START", o.get("setup")), ("teardown_input[0]", "END", o.get("teardown"))):
        if not s:
            continue
        got = page.evaluate(STOP_READBACK_JS, k)
        if got is None:
            ctx["warnings"].append(f"!!! {label} STOP MISSING: no {k} in the form")
            continue
        if not got["location"]:
            ctx["warnings"].append(f"!!! {label} STOP LOCATION EMPTY ({s['location'].get('name')})")
        if got["date"] != s["date"]:
            ctx["warnings"].append(f"!!! {label} STOP DATE: expected {s['date']!r}, form has {got['date']!r}")
        for i, key in enumerate(("start", "end")):
            if s.get(key) and (got["times"][i:i+1] or [None])[0] != s[key]:
                ctx["warnings"].append(f"!!! {label} STOP {key.upper()} TIME: expected {s[key]!r}, "
                                       f"form has {(got['times'][i:i+1] or [None])[0]!r}")
    # the extra stops: there, at their position, on their date and times (an empty location: the check below)
    for i, c in enumerate(o["consignments"]):
        for k, s in enumerate(c.get("stops") or []):
            prefix = f"consignments[{i}].standalone_stops[{k}]"
            got = page.evaluate(STOP_READBACK_JS, prefix)
            if got is None:
                ctx["warnings"].append(f"!!! EXTRA STOP MISSING: no {prefix} in the form ({s['location'].get('name')})")
                continue
            position = selected_location(page, f"{prefix}.stop_position")
            if position != s["position"]:
                ctx["warnings"].append(f"CHECK {prefix}.stop_position: expected {s['position']!r}, form has {position!r}")
            # the Stop action: the document's, or empty (Qargo has no such action); never another one
            action = selected_location(page, f"{prefix}.stop_type")
            if action and _txt(action) != _txt(s.get("activity")):
                ctx["warnings"].append(f"CHECK {prefix}.stop_type: expected {s.get('activity') or ''!r}, form has {action!r}")
            if got["date"] != s["date"]:
                ctx["warnings"].append(f"CHECK {prefix}.date: expected {s['date']!r}, form has {got['date']!r}")
            for j, key in enumerate(("start", "end")):
                have = (got["times"][j:j+1] or [""])[0]
                if s.get(key) and have != s[key]:
                    ctx["warnings"].append(f"CHECK c{i+1} extra stop {k+1} {key} time: expected {s[key]!r}, form has {have!r}")
    # every location field must have a selection
    empty = page.evaluate("""() => [...document.querySelectorAll('[id$=".location"]')]
        .filter(i => !i.closest('.ant-select').querySelector('.ant-select-selection-item'))
        .map(i => i.id)""")
    for e in empty:
        ctx["warnings"].append(f"EMPTY location field {e}")

def open_browser(p, profile, *, channel=None, headless=False, extra_args=()):
    """the browser window with the Qargo login kept in `profile` (channel: None = Playwright's own Chromium,
    or "chrome" / "msedge")"""
    # no fixed viewport: the page follows the window size, so the Save bar stays on screen
    ctxb = p.chromium.launch_persistent_context(str(profile), headless=headless, no_viewport=True, channel=channel,
                                                args=["--start-maximized",
                                                      "--disable-background-timer-throttling",
                                                      "--disable-backgrounding-occluded-windows",
                                                      "--disable-renderer-backgrounding", *extra_args])
    ctxb.add_init_script(ENGLISH_JS)
    return ctxb

# Qargo keeps its language per browser (localStorage USER_LOCALE), not per account, and a new browser profile
# starts in Dutch - but every button the bot presses is found by its English text.
ENGLISH_JS = """(() => {
    try {
        if (location.hostname === %r && localStorage.getItem('USER_LOCALE') !== '"en"')
            localStorage.setItem('USER_LOCALE', '"en"');
    } catch (e) {}
})()""" % TENANT_URL.split("://", 1)[-1].split("/")[0].split(":")[0]

def login_state(page):
    """is this page inside Qargo ("in"), or somewhere else (the login site) or asking for a password ("out")?"""
    if TENANT_URL.split("://", 1)[-1] not in page.url or page.locator('input[type=password]').count():
        return "out"
    return "in"

def fill_one(ctxb, o, pdf_dir, *, save=False, allow_duplicate=False, doc_warnings=(), done=None, done_path=None,
             create_locations=False):
    """Fill one order in a new tab of the browser context ctxb, classify the result and log it.
    doc_warnings: the validator's warnings for this order. save: press Save when there are no warnings at all;
    the saved order then goes into `done` and done_path (default: done.json).
    Returns (status, ctx, tab); tab is None when it was closed. Cancelled (from STEP_HOOK) closes the tab and
    goes on up to the caller."""
    if save:
        done_path = done_path or paths.done_file()
        if done is None:
            done = json.loads(done_path.read_text(encoding="utf-8-sig")) if done_path.exists() else {}
    # validator / parser doubts count as warnings too: --save leaves such an order for you to check
    ctx = {"warnings": [f"JSON: {m}" for m in doc_warnings], "chosen": [], "notes": [], "by_hand": [],
           "allow_duplicate": allow_duplicate, "create_locations": create_locations, "order": o["key"]}
    tab = ctxb.new_page()
    tab.bring_to_front()          # background tabs get paused by Chromium -> "frozen" runs
    log(f"--- {o['key']} ({o['customer']} {o['customer_reference']}, {len(o['consignments'])} consignments)"
        + (" - a CHANGE to the order in Qargo" if o.get("change") else ""))
    try:
        if o.get("change"):
            status = change_order(tab, o, pdf_dir, ctx)
            if status.startswith("UNCHANGED"):
                tab.close(run_before_unload=False)
            elif ctx["by_hand"]:
                # the tab stays open with the rest of the change in it; what the bot could not do is the reason
                status = status.replace("EDITED", "EDIT INCOMPLETE")
                ctx["warnings"] += [f"TO DO BY HAND in {ctx['qargo']['order']}: {t}" for t in ctx["by_hand"]]
        else:
            fill_order(tab, o, pdf_dir, ctx)
            status = "FILLED"
    except DuplicateOrder as e:
        # nothing else was filled: say where the order is, and whether it is what the document says
        status = f"DUPLICATE ({str(e).split(' as ')[1].split(' ')[0]})"
        ctx["warnings"].append(f"{e}. Not filled. If it really is another order: "
                               f"--allow-duplicate {o['key']}")
        if e.found:
            try:
                diff = differences(tab, o, e.found)
                if diff is None:
                    ctx["notes"].append(f"{e.found['order']} is another customer's order with the same reference")
                elif diff:
                    ctx["differs"] = (f"{e.found['order']} differs from the document in {len(diff)} place(s): "
                                      f"{'; '.join(diff[:6])}{' ...' if len(diff) > 6 else ''}. If the customer "
                                      f"changed this order: --change {o['key']}")
                    ctx["warnings"].append(ctx["differs"])
                else:
                    ctx["notes"].append(f"{e.found['order']} in Qargo is what the document says")
            except Exception as ex:
                ctx["notes"].append(f"could not compare with {e.found['order']}: {type(ex).__name__}")
        tab.close(run_before_unload=False)
    except NotChanged as e:
        status = "NOT CHANGED"
        ctx["warnings"].append(f"not changed in Qargo: {e}")
        tab.close(run_before_unload=False)
    except Exception as e:
        status = "ERROR"
        ctx["warnings"].append(f"{type(e).__name__}: {str(e).splitlines()[0][:300]}")
        try:
            # the key of a hand-made orders file can hold what a file name cannot ("/", ":" ...)
            shot = paths.logs_dir() / f"error_{re.sub(r'[^A-Za-z0-9._-]', '_', str(o['key']))}.png"
            tab.screenshot(path=str(shot), full_page=True)
            ctx["warnings"].append(f"screenshot: {shot.name}")
        except Exception:
            pass
    except Cancelled:
        try:
            tab.close(run_before_unload=False)      # never leave a half-filled form behind
        except Exception:
            pass                                    # the window is gone as well: still Cancelled, nothing else
        raise
    for c in ctx["chosen"]:
        log(f"    {c}")
    for n in ctx["notes"]:
        log(f"    note: {n}")
    for w in ctx["warnings"]:
        log(f"    !! {w}")
    if (status == "FILLED" or status.startswith("EDITED")) and save and not ctx["warnings"]:
        try:
            answered = press_save(tab, allow_duplicate=allow_duplicate, own_order=(ctx.get("qargo") or {}).get("order"))
            status = "SAVED" if status == "FILLED" else status.replace("EDITED", "CHANGED")
            done[o["key"]] = tab.url
            done_path.write_text(json.dumps(done, indent=1), encoding="utf-8")
            if answered:
                log(f"    note: Qargo asked before saving, answered Save: {'; '.join(answered)}")
        except SaveRefused as e:
            status += " (not saved: Qargo asked)"
            ctx["warnings"].append(f"QARGO ASKED before saving: {e}. Not saved: check the tab and press Save yourself")
            log(f"    !! {ctx['warnings'][-1]}")
        except PWTimeout:
            status = "SAVE?"; ctx["warnings"].append("Save clicked but no order page opened - check the tab")
    elif status == "FILLED" and save:
        status = "FILLED (not saved: warnings)"
    elif status.startswith("EDITED") and save:
        status += " (not saved: warnings)"
    log(f"    => {status}")
    return status, ctx, (None if tab.is_closed() else tab)

def run_fill(orders_path, *, only=None, customer=None, skip=(), save=False, allow_duplicate=(), pdf_dir=None,
             profile=None, create_locations=False, not_read=(), change=()):
    """What `python3 qargo_fill.py ...` does, with the options as arguments (pdf_dir: a list of folders;
    profile: default ./.qargo-profile). Asks twice in the terminal (log in; finished).
    Returns [(key, status, number of warnings)]."""
    LOG_LINES.clear()             # a second run in the same process must not repeat the first run's lines
    orders_path = Path(orders_path).resolve()
    orders = json.loads(orders_path.read_text(encoding="utf-8-sig"))
    for o in orders:
        if o.get("key") in change:      # the planner knows this order is a change to one Qargo already has
            o["change"] = True
    pdf_dir = [Path(d).expanduser().resolve() for d in (pdf_dir or [paths.documents_dir(), paths.downloads_dir()])]
    done_path = paths.done_file()
    done = json.loads(done_path.read_text(encoding="utf-8-sig")) if done_path.exists() else {}
    sel = [o for o in orders
           if (not only or o["key"] in only)
           and (not customer or o["customer"].lower() == customer.lower())
           and o["key"] not in skip and (o["key"] not in done or o.get("change"))]
    # never fill an order the validator rejects (wrong dates, missing locations, typos in the JSON...)
    errors, warnings = validate(sel, pdf_dir)
    bad = sorted({k for k, _ in errors})
    for k, m in errors:
        log(f"INVALID {k}: {m}")
    if bad:
        log(f"not filling {len(bad)} invalid order(s): {bad} - fix the JSON or the parser first")
        sel = [o for o in sel if o.get("key") not in bad]
    log(f"{len(sel)} orders to fill (skipping {len(done)} already saved per done.json)")
    source = {o.get("key"): o.get("source") or "" for o in orders}
    # (key, status, warnings, why) - an order that is not filled is in the summary too, with the reason
    results = [(k, "NOT FILLED", 0, "; ".join(m for kk, m in errors if kk == k)) for k in bad]
    if not sel:
        # nothing to check in a browser: say so and stop, instead of "DONE filling" over an empty window
        summary(results, source, not_read)
        (paths.logs_dir() / f"fill_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt").write_text("\n".join(LOG_LINES), encoding="utf-8")
        sys.exit(1 if results or not_read else 0)
    failed = 0
    with sync_playwright() as p:
        try:
            ctxb = open_browser(p, profile or paths.profile_dir("chromium"))
            page = ctxb.pages[0] if ctxb.pages else ctxb.new_page()
            page.goto(f"{TENANT_URL}/orders")
            page.wait_for_timeout(3000)
            if login_state(page) == "out":
                input(">>> Log in to Qargo in the browser window, open the Orders page, then press Enter here... ")
            doc_warnings = {}
            for k, m in warnings:
                doc_warnings.setdefault(k, []).append(m)
            for o in sel:
                status, ctx, tab = fill_one(ctxb, o, pdf_dir, save=save, allow_duplicate=o["key"] in allow_duplicate,
                                            create_locations=create_locations,
                                            doc_warnings=doc_warnings.get(o["key"], []), done=done, done_path=done_path)
                why = "" if status in ("FILLED", "SAVED") or not ctx["warnings"] else ctx["warnings"][-1 if status == "SAVE?" else 0]
                if status.startswith(("DUPLICATE", "UNCHANGED")):
                    why = ctx.get("differs", "")
                elif status.startswith("EDIT INCOMPLETE"):
                    why = "; ".join(ctx["by_hand"])
                results.append((o["key"], status, len(ctx["warnings"]), why))
            failed = summary(results, source, not_read)
        finally:
            # before the prompt below, as always (the tabs can stay open for hours) - and also when something
            # stopped the run: the log then says how far it got
            log_file = paths.logs_dir() / f"fill_log_{datetime.datetime.now():%Y%m%d_%H%M%S}.txt"
            log_file.write_text("\n".join(LOG_LINES), encoding="utf-8")
        input(f">>> DONE filling{f', {failed} NOT in Qargo (see !! above)' if failed else ''}. Check each tab and press Save "
              "there. Press Enter here only when you're finished - it closes the browser... ")
        ctxb.close()
    return [r[:3] for r in results]
def summary(results, source, not_read=()):
    """The last thing on screen: what is in a Qargo tab, then everything that is not, with the document and the
    reason. Returns how many orders and documents did not get there."""
    starts = lambda *p: [r for r in results if r[1].startswith(p)]
    ok, changed, dup = starts("FILLED", "SAVED"), starts("EDITED", "CHANGED"), starts("DUPLICATE", "UNCHANGED")
    # a change that is not finished: the order IS in Qargo (as it was), so it is not "NOT in Qargo" either
    unfinished = starts("EDIT INCOMPLETE", "NOT CHANGED")
    failed = [r for r in results if r not in ok + changed + dup + unfinished]
    log("==== summary")
    for k, s, w, _ in ok + changed:
        log(f"{k:20} {s:28} warnings={w}  {source.get(k, '')}")
    for k, s, w, why in dup:
        log(f"{k:20} {s:28} warnings={w}  {source.get(k, '')}")
        if why:                                # in Qargo, but not as the document says: a change nobody marked?
            log(f"!!     {why}")
    for k, s, _, why in unfinished + failed:
        log(f"!! {k:17} {s:28} {source.get(k, '')}")
        log(f"!!     {why}")
    for f in not_read:
        log(f"!! {f}: NOT READ - no order was made from this document; enter it by hand")
    n = len(failed) + len(not_read)
    look = n or unfinished or any(r[3] for r in dup)
    log(f"{len(ok)} filled, " + (f"{len(changed)} changed, " if changed else "") + f"{len(dup)} already in Qargo, "
        + (f"{len(unfinished)} changes not finished, " if unfinished else "")
        + f"{n} NOT in Qargo" + (" <<<<<< look at the !! lines" if look else ""))
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("orders")
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--customer")
    ap.add_argument("--skip", nargs="*", default=[])
    ap.add_argument("--save", action="store_true", help="press Save after filling (only when no warnings)")
    ap.add_argument("--allow-duplicate", nargs="*", default=[], metavar="KEY",
                    help="fill these orders even though Qargo already has an order with the same customer reference")
    ap.add_argument("--change", nargs="*", default=[], metavar="KEY",
                    help="these orders change one Qargo already has (same customer reference): edit that order "
                         "instead of making a new one (a PostNL Routemutatie is a change by itself)")
    ap.add_argument("--create-locations", action="store_true",
                    help="an address Qargo has no location for gets a new location record (never AH stores or guessed "
                         "addresses); such an order is never saved automatically")
    ap.add_argument("--pdf-dir", action="append",
                    help="folder with the source documents, searched recursively (repeatable; "
                         "default: ./documents, then ~/Downloads)")
    ap.add_argument("--profile")
    ap.add_argument("--not-read", nargs="*", default=[], metavar="FILE",
                    help="documents no order was read from (run.py passes them); listed again in the summary")
    a = ap.parse_args()
    run_fill(a.orders, only=a.only, customer=a.customer, skip=a.skip, save=a.save, allow_duplicate=a.allow_duplicate,
             pdf_dir=a.pdf_dir, profile=a.profile, create_locations=a.create_locations, not_read=a.not_read,
             change=a.change)

if __name__ == "__main__":
    main()
